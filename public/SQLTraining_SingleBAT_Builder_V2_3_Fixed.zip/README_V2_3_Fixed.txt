SQL Training Single-BAT Builder V2.3 Fixed
==================================================

Root cause of the registry hang
-------------------------------
The previous command used:

    reg add ... /d "%WORKDIR%\" /f

The data argument ended with a backslash immediately before the closing
quotation mark. Some Windows command-line parsers can treat that sequence
as an escaped quote. In that case, /f is no longer parsed as the force
option.

When the registry value already exists, REG ADD can wait for overwrite
confirmation. This looks like a hang.

The old verification also used:

    findstr /C:"%WORKDIR%\"

The same trailing-backslash-and-quote problem can cause FINDSTR not to
receive the input file correctly and wait for standard input.

V2.3 fix
--------
The trusted location is written without a trailing backslash:

    Path = C:\Users\<user>\AppData\Local\ADS\SQLTraining

The verification pattern also has no trailing backslash.

REG ADD /F now remains a separate valid argument and can overwrite an
existing value without prompting.

Administrator rights
--------------------
This script writes under HKEY_CURRENT_USER rather than HKEY_LOCAL_MACHINE.
It normally runs in the current user's context. However, enterprise
policies or security software can still block REG.EXE or user-created
Trusted Locations.

Build
-----
1. Put SQLTraining_v1.0.accdb in this folder.
2. Run Build_SQLTraining_SingleBAT_V2_3_Fixed.cmd.
3. Distribute SQLTraining_SingleFile_V2_3_Fixed.bat.

Clean test
----------
1. Close all Access windows.
2. Win + R
3. Enter:
   %LOCALAPPDATA%\ADS
4. Delete SQLTraining.
5. Run the generated V2.3 BAT.
6. Test the second launch after closing Access.
