@echo off
setlocal EnableExtensions DisableDelayedExpansion

rem ============================================================
rem SQL Training Lab - Single BAT V2.3 Fixed
rem
rem Important fix:
rem Do not put a trailing backslash immediately before a closing
rem quote in REG ADD or FINDSTR arguments.
rem
rem No certutil. No PowerShell.
rem ============================================================

set "WORKDIR=%LOCALAPPDATA%\ADS\SQLTraining"
set "TRUSTPATH=%WORKDIR%"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "READY=%WORKDIR%\.SQLTraining_V2_3_Fixed.ready"
set "PAYLOAD=%TEMP%\SQLTraining_%RANDOM%_%RANDOM%.b64"
set "TEMPJS=%TEMP%\SQLTraining_Decode_%RANDOM%_%RANDOM%.js"
set "TRUSTKEY=HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99"
set "REGCHECK=%TEMP%\SQLTraining_RegCheck_%RANDOM%_%RANDOM%.txt"

rem Second and later launches.
if exist "%TARGET%" if exist "%READY%" goto OPEN_DATABASE

echo.
echo SQL Training Lab first-run setup...
echo.

tasklist /FI "IMAGENAME eq MSACCESS.EXE" 2>nul | find /I "MSACCESS.EXE" >nul
if not errorlevel 1 (
    echo [ERROR] Microsoft Access is currently running.
    echo Close all Access windows and run this BAT again.
    pause
    exit /b 1
)

if not exist "%WORKDIR%" mkdir "%WORKDIR%" >nul 2>&1

if not exist "%WORKDIR%" (
    echo [ERROR] Could not create the local work folder:
    echo %WORKDIR%
    pause
    exit /b 1
)

call :ENSURE_TRUSTED_LOCATION
if errorlevel 1 exit /b 1

if not exist "%TARGET%" (
    call :RESTORE_DATABASE
    if errorlevel 1 exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] Local ACCDB was not found:
    echo %TARGET%
    pause
    exit /b 1
)

for %%F in ("%TARGET%") do set "TARGET_SIZE=%%~zF"

if %TARGET_SIZE% LSS 1024 (
    echo [ERROR] Local ACCDB is too small or invalid.
    echo Size: %TARGET_SIZE% bytes
    pause
    exit /b 1
)

del "%TARGET%:Zone.Identifier" >nul 2>&1

> "%READY%" echo Ready

if not exist "%READY%" (
    echo [ERROR] Could not create the setup marker.
    pause
    exit /b 1
)

echo [4/4] First-run setup completed.
echo.

goto OPEN_DATABASE

rem ============================================================
rem Trusted Location
rem ============================================================
:ENSURE_TRUSTED_LOCATION

echo [1/4] Checking Access Trusted Location...

if exist "%REGCHECK%" del /q "%REGCHECK%" >nul 2>&1

reg query "%TRUSTKEY%" /v Path > "%REGCHECK%" 2>&1

if not errorlevel 1 (
    findstr /I /L /C:"%TRUSTPATH%" "%REGCHECK%" >nul
    if not errorlevel 1 (
        del /q "%REGCHECK%" >nul 2>&1
        echo [2/4] Trusted Location is already correct.
        exit /b 0
    )
)

del /q "%REGCHECK%" >nul 2>&1

echo Location99 is missing or different.
echo Deleting and recreating Location99...

reg delete "%TRUSTKEY%" /f >nul 2>&1

echo Writing Path...
rem No trailing backslash before the closing quote.
reg add "%TRUSTKEY%" /v Path /t REG_SZ /d "%TRUSTPATH%" /f
if errorlevel 1 goto TRUST_SUB_ERROR

echo Writing AllowSubFolders...
reg add "%TRUSTKEY%" /v AllowSubFolders /t REG_DWORD /d 0 /f
if errorlevel 1 goto TRUST_SUB_ERROR

echo Writing Description...
reg add "%TRUSTKEY%" /v Description /t REG_SZ /d "ADS SQL Training Lab" /f
if errorlevel 1 goto TRUST_SUB_ERROR

echo Verifying Location99...

reg query "%TRUSTKEY%" /v Path > "%REGCHECK%" 2>&1
if errorlevel 1 goto TRUST_SUB_ERROR

rem No trailing backslash at the end of the FINDSTR pattern.
findstr /I /L /C:"%TRUSTPATH%" "%REGCHECK%" >nul
if errorlevel 1 goto TRUST_SUB_ERROR

del /q "%REGCHECK%" >nul 2>&1
echo [2/4] Trusted Location was recreated successfully.
exit /b 0

:TRUST_SUB_ERROR

echo.
echo [ERROR] Could not create or verify the Access Trusted Location.
echo.
echo Registry key:
echo %TRUSTKEY%
echo.
echo Expected Path:
echo %TRUSTPATH%
echo.
echo Current registry data:
reg query "%TRUSTKEY%" /s 2>&1
echo.

if exist "%REGCHECK%" del /q "%REGCHECK%" >nul 2>&1

pause
exit /b 1

rem ============================================================
rem Restore embedded ACCDB outside a parenthesized block.
rem ============================================================
:RESTORE_DATABASE

set "PAYLOAD_LINE="

for /f "tokens=1 delims=:" %%N in ('findstr /n /b /c:":__SQLTRAINING_PAYLOAD__" "%~f0"') do set "PAYLOAD_LINE=%%N"

if not defined PAYLOAD_LINE (
    echo [ERROR] Embedded payload marker was not found.
    pause
    exit /b 1
)

echo [3/4] Extracting and restoring the embedded ACCDB...
echo This can take some time on a company-managed PC.

more +%PAYLOAD_LINE% "%~f0" > "%PAYLOAD%"

if not exist "%PAYLOAD%" (
    echo [ERROR] Temporary payload file was not created.
    pause
    exit /b 1
)

call :WRITE_DECODER "%TEMPJS%"

if not exist "%TEMPJS%" (
    echo [ERROR] Temporary decoder was not created.
    del /q "%PAYLOAD%" >nul 2>&1
    pause
    exit /b 1
)

cscript.exe //nologo "%TEMPJS%" "%PAYLOAD%" "%TARGET%"
set "DECODE_RC=%ERRORLEVEL%"

del /q "%PAYLOAD%" >nul 2>&1
del /q "%TEMPJS%" >nul 2>&1

if not "%DECODE_RC%"=="0" (
    echo [ERROR] Could not restore the embedded ACCDB.
    echo Decoder exit code: %DECODE_RC%
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] Restored ACCDB was not found.
    pause
    exit /b 1
)

exit /b 0

:OPEN_DATABASE

set "ACCESS_EXE="

for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"

if not defined ACCESS_EXE (
    for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"
)

if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE"

if not defined ACCESS_EXE (
    echo [ERROR] Microsoft Access was not found.
    echo Database:
    echo %TARGET%
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] Local ACCDB was not found:
    echo %TARGET%
    pause
    exit /b 1
)

echo Opening Microsoft Access...
start "" "%ACCESS_EXE%" "%TARGET%"

endlocal
exit /b 0

:WRITE_DECODER

> "%~1" echo var args = WScript.Arguments;
>>"%~1" echo if (args.length ^< 2) WScript.Quit(2);
>>"%~1" echo var payloadPath = args.Item(0);
>>"%~1" echo var targetPath = args.Item(1);
>>"%~1" echo try {
>>"%~1" echo   var fso = new ActiveXObject("Scripting.FileSystemObject");
>>"%~1" echo   var input = fso.OpenTextFile(payloadPath, 1, false, 0);
>>"%~1" echo   var base64 = input.ReadAll();
>>"%~1" echo   input.Close();
>>"%~1" echo   base64 = base64.replace(/\s/g, "");
>>"%~1" echo   var xml;
>>"%~1" echo   try {
>>"%~1" echo     xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
>>"%~1" echo   } catch (ignore) {
>>"%~1" echo     xml = new ActiveXObject("Msxml2.DOMDocument.3.0");
>>"%~1" echo   }
>>"%~1" echo   var node = xml.createElement("base64");
>>"%~1" echo   node.dataType = "bin.base64";
>>"%~1" echo   node.text = base64;
>>"%~1" echo   var bytes = node.nodeTypedValue;
>>"%~1" echo   var output = new ActiveXObject("ADODB.Stream");
>>"%~1" echo   output.Type = 1;
>>"%~1" echo   output.Open();
>>"%~1" echo   output.Write(bytes);
>>"%~1" echo   output.SaveToFile(targetPath, 2);
>>"%~1" echo   output.Close();
>>"%~1" echo   WScript.Quit(0);
>>"%~1" echo } catch (e) {
>>"%~1" echo   WScript.Echo("Decode error: " + e.number + " / " + e.description);
>>"%~1" echo   WScript.Quit(1);
>>"%~1" echo }

exit /b 0

:__SQLTRAINING_PAYLOAD__
