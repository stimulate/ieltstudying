#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Lite - アンインストーラー（シンプル版）
#>

$INSTALL_DIR  = "C:\ProgramData\NightLockLite"
$TASK_NAMES   = @(
    "NightLockLite-LogoffAt2200",
    "NightLockLite-IntervalCheck",
    "NightLockLite-OnLogon"
)

function Write-Log { param([string]$m)
    Write-Output "[$(Get-Date -Format 'HH:mm:ss')] $m"
}

Write-Log "=== NightLock Lite Uninstall START ==="

# スケジュールタスクを削除
foreach ($name in $TASK_NAMES) {
    Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue
    Write-Log "Task removed: $name"
}

# インストールディレクトリを削除
if (Test-Path $INSTALL_DIR) {
    Remove-Item -Path $INSTALL_DIR -Recurse -Force -ErrorAction SilentlyContinue
    Write-Log "Removed: $INSTALL_DIR"
}

# イベントログソースを削除
Remove-EventLog -Source "NightLockLite" -ErrorAction SilentlyContinue
Write-Log "Event source removed."

Write-Log "=== NightLock Lite Uninstall END ==="
