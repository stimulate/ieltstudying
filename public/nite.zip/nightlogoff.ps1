#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Lite - 強制ログオフスクリプト（シンプル版）
.DESCRIPTION
    毎日 22:00 と 22:00〜05:00 の 10 分毎にスケジュールタスクから実行される。
    制限時間帯（22:00〜05:00）であれば、除外リスト以外の全ユーザーをログオフする。
    SharePoint・例外名単・Windows Service は使用しない。
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "SilentlyContinue"

# ── 定数 ─────────────────────────────────────────────────────────────────────
$INSTALL_DIR = "C:\ProgramData\NightLockLite"
$LOG_DIR     = "$INSTALL_DIR\logs"
$KILL_SWITCH = "$INSTALL_DIR\MAINTENANCE_MODE"

# 制限時間帯の設定
$RESTRICT_START = 22   # 22:00
$RESTRICT_END   =  5   # 05:00

# ログオフ前の警告表示秒数（0 にすると即時ログオフ）
$WARNING_SECONDS = 60

# 常時除外するアカウント（SAM アカウント名で記載）
# IT 管理者など、夜間作業が想定されるアカウントを追加する
$PERMANENT_EXEMPTIONS = @(
    "Administrator"
)

# ── ログ ─────────────────────────────────────────────────────────────────────
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts      = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line    = "[$ts][$Level][nightlogoff] $Message"
    Write-Output $line
    $logFile = "$LOG_DIR\nightlogoff-$(Get-Date -Format 'yyyyMM').log"
    Add-Content -Path $logFile -Value $line -Encoding UTF8

    # 3 ヶ月以上前のログを自動削除
    Get-ChildItem "$LOG_DIR\nightlogoff-*.log" -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt (Get-Date).AddMonths(-3) } |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

# ── 制限時間帯チェック ────────────────────────────────────────────────────────
function Test-RestrictedHours {
    $hour = (Get-Date).Hour
    # 22:00〜翌 05:00 は深夜をまたぐため OR 条件で判定
    $result = ($hour -ge $RESTRICT_START) -or ($hour -lt $RESTRICT_END)
    Write-Log "Current time: $(Get-Date -Format 'HH:mm'), Restricted: $result"
    return $result
}

# ── アクティブセッション一覧を取得 ───────────────────────────────────────────
function Get-ActiveSessions {
    $sessions = @()
    try {
        # quser はインタラクティブ・切断・ロック画面中のセッションをすべて返す
        $raw = quser 2>&1
        if ($LASTEXITCODE -ne 0) { return $sessions }

        foreach ($line in $raw) {
            if ($line -match "^\s*USERNAME") { continue }  # ヘッダー行をスキップ
            # quser の出力フォーマット: USERNAME  SESSIONNAME  ID  STATE  IDLE TIME  LOGON TIME
            if ($line -match "^\s*>?(\S+)\s+\S*\s+(\d+)\s+(\S+)") {
                $sessions += [PSCustomObject]@{
                    Username  = $Matches[1]
                    SessionId = [int]$Matches[2]
                    State     = $Matches[3]
                }
            }
        }
    }
    catch {
        Write-Log "quser failed: $($_.Exception.Message)" "WARN"
    }
    return $sessions
}

# ── 警告ポップアップを送信 ────────────────────────────────────────────────────
function Send-LogoffWarning {
    param([int]$SessionId, [string]$Username)
    $msg = "【NightLock 警告 / Warning】`n`n" +
           "夜間アクセス制限（22:00〜05:00）により、`n" +
           "${WARNING_SECONDS}秒後に自動ログオフされます。`n" +
           "作業中のファイルを保存してください。`n`n" +
           "Access is restricted from 22:00 to 05:00.`n" +
           "You will be logged off in ${WARNING_SECONDS} seconds.`n" +
           "Please save your work now."
    try {
        msg $SessionId /TIME:$WARNING_SECONDS $msg 2>&1 | Out-Null
        Write-Log "  Warning sent to $Username (session $SessionId)"
    }
    catch {
        Write-Log "  msg.exe failed for session ${SessionId}: $($_.Exception.Message)" "WARN"
    }
}

# ── セッションをログオフ ──────────────────────────────────────────────────────
function Invoke-SessionLogoff {
    param([int]$SessionId, [string]$Username)
    try {
        logoff $SessionId 2>&1 | Out-Null
        Write-Log "  LOGOFF: $Username (session $SessionId)" "WARN"
        Write-EventLog -LogName Application -Source "NightLockLite" -EventId 4001 `
            -EntryType Warning `
            -Message "NightLock Lite: Forced logoff - User='$Username' Session=$SessionId Time=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" `
            -ErrorAction SilentlyContinue
    }
    catch {
        Write-Log "  logoff failed for session ${SessionId}: $($_.Exception.Message)" "ERROR"
    }
}

# ── Main ─────────────────────────────────────────────────────────────────────
Write-Log "===== Enforcement check START ====="

# メンテナンスモードチェック（MAINTENANCE_MODE ファイルがあれば全処理を停止）
if (Test-Path $KILL_SWITCH) {
    Write-Log "MAINTENANCE MODE active. Skipping enforcement." "WARN"
    exit 0
}

# 制限時間帯でなければ何もしない
if (!(Test-RestrictedHours)) {
    Write-Log "Not in restricted hours. No action."
    Write-Log "===== Enforcement check END ====="
    exit 0
}

# 除外リストを HashSet に変換（大文字小文字を無視して比較）
$exemptSet = [System.Collections.Generic.HashSet[string]]::new(
    [System.StringComparer]::OrdinalIgnoreCase
)
foreach ($u in $PERMANENT_EXEMPTIONS) { $exemptSet.Add($u) | Out-Null }
Write-Log "Exempt accounts: $($PERMANENT_EXEMPTIONS -join ', ')"

# セッション一覧を取得して処理
$sessions = Get-ActiveSessions
Write-Log "Active sessions: $($sessions.Count)"

if ($sessions.Count -eq 0) {
    Write-Log "No sessions found."
    Write-Log "===== Enforcement check END ====="
    exit 0
}

foreach ($session in $sessions) {
    $user = $session.Username
    Write-Log "Checking: $user (session=$($session.SessionId) state=$($session.State))"

    # 除外アカウントはスキップ
    if ($exemptSet.Contains($user)) {
        Write-Log "  EXEMPT - skipping: $user"
        continue
    }

    # Windows 組み込みのシステムセッションはスキップ
    if ($user -match "^(SYSTEM|DWM-\d+|UMFD-\d+)$") {
        Write-Log "  System session - skipping: $user"
        continue
    }

    # 警告 → 待機 → 強制ログオフ
    if ($WARNING_SECONDS -gt 0) {
        Send-LogoffWarning -SessionId $session.SessionId -Username $user
        Start-Sleep -Seconds $WARNING_SECONDS
    }
    Invoke-SessionLogoff -SessionId $session.SessionId -Username $user
}

Write-Log "===== Enforcement check END ====="
exit 0
