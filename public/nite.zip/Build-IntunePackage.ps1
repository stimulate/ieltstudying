<#
.SYNOPSIS
    NightLock Lite - Intune Win32 App パッケージビルドスクリプト（シンプル版）
.DESCRIPTION
    管理者作業 PC 上で実行する。
    全ファイルを staging フォルダにまとめ、IntuneWinAppUtil.exe で
    .intunewin パッケージを生成する。
    ※ nssm.exe / クライアントシークレット / SharePoint 設定は不要。

    事前に用意するもの:
    - IntuneWinAppUtil.exe（Microsoft 公式 GitHub からダウンロード）
      https://github.com/microsoft/Microsoft-Win32-Content-Prep-Tool/releases
#>

param(
    [string]$IntuneWinAppUtil = ".\IntuneWinAppUtil.exe",
    [string]$OutputDir        = ".\output"
)

$SOURCE = ".\package"

# ── 前提チェック ──────────────────────────────────────────────────────────────
if (!(Test-Path $IntuneWinAppUtil)) {
    throw "IntuneWinAppUtil.exe が見つかりません: $IntuneWinAppUtil`n" +
          "https://github.com/microsoft/Microsoft-Win32-Content-Prep-Tool/releases からダウンロードしてください。"
}

# ── ステージングフォルダを作成 ────────────────────────────────────────────────
Write-Host "Staging files..." -ForegroundColor Cyan
if (Test-Path $SOURCE) { Remove-Item $SOURCE -Recurse -Force }
New-Item -ItemType Directory -Path "$SOURCE\scripts" -Force | Out-Null

Copy-Item ".\install.ps1"                  "$SOURCE\install.ps1"
Copy-Item ".\uninstall.ps1"               "$SOURCE\uninstall.ps1"
Copy-Item ".\scripts\nightlogoff.ps1"     "$SOURCE\scripts\nightlogoff.ps1"
Copy-Item ".\scripts\logincheck.ps1"      "$SOURCE\scripts\logincheck.ps1"

Write-Host "  Staged files:" -ForegroundColor Green
Get-ChildItem $SOURCE -Recurse -File | ForEach-Object {
    Write-Host "    $($_.FullName.Replace((Resolve-Path $SOURCE).Path, ''))"
}

# ── .intunewin を生成 ─────────────────────────────────────────────────────────
Write-Host "`nBuilding .intunewin..." -ForegroundColor Cyan
if (!(Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir | Out-Null }

& $IntuneWinAppUtil -c $SOURCE -s "install.ps1" -o $OutputDir -q

if (Test-Path "$OutputDir\install.intunewin") {
    Write-Host "  Package created: $OutputDir\install.intunewin" -ForegroundColor Green
} else {
    throw "パッケージ生成に失敗しました。IntuneWinAppUtil.exe の出力を確認してください。"
}

# ── Intune ポータル設定値を表示 ───────────────────────────────────────────────
Write-Host ""
Write-Host "=============================================" -ForegroundColor Yellow
Write-Host "  Intune Win32 App 登録設定値" -ForegroundColor Yellow
Write-Host "=============================================" -ForegroundColor Yellow

Write-Host "`n[アプリ情報]" -ForegroundColor Cyan
Write-Host "  名前        : NightLock Lite v1.0"
Write-Host "  説明        : 夜間（22:00〜05:00）のログオンを制限します"
Write-Host "  発行元      : IT Department"
Write-Host "  バージョン  : 1.0.0"

Write-Host "`n[プログラム]" -ForegroundColor Cyan
Write-Host '  インストールコマンド   : powershell.exe -NonInteractive -NoProfile -ExecutionPolicy Bypass -File "install.ps1"'
Write-Host '  アンインストールコマンド: powershell.exe -NonInteractive -NoProfile -ExecutionPolicy Bypass -File "uninstall.ps1"'
Write-Host "  インストールの動作     : システム  ← 必ずシステムを選択"

Write-Host "`n[要件]" -ForegroundColor Cyan
Write-Host "  OS アーキテクチャ      : 64 ビット"
Write-Host "  最低 OS バージョン     : Windows 10 1903"

Write-Host "`n[検出規則]  ※ 手動で検出規則を構成する" -ForegroundColor Cyan
Write-Host "  規則の種類   : ファイル"
Write-Host "  パス         : C:\ProgramData\NightLockLite"
Write-Host "  ファイル名   : version.txt"
Write-Host "  検出方法     : 文字列（バージョン）の比較"
Write-Host "  演算子       : 次の値と等しい"
Write-Host "  値           : 1.0.0"

Write-Host "`n[割り当て]" -ForegroundColor Cyan
Write-Host "  グループ     : 対象デバイスグループ（または すべてのデバイス）"
Write-Host "  種別         : 必須"

Write-Host ""
Write-Host "=============================================" -ForegroundColor Yellow
Write-Host "  完了。output\install.intunewin を Intune にアップロードしてください。" -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor Yellow
