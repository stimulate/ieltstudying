#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Lite - インストーラー（最小構成版）
.DESCRIPTION
    Intune Win32 App として配信されるエントリーポイント。
    以下のみを行う（シンプル版）:
      1. スクリプトを C:\ProgramData\NightLockLite\ に配置
      2. スケジュールタスクを 3 本登録（ローカル完結、Intune 配信タイミング不依存）
    Windows Service / SharePoint / Break Glass は使用しない。
.VERSION
    1.0.0
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── 定数 ─────────────────────────────────────────────────────────────────────
$INSTALL_DIR     = "C:\ProgramData\NightLockLite"
$SCRIPT_DIR      = "$INSTALL_DIR\scripts"
$LOG_DIR         = "$INSTALL_DIR\logs"
$VERSION_FILE    = "$INSTALL_DIR\version.txt"
$CURRENT_VERSION = "1.0.0"
$SOURCE_DIR      = Split-Path -Parent $MyInvocation.MyCommand.Path

# ── ログ ─────────────────────────────────────────────────────────────────────
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts][$Level] $Message"
    Write-Output $line
    if (!(Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR -Force | Out-Null }
    Add-Content -Path "$LOG_DIR\install.log" -Value $line -Encoding UTF8
}

# ── バージョンチェック（Intune 検出規則と連動した冪等性保証）────────────────
function Test-AlreadyInstalled {
    if (Test-Path $VERSION_FILE) {
        if ((Get-Content $VERSION_FILE -Raw).Trim() -eq $CURRENT_VERSION) {
            Write-Log "Version $CURRENT_VERSION already installed. Skipping."
            return $true
        }
    }
    return $false
}

# ── ディレクトリ作成 + ACL 設定 ──────────────────────────────────────────────
function Initialize-Directories {
    Write-Log "Creating directories..."
    @($INSTALL_DIR, $SCRIPT_DIR, $LOG_DIR) | ForEach-Object {
        if (!(Test-Path $_)) { New-Item -ItemType Directory -Path $_ -Force | Out-Null }
    }

    # SYSTEM と Administrators のみ書き込み可能（社員による改ざん防止）
    $acl = Get-Acl $INSTALL_DIR
    $acl.SetAccessRuleProtection($true, $false)
    $acl.Access | ForEach-Object { $acl.RemoveAccessRule($_) | Out-Null }
    foreach ($identity in @("SYSTEM", "BUILTIN\Administrators")) {
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $identity, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow"
        )
        $acl.AddAccessRule($rule)
    }
    Set-Acl -Path $INSTALL_DIR -AclObject $acl
    Write-Log "Directory ACL secured."
}

# ── スクリプトをコピー ────────────────────────────────────────────────────────
function Copy-Scripts {
    Write-Log "Copying scripts..."
    foreach ($file in @("nightlogoff.ps1", "logincheck.ps1")) {
        $src = Join-Path $SOURCE_DIR "scripts\$file"
        $dst = Join-Path $SCRIPT_DIR $file
        if (Test-Path $src) {
            Copy-Item -Path $src -Destination $dst -Force
            Write-Log "  Copied: $file"
        } else {
            throw "Required script not found in package: $file"
        }
    }
}

# ── スケジュールタスクを登録 ──────────────────────────────────────────────────
function Register-ScheduledTasks {
    Write-Log "Registering Scheduled Tasks..."

    $pwsh  = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $flags = "-NonInteractive -NoProfile -ExecutionPolicy Bypass"

    # ── Task 1: 毎日 22:00 に強制ログオフ ────────────────────────────────────
    # StartWhenAvailable = PC が 22:00 に電源 OFF でも、次回起動後に補完実行する
    $t1Name = "NightLockLite-LogoffAt2200"
    Unregister-ScheduledTask -TaskName $t1Name -Confirm:$false -ErrorAction SilentlyContinue

    $t1Trigger  = New-ScheduledTaskTrigger -Daily -At "22:00"
    $t1Action   = New-ScheduledTaskAction -Execute $pwsh `
                      -Argument "$flags -File `"$SCRIPT_DIR\nightlogoff.ps1`""
    $t1Settings = New-ScheduledTaskSettingsSet `
                      -StartWhenAvailable `
                      -RunOnlyIfNetworkAvailable:$false `
                      -ExecutionTimeLimit (New-TimeSpan -Minutes 5) `
                      -RestartCount 2 `
                      -RestartInterval (New-TimeSpan -Minutes 1)

    Register-ScheduledTask -TaskName $t1Name `
        -Trigger $t1Trigger -Action $t1Action -Settings $t1Settings `
        -RunLevel Highest -User "SYSTEM" -Force | Out-Null
    Write-Log "  Registered: $t1Name"

    # ── Task 2: 22:00〜05:00 の間、10 分毎に再チェック ───────────────────────
    # 理由: 22:00 時点では未ログインだった社員が後からログインするケースをカバー
    $t2Name = "NightLockLite-IntervalCheck"
    Unregister-ScheduledTask -TaskName $t2Name -Confirm:$false -ErrorAction SilentlyContinue

    $t2Trigger = New-ScheduledTaskTrigger -Daily -At "22:00"
    # 22:00 から 7 時間（05:00 まで）、10 分間隔で繰り返す
    $t2Trigger.Repetition = New-CimInstance -CimClass (
        Get-CimClass -Namespace Root/Microsoft/Windows/TaskScheduler `
                     -ClassName MSFT_TaskRepetitionPattern
    ) -Property @{
        Interval          = "PT10M"
        Duration          = "PT7H"
        StopAtDurationEnd = $true
    } -ClientOnly

    $t2Action   = New-ScheduledTaskAction -Execute $pwsh `
                      -Argument "$flags -File `"$SCRIPT_DIR\nightlogoff.ps1`""
    $t2Settings = New-ScheduledTaskSettingsSet `
                      -StartWhenAvailable `
                      -RunOnlyIfNetworkAvailable:$false `
                      -ExecutionTimeLimit (New-TimeSpan -Minutes 5) `
                      -MultipleInstances IgnoreNew

    Register-ScheduledTask -TaskName $t2Name `
        -Trigger $t2Trigger -Action $t2Action -Settings $t2Settings `
        -RunLevel Highest -User "SYSTEM" -Force | Out-Null
    Write-Log "  Registered: $t2Name"

    # ── Task 3: ユーザーがログオンした瞬間に即時チェック ─────────────────────
    # 理由: 上記 2 つは定期実行だが、ログオン直後の数秒〜数分のギャップを埋める
    $t3Name = "NightLockLite-OnLogon"
    Unregister-ScheduledTask -TaskName $t3Name -Confirm:$false -ErrorAction SilentlyContinue

    $t3Trigger  = New-ScheduledTaskTrigger -AtLogOn
    $t3Action   = New-ScheduledTaskAction -Execute $pwsh `
                      -Argument "$flags -File `"$SCRIPT_DIR\logincheck.ps1`""
    $t3Settings = New-ScheduledTaskSettingsSet `
                      -StartWhenAvailable `
                      -RunOnlyIfNetworkAvailable:$false `
                      -ExecutionTimeLimit (New-TimeSpan -Minutes 2)

    Register-ScheduledTask -TaskName $t3Name `
        -Trigger $t3Trigger -Action $t3Action -Settings $t3Settings `
        -RunLevel Highest -User "SYSTEM" -Force | Out-Null
    Write-Log "  Registered: $t3Name"
}

# ── Windows イベントログのソース登録 ─────────────────────────────────────────
function Register-EventSource {
    if (![System.Diagnostics.EventLog]::SourceExists("NightLockLite")) {
        New-EventLog -LogName Application -Source "NightLockLite" -ErrorAction SilentlyContinue
    }
}

# ── バージョンマーカー書き込み（Intune 検出規則用）──────────────────────────
function Write-VersionMarker {
    Set-Content -Path $VERSION_FILE -Value $CURRENT_VERSION -Encoding ASCII
    Write-Log "Version marker written: $CURRENT_VERSION"
}

# ── Main ─────────────────────────────────────────────────────────────────────
try {
    Write-Log "================================================"
    Write-Log " NightLock Lite Installer v$CURRENT_VERSION"
    Write-Log "================================================"

    if (Test-AlreadyInstalled) { exit 0 }

    Initialize-Directories
    Copy-Scripts
    Register-ScheduledTasks
    Register-EventSource
    Write-VersionMarker

    Write-Log "Installation completed successfully."
    exit 0
}
catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log $_.ScriptStackTrace "ERROR"
    exit 1
}
