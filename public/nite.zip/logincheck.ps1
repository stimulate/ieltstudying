#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Lite - ログオン時即時チェック（シンプル版）
.DESCRIPTION
    ユーザーがログオンした瞬間にスケジュールタスク（AtLogon）から実行される。
    制限時間帯（22:00〜05:00）にログオンしたユーザーを即時にログオフする。
    10 分毎の定期チェックが走るまでの空白時間を埋めるのが目的。
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "SilentlyContinue"

$INSTALL_DIR     = "C:\ProgramData\NightLockLite"
$LOG_DIR         = "$INSTALL_DIR\logs"
$KILL_SWITCH     = "$INSTALL_DIR\MAINTENANCE_MODE"

$RESTRICT_START  = 22
$RESTRICT_END    = 5
$WARNING_SECONDS = 60

# nightlogoff.ps1 と同じリストに揃える
$PERMANENT_EXEMPTIONS = @(
    "Administrator"
)

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts      = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line    = "[$ts][$Level][logincheck] $Message"
    Write-Output $line
    $logFile = "$LOG_DIR\logincheck-$(Get-Date -Format 'yyyyMM').log"
    Add-Content -Path $logFile -Value $line -Encoding UTF8
}

function Test-RestrictedHours {
    $hour = (Get-Date).Hour
    return ($hour -ge $RESTRICT_START) -or ($hour -lt $RESTRICT_END)
}

# ログオンしたユーザーとセッション ID を取得
function Get-NewLogonSession {
    # デスクトップが完全に立ち上がるまで少し待つ
    Start-Sleep -Seconds 5

    try {
        $raw = quser 2>&1
        foreach ($line in $raw) {
            if ($line -match "^\s*USERNAME") { continue }
            # Active 状態のセッションのみ対象（ログオン直後は必ず Active）
            if ($line -match "^\s*>?(\S+)\s+\S+\s+(\d+)\s+Active") {
                $user = $Matches[1]
                $sid  = [int]$Matches[2]
                # システムセッションは除外
                if ($user -notmatch "^(SYSTEM|DWM-\d+|UMFD-\d+)$") {
                    return [PSCustomObject]@{ Username = $user; SessionId = $sid }
                }
            }
        }
    }
    catch {
        Write-Log "quser failed: $($_.Exception.Message)" "WARN"
    }
    return $null
}

# ── Main ─────────────────────────────────────────────────────────────────────
Write-Log "===== Logon check START ====="

if (Test-Path $KILL_SWITCH) {
    Write-Log "MAINTENANCE MODE active. Logon check suspended." "WARN"
    exit 0
}

if (!(Test-RestrictedHours)) {
    Write-Log "Logon at $(Get-Date -Format 'HH:mm') - not restricted. Allowed."
    Write-Log "===== Logon check END ====="
    exit 0
}

Write-Log "Logon detected during restricted hours ($(Get-Date -Format 'HH:mm')). Checking user..."

$session = Get-NewLogonSession
if ($null -eq $session) {
    Write-Log "Could not identify the logged-on user. Delegating to nightlogoff.ps1..."
    # ユーザー特定に失敗した場合は全体チェックスクリプトに委譲
    & "$INSTALL_DIR\scripts\nightlogoff.ps1"
    exit 0
}

Write-Log "Logged-on user: $($session.Username) (session $($session.SessionId))"

# 除外チェック
$exemptSet = [System.Collections.Generic.HashSet[string]]::new(
    [System.StringComparer]::OrdinalIgnoreCase
)
foreach ($u in $PERMANENT_EXEMPTIONS) { $exemptSet.Add($u) | Out-Null }

if ($exemptSet.Contains($session.Username)) {
    Write-Log "User $($session.Username) is EXEMPT. Allowing."
    Write-Log "===== Logon check END ====="
    exit 0
}

# 除外対象でなければ警告 → 強制ログオフ
Write-Log "User $($session.Username) is NOT exempt. Initiating logoff..." "WARN"

if ($WARNING_SECONDS -gt 0) {
    $msg = "【NightLock 警告 / Warning】`n`n" +
           "このPCは夜間（22:00〜05:00）はご利用いただけません。`n" +
           "${WARNING_SECONDS}秒後に自動ログオフされます。`n`n" +
           "This PC is restricted from 22:00 to 05:00.`n" +
           "You will be logged off in ${WARNING_SECONDS} seconds."
    msg $session.SessionId /TIME:$WARNING_SECONDS $msg 2>&1 | Out-Null
    Write-Log "Warning sent. Waiting ${WARNING_SECONDS}s..."
    Start-Sleep -Seconds $WARNING_SECONDS
}

logoff $session.SessionId 2>&1 | Out-Null
Write-Log "LOGOFF: $($session.Username) (session $($session.SessionId))" "WARN"

Write-EventLog -LogName Application -Source "NightLockLite" -EventId 4002 `
    -EntryType Warning `
    -Message "NightLock Lite: Logon denied (restricted hours) - User='$($session.Username)' Time=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" `
    -ErrorAction SilentlyContinue

Write-Log "===== Logon check END ====="
exit 0
