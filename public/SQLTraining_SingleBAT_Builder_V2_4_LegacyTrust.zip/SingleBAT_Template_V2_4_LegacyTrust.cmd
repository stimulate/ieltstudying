@echo off
setlocal EnableExtensions DisableDelayedExpansion

rem ============================================================
rem SQL Training Lab - Single BAT V2.4 LegacyTrust
rem
rem Based on the working V2.3 database extraction/startup flow.
rem The Trusted Location block follows the previous BAT shown
rem in the screenshot:
rem
rem   Path = <local folder>\
rem   AllowSubFolders = 0
rem   Description = ADS SQL Training Lab
rem
rem No certutil. No PowerShell.
rem ============================================================

set "WORKDIR=%LOCALAPPDATA%\ADS\SQLTraining"
set "TRUSTPATH=%WORKDIR%\"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "READY=%WORKDIR%\.SQLTraining_V2_4_LegacyTrust.ready"
set "PAYLOAD=%TEMP%\SQLTraining_%RANDOM%_%RANDOM%.b64"
set "TEMPJS=%TEMP%\SQLTraining_Decode_%RANDOM%_%RANDOM%.js"
set "TRUSTKEY=HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99"

rem If the local ACCDB exists, check only. Do not rewrite when correct.
if exist "%TARGET%" (
    call :CHECK_TRUSTED_LOCATION
    if not errorlevel 1 goto OPEN_DATABASE

    rem Repair only the registry. Do not restore or overwrite ACCDB.
    call :WRITE_TRUSTED_LOCATION
    if errorlevel 1 exit /b 1

    goto OPEN_DATABASE
)

echo.
echo SQL Training Lab first-run setup...
echo.

rem Trust Center settings should be written while Access is closed.
tasklist /FI "IMAGENAME eq MSACCESS.EXE" 2>nul | find /I "MSACCESS.EXE" >nul
if not errorlevel 1 (
    echo [ERROR] Microsoft Access is currently running.
    echo Close all Access windows and run this BAT again.
    pause
    exit /b 1
)

if not exist "%WORKDIR%" mkdir "%WORKDIR%" >nul 2>&1

if not exist "%WORKDIR%" (
    echo [ERROR] Could not create the local work folder:
    echo %WORKDIR%
    pause
    exit /b 1
)

call :WRITE_TRUSTED_LOCATION
if errorlevel 1 exit /b 1

call :RESTORE_DATABASE
if errorlevel 1 exit /b 1

if not exist "%TARGET%" (
    echo [ERROR] Local ACCDB was not found:
    echo %TARGET%
    pause
    exit /b 1
)

for %%F in ("%TARGET%") do set "TARGET_SIZE=%%~zF"

if %TARGET_SIZE% LSS 1024 (
    echo [ERROR] Local ACCDB is too small or invalid.
    echo Size: %TARGET_SIZE% bytes
    pause
    exit /b 1
)

rem Remove Mark-of-the-Web from the locally restored database, if present.
del "%TARGET%:Zone.Identifier" >nul 2>&1

attrib +h "%WORKDIR%" >nul 2>&1
attrib +h "%TARGET%" >nul 2>&1

> "%READY%" echo Ready

goto OPEN_DATABASE

rem ============================================================
rem Check the existing Location99 without modifying it.
rem Exact expected value includes a trailing backslash.
rem ============================================================
:CHECK_TRUSTED_LOCATION

set "REGISTERED_PATH="

for /f "tokens=2,*" %%A in ('reg query "%TRUSTKEY%" /v Path 2^>nul ^| findstr /I "REG_SZ"') do set "REGISTERED_PATH=%%B"

if not defined REGISTERED_PATH exit /b 1
if /I not "%REGISTERED_PATH%"=="%TRUSTPATH%" exit /b 1

exit /b 0

rem ============================================================
rem Recreate Location99 using the previous working registry form.
rem HKCU normally does not require administrator privileges.
rem ============================================================
:WRITE_TRUSTED_LOCATION

echo Registering Access Trusted Location...

rem Delete only the dedicated Location99 key.
reg delete "%TRUSTKEY%" /f >nul 2>&1

rem Keep the trailing backslash exactly as in the previous working BAT.
reg add "%TRUSTKEY%" /v Path /t REG_SZ /d "%WORKDIR%\" /f >nul 2>&1
if errorlevel 1 goto TRUST_ERROR

reg add "%TRUSTKEY%" /v AllowSubFolders /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 goto TRUST_ERROR

reg add "%TRUSTKEY%" /v Description /t REG_SZ /d "ADS SQL Training Lab" /f >nul 2>&1
if errorlevel 1 goto TRUST_ERROR

call :CHECK_TRUSTED_LOCATION
if errorlevel 1 goto TRUST_ERROR

echo Access Trusted Location is ready.
exit /b 0

:TRUST_ERROR

echo.
echo [ERROR] Could not create or verify the Access Trusted Location.
echo.
echo Expected:
echo %TRUSTPATH%
echo.
echo Current Location99:
reg query "%TRUSTKEY%" /s 2>&1
echo.
pause
exit /b 1

rem ============================================================
rem Restore embedded ACCDB.
rem This is the same separate-subroutine design used after V2.1.
rem ============================================================
:RESTORE_DATABASE

set "PAYLOAD_LINE="

for /f "tokens=1 delims=:" %%N in ('findstr /n /b /c:":__SQLTRAINING_PAYLOAD__" "%~f0"') do set "PAYLOAD_LINE=%%N"

if not defined PAYLOAD_LINE (
    echo [ERROR] Embedded payload marker was not found.
    pause
    exit /b 1
)

echo Restoring the embedded ACCDB...

more +%PAYLOAD_LINE% "%~f0" > "%PAYLOAD%"

if not exist "%PAYLOAD%" (
    echo [ERROR] Temporary payload file was not created.
    pause
    exit /b 1
)

call :WRITE_DECODER "%TEMPJS%"

if not exist "%TEMPJS%" (
    echo [ERROR] Temporary decoder was not created.
    del /q "%PAYLOAD%" >nul 2>&1
    pause
    exit /b 1
)

cscript.exe //nologo "%TEMPJS%" "%PAYLOAD%" "%TARGET%"
set "DECODE_RC=%ERRORLEVEL%"

del /q "%PAYLOAD%" >nul 2>&1
del /q "%TEMPJS%" >nul 2>&1

if not "%DECODE_RC%"=="0" (
    echo [ERROR] Could not restore the embedded ACCDB.
    echo Decoder exit code: %DECODE_RC%
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] Restored ACCDB was not found.
    pause
    exit /b 1
)

exit /b 0

rem ============================================================
rem Find and start Microsoft Access.
rem ============================================================
:OPEN_DATABASE

set "ACCESS_EXE="

for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"

if not defined ACCESS_EXE (
    for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"
)

if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE"

if not defined ACCESS_EXE (
    echo [ERROR] Microsoft Access was not found.
    echo Database:
    echo %TARGET%
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] Local ACCDB was not found:
    echo %TARGET%
    pause
    exit /b 1
)

echo Opening Microsoft Access...
start "" "%ACCESS_EXE%" "%TARGET%"

endlocal
exit /b 0

rem ============================================================
rem Temporary JScript Base64 decoder.
rem ============================================================
:WRITE_DECODER

> "%~1" echo var args = WScript.Arguments;
>>"%~1" echo if (args.length ^< 2) WScript.Quit(2);
>>"%~1" echo var payloadPath = args.Item(0);
>>"%~1" echo var targetPath = args.Item(1);
>>"%~1" echo try {
>>"%~1" echo   var fso = new ActiveXObject("Scripting.FileSystemObject");
>>"%~1" echo   var input = fso.OpenTextFile(payloadPath, 1, false, 0);
>>"%~1" echo   var base64 = input.ReadAll();
>>"%~1" echo   input.Close();
>>"%~1" echo   base64 = base64.replace(/\s/g, "");
>>"%~1" echo   var xml;
>>"%~1" echo   try {
>>"%~1" echo     xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
>>"%~1" echo   } catch (ignore) {
>>"%~1" echo     xml = new ActiveXObject("Msxml2.DOMDocument.3.0");
>>"%~1" echo   }
>>"%~1" echo   var node = xml.createElement("base64");
>>"%~1" echo   node.dataType = "bin.base64";
>>"%~1" echo   node.text = base64;
>>"%~1" echo   var bytes = node.nodeTypedValue;
>>"%~1" echo   var output = new ActiveXObject("ADODB.Stream");
>>"%~1" echo   output.Type = 1;
>>"%~1" echo   output.Open();
>>"%~1" echo   output.Write(bytes);
>>"%~1" echo   output.SaveToFile(targetPath, 2);
>>"%~1" echo   output.Close();
>>"%~1" echo   WScript.Quit(0);
>>"%~1" echo } catch (e) {
>>"%~1" echo   WScript.Echo("Decode error: " + e.number + " / " + e.description);
>>"%~1" echo   WScript.Quit(1);
>>"%~1" echo }

exit /b 0

:__SQLTRAINING_PAYLOAD__
