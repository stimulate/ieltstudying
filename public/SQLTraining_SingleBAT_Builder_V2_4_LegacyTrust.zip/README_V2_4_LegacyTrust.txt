SQL Training Single-BAT Builder V2.4 LegacyTrust
======================================================

Judgment
--------
The registry code shown in the screenshot should be reused.

The previous working BAT stored:

    Path = C:\Users\<user>\AppData\Local\ADS\SQLTraining\

with a trailing backslash.

V2.3 stored the path without the trailing backslash. The database could
open, but Access still displayed Enable Content. Based on the working
version and the actual behavior, the missing trailing backslash is the
most likely difference.

Correction
----------
V2.4 restores this exact registry command:

    reg add "%TRUSTKEY%" /v Path /t REG_SZ /d "%WORKDIR%\" /f

In cmd.exe, the backslash does not escape the closing quotation mark.
The earlier decision to remove it was incorrect.

V2.4:
- keeps the V2.3 restore and Access startup flow
- uses Location99
- writes Path with the trailing backslash
- writes AllowSubFolders=0
- writes Description
- verifies the exact registry value without FINDSTR trailing-slash syntax
- repairs only Location99 when the local ACCDB already exists
- does not overwrite an existing local ACCDB
- does not use certutil
- does not use PowerShell

Clean test
----------
1. Close all Access windows.
2. Win + R
3. Open:
   %LOCALAPPDATA%\ADS
4. Delete the SQLTraining folder.
5. In Registry Editor, delete only Location99 if it was created by an
   earlier test, or let V2.4 replace it.
6. Build and run SQLTraining_SingleFile_V2_4_LegacyTrust.bat.
7. Confirm in Access:
   File > Options > Trust Center > Trust Center Settings >
   Trusted Locations

Expected path:
   C:\Users\<user>\AppData\Local\ADS\SQLTraining\

The ACCDB must actually be located directly inside that folder.
