﻿Attribute VB_Name = "modSQLLab"
Option Compare Database
Option Explicit

Public Sub BuildTrainingData()
    On Error GoTo EH
    Application.Echo False

    Dim q, t
    For Each q In Array("q_UserResult", "q_sales_by_contract", _
                        "q_wide_to_long", "q_active_product")
        DeleteQueryIfExists CStr(q)
    Next

    For Each t In Array("t_exercise", "contract_wide", "sales", _
                        "contract", "store", "product", _
                        "t_sales_feb", "t_sales_jan", "t_sales_detail", _
                        "t_contract", "m_store", "m_product")
        DeleteTableIfExists CStr(t)
    Next

    CreateTables
    InsertData
    CreateSavedQueries
    InsertExercises

    Application.Echo True
    MsgBox "講義対応版のデータと練習問題を作成しました。", _
           vbInformation, "SQL Training Lab"
    Exit Sub

EH:
    Application.Echo True
    MsgBox "作成に失敗しました。" & vbCrLf & _
           "Error " & Err.Number & ": " & Err.Description, _
           vbCritical, "SQL Training Lab"
End Sub

Private Sub CreateTables()
    ExecSQL "CREATE TABLE product (" & _
            "product_code TEXT(10) NOT NULL, " & _
            "product_name TEXT(50) NOT NULL, " & _
            "product_status TEXT(20), " & _
            "CONSTRAINT pk_product PRIMARY KEY(product_code))"

    ExecSQL "CREATE TABLE store (" & _
            "store_id TEXT(10) NOT NULL, " & _
            "store_name TEXT(50) NOT NULL, " & _
            "region_name TEXT(20), " & _
            "CONSTRAINT pk_store PRIMARY KEY(store_id))"

    'product_name and amount/ap_amount are intentionally duplicated
    'so that the lecture SQL can run without being rewritten.
    ExecSQL "CREATE TABLE [contract] (" & _
            "contract_id LONG NOT NULL, " & _
            "contract_date DATETIME NOT NULL, " & _
            "product_code TEXT(10), " & _
            "product_name TEXT(50), " & _
            "customer_id TEXT(20), " & _
            "customer_name TEXT(50), " & _
            "contract_status TEXT(20), " & _
            "amount CURRENCY, " & _
            "ap_amount CURRENCY, " & _
            "store_id TEXT(10), " & _
            "CONSTRAINT pk_contract PRIMARY KEY(contract_id))"

    ExecSQL "CREATE TABLE sales (" & _
            "sales_id LONG NOT NULL, " & _
            "contract_id LONG, " & _
            "sales_date DATETIME, " & _
            "store_id TEXT(10), " & _
            "amount CURRENCY, " & _
            "CONSTRAINT pk_sales PRIMARY KEY(sales_id))"

    ExecSQL "CREATE TABLE contract_wide (" & _
            "customer_id TEXT(20) NOT NULL, " & _
            "cancer_ap CURRENCY, " & _
            "medical_ap CURRENCY, " & _
            "nursing_ap CURRENCY, " & _
            "CONSTRAINT pk_contract_wide PRIMARY KEY(customer_id))"

    ExecSQL "CREATE TABLE t_exercise (" & _
            "exercise_id LONG NOT NULL, " & _
            "category_name TEXT(60), " & _
            "question_text MEMO, " & _
            "starter_sql MEMO, " & _
            "answer_sql MEMO, " & _
            "explanation_text MEMO, " & _
            "CONSTRAINT pk_t_exercise PRIMARY KEY(exercise_id))"
End Sub

Private Sub InsertData()
    Dim r, rows

    rows = Array( _
        Array("00001", "がん保険", "有効"), _
        Array("00002", "医療保険", "有効"), _
        Array("00003", "介護保険", "有効"))
    For Each r In rows
        ExecSQL "INSERT INTO product VALUES (" & _
                Q(r(0)) & "," & Q(r(1)) & "," & Q(r(2)) & ")"
    Next

    rows = Array( _
        Array("S01", "東京第一支店", "関東"), _
        Array("S02", "東京第二支店", "関東"), _
        Array("S03", "大阪支店", "関西"), _
        Array("S04", "名古屋支店", "中部"))
    For Each r In rows
        ExecSQL "INSERT INTO store VALUES (" & _
                Q(r(0)) & "," & Q(r(1)) & "," & Q(r(2)) & ")"
    Next

    AddContract 1, "04/10/2025", "00001", "がん保険", _
                "C101", "山田太郎", "有効", 10000, "S01"
    AddContract 2, "04/18/2025", "00002", "医療保険", _
                "C102", "佐藤花子", "有効", 8000, "S01"
    AddContract 3, "05/02/2025", "00001", "がん保険", _
                "C103", "テストデータ", "有効", 12000, "S02"
    AddContract 4, "05/20/2025", "00001", "がん保険", _
                "C104", "鈴木一郎", "有効", Null, "S02"
    AddContract 5, "06/15/2025", "00001", "がん保険", _
                "C105", "高橋美咲", "有効", 6000, "S03"
    AddContract 6, "07/01/2025", "00001", "がん保険", _
                "C106", "伊藤健一", "有効", 5000, "S03"

    AddContract 7, "02/01/2026", "00002", "医療保険", _
                "C001", "田中一郎", "有効", 8000, "S01"
    AddContract 8, "02/03/2026", "00001", "がん保険", _
                "C002", "佐々木愛", "有効", 6000, "S01"
    AddContract 9, "02/06/2026", "00001", "がん保険", _
                "C003", "中村健", "有効", 12000, "S02"
    AddContract 10, "02/07/2026", "00003", "介護保険", _
                "C004", "小林美咲", "有効", 3000, "S02"
    AddContract 11, "02/10/2026", "00004", "学資保険", _
                "C005", "加藤誠", "有効", 6000, "S03"
    AddContract 12, "02/11/2026", "00004", "学資保険", _
                "C006", "吉田葵", "有効", 8000, "S03"

    AddSale 101, 1, "04/10/2025", "S01", 6000
    AddSale 102, 1, "04/10/2025", "S01", 4000
    AddSale 103, 2, "04/18/2025", "S01", 8000
    AddSale 104, 3, "05/02/2025", "S02", 7000
    AddSale 105, 3, "05/02/2025", "S02", 5000
    AddSale 106, 5, "06/15/2025", "S03", 6000
    AddSale 107, 6, "07/01/2025", "S03", 5000
    AddSale 108, 7, "02/01/2026", "S01", 8000
    AddSale 109, 8, "02/03/2026", "S01", 3000
    AddSale 110, 8, "02/03/2026", "S01", 3000
    AddSale 111, 9, "02/06/2026", "S02", 7000
    AddSale 112, 9, "02/06/2026", "S02", 5000
    AddSale 113, 10, "02/07/2026", "S02", 3000
    AddSale 114, 11, "02/10/2026", "S03", 6000
    AddSale 115, 12, "02/11/2026", "S03", 5000
    AddSale 116, 12, "02/11/2026", "S03", 3000

    ExecSQL "INSERT INTO contract_wide VALUES ('C001',10000,5000,0)"
    ExecSQL "INSERT INTO contract_wide VALUES ('C002',0,8000,2000)"
    ExecSQL "INSERT INTO contract_wide VALUES ('C003',3000,0,1000)"
End Sub

Private Sub AddContract(ByVal id As Long, ByVal d As String, _
    ByVal pcd As String, ByVal pname As String, _
    ByVal cid As String, ByVal cname As String, _
    ByVal st As String, ByVal amt As Variant, ByVal sid As String)

    Dim a As String
    If IsNull(amt) Then
        a = "NULL"
    Else
        a = CStr(CLng(amt))
    End If

    ExecSQL "INSERT INTO [contract] " & _
        "(contract_id,contract_date,product_code,product_name," & _
        "customer_id,customer_name,contract_status,amount,ap_amount,store_id) " & _
        "VALUES (" & id & ",#" & d & "#," & Q(pcd) & "," & Q(pname) & "," & _
        Q(cid) & "," & Q(cname) & "," & Q(st) & "," & a & "," & a & "," & Q(sid) & ")"
End Sub

Private Sub AddSale(ByVal id As Long, ByVal cid As Long, _
    ByVal d As String, ByVal sid As String, ByVal amt As Long)

    ExecSQL "INSERT INTO sales " & _
        "(sales_id,contract_id,sales_date,store_id,amount) VALUES (" & _
        id & "," & cid & ",#" & d & "#," & Q(sid) & "," & amt & ")"
End Sub

Private Sub CreateSavedQueries()
    CurrentDb.CreateQueryDef "q_sales_by_contract", _
        "SELECT contract_id, SUM(amount) AS contract_sales_amount " & _
        "FROM sales GROUP BY contract_id;"

    CurrentDb.CreateQueryDef "q_active_product", _
        "SELECT product_code, product_name, product_status " & _
        "FROM product WHERE product_status='有効';"

    CurrentDb.CreateQueryDef "q_wide_to_long", _
        "SELECT customer_id,'00001' AS product_code," & _
        "'がん保険' AS product_name,cancer_ap AS amount FROM contract_wide " & _
        "UNION ALL " & _
        "SELECT customer_id,'00002','医療保険',medical_ap FROM contract_wide " & _
        "UNION ALL " & _
        "SELECT customer_id,'00003','介護保険',nursing_ap FROM contract_wide;"
End Sub

Private Sub InsertExercises()
    AddEx 1, "WHERE：複数条件", _
        "2025/4/1～2025/6/30のがん保険のうち、顧客名がテストデータではなく、amountがNULLではない契約を表示してください。", _
        "SELECT contract_date,product_name,amount FROM [contract] " & _
        "WHERE contract_date BETWEEN DateSerial(2025,4,1) AND DateSerial(2025,6,30) " & _
        "AND product_name='がん保険' AND customer_name<>'テストデータ' " & _
        "AND amount IS NOT NULL;", _
        "結果は2件です。AccessではDateSerialを使うと日付形式の曖昧さを避けられます。"

    AddEx 2, "COUNT：全件数", _
        "contractの全件数を求めてください。", _
        "SELECT COUNT(*) AS contract_count FROM [contract];", _
        "COUNT(*)は行数を数えます。"

    AddEx 3, "COUNT：がん保険", _
        "がん保険の契約件数を求めてください。", _
        "SELECT COUNT(*) AS cancer_count FROM [contract] " & _
        "WHERE product_name='がん保険';", _
        "WHEREで絞り込んだ後にCOUNTします。"

    AddEx 4, "SUM：総合計", _
        "新契約APの総合計をtotal_apという列名で求めてください。", _
        "SELECT SUM(ap_amount) AS total_ap FROM [contract];", _
        "SUMはNULLを無視します。"

    AddEx 5, "GROUP BY：商品別", _
        "商品名別に新契約APを合計してください。", _
        "SELECT product_name,SUM(ap_amount) AS total_ap " & _
        "FROM [contract] GROUP BY product_name;", _
        "非集計列product_nameをGROUP BYに指定します。"

    AddEx 6, "GROUP BY：契約日別", _
        "契約日別に新契約APを合計してください。", _
        "SELECT contract_date,SUM(ap_amount) AS total_ap " & _
        "FROM [contract] GROUP BY contract_date;", _
        "契約日が集計単位です。"

    AddEx 7, "sales：店舗別SUM", _
        "salesをstore_id別に集計してください。", _
        "SELECT store_id,SUM(amount) AS total_amount " & _
        "FROM sales GROUP BY store_id;", _
        "AccessのSQL入力欄には--コメントを入れないでください。"

    AddEx 8, "DISTINCT", _
        "顧客IDを重複なしで表示してください。", _
        "SELECT DISTINCT customer_id FROM [contract];", _
        "DISTINCTは重複行を除去します。"

    AddEx 9, "INNER JOIN", _
        "contractとproductを商品コードでINNER JOINしてください。", _
        "SELECT c.contract_date,c.product_code,p.product_name,c.ap_amount " & _
        "FROM [contract] AS c INNER JOIN product AS p " & _
        "ON c.product_code=p.product_code;", _
        "productにない00004は表示されません。"

    AddEx 10, "LEFT JOIN", _
        "contractを左側としてproductへLEFT JOINし、00004も残してください。", _
        "SELECT c.contract_date,c.product_code,p.product_name,c.ap_amount " & _
        "FROM [contract] AS c LEFT JOIN product AS p " & _
        "ON c.product_code=p.product_code;", _
        "00004の商品名はNULLになります。"

    AddEx 11, "LEFT JOIN + WHERE", _
        "全契約を残しながら、有効な商品だけを結合してください。", _
        "SELECT c.contract_date,c.product_code,p.product_name," & _
        "p.product_status,c.ap_amount FROM [contract] AS c " & _
        "LEFT JOIN product AS p ON c.product_code=p.product_code " & _
        "AND p.product_status='有効';", _
        "右表条件をWHEREに置くと、右表がNULLの00004が消えます。"

    AddEx 12, "笛卡尔積", _
        "結合条件なしでcontractとproductを組み合わせてください。", _
        "SELECT c.customer_id,c.ap_amount,p.product_name " & _
        "FROM [contract] AS c,product AS p;", _
        "12件×3商品で36件になります。"

    AddEx 13, "JOIN後の誤集計", _
        "contractとsalesをJOIN後、contract側APをSUMし、重複計上を確認してください。", _
        "SELECT SUM(c.ap_amount) AS wrong_total_ap " & _
        "FROM [contract] AS c INNER JOIN sales AS s " & _
        "ON c.contract_id=s.contract_id;", _
        "1契約に複数明細があるとcontract側APが繰り返されます。"

    AddEx 14, "JOIN + SUM + GROUP BY", _
        "JOIN後、sales.amountを商品名別に合計してください。", _
        "SELECT c.product_name,SUM(s.amount) AS total_ap " & _
        "FROM [contract] AS c INNER JOIN sales AS s " & _
        "ON c.contract_id=s.contract_id GROUP BY c.product_name;", _
        "JOIN後の粒度はsales明細なのでsales.amountを合計します。"

    AddEx 15, "事前集計 + JOIN", _
        "q_sales_by_contractをcontractへJOINして商品別に合計してください。", _
        "SELECT c.product_name,SUM(x.contract_sales_amount) AS total_ap " & _
        "FROM [contract] AS c INNER JOIN q_sales_by_contract AS x " & _
        "ON c.contract_id=x.contract_id GROUP BY c.product_name;", _
        "salesを契約単位へ事前集計してからJOINします。"

    AddEx 16, "横持ち → UNION ALL", _
        "contract_wideを顧客ID・商品コード・商品名・amountの縦持ちに変換してください。", _
        "SELECT customer_id,'00001' AS product_code,'がん保険' AS product_name," & _
        "cancer_ap AS amount FROM contract_wide UNION ALL " & _
        "SELECT customer_id,'00002','医療保険',medical_ap FROM contract_wide UNION ALL " & _
        "SELECT customer_id,'00003','介護保険',nursing_ap FROM contract_wide;", _
        "UNION ALLでは各SELECTの列数とデータ型を合わせます。"

    AddEx 17, "横持ち集計", _
        "q_wide_to_longを使い、商品名別にAPを合計してください。", _
        "SELECT product_name,SUM(amount) AS total_ap " & _
        "FROM q_wide_to_long GROUP BY product_name;", _
        "縦持ちにすると通常のGROUP BYで集計できます。"

    AddEx 18, "SELECTの入れ子", _
        "有効な商品マスタに存在する契約だけを、WHERE内のSELECTで表示してください。", _
        "SELECT contract_id,contract_date,product_code,ap_amount " & _
        "FROM [contract] WHERE product_code IN " & _
        "(SELECT product_code FROM product WHERE product_status='有効');", _
        "内側のSELECTが有効な商品コード一覧を返します。"
End Sub

Private Sub AddEx(ByVal id As Long, ByVal cat As String, _
    ByVal question As String, ByVal answer As String, ByVal explanation As String)

    Dim rs As DAO.Recordset
    Set rs = CurrentDb.OpenRecordset("t_exercise", dbOpenDynaset, dbAppendOnly)

    rs.AddNew
    rs!exercise_id = id
    rs!category_name = cat
    rs!question_text = question
    rs!starter_sql = ""
    rs!answer_sql = answer
    rs!explanation_text = explanation
    rs.Update

    rs.Close
End Sub

Public Function IsSafeSelect(ByVal sqlText As String) As Boolean
    Dim s As String, word, blocked

    s = Trim$(Nz(sqlText, ""))
    If Len(s) = 0 Then Exit Function

    If Right$(s, 1) = ";" Then s = Left$(s, Len(s) - 1)
    If InStr(s, ";") > 0 Then Exit Function

    s = UCase$(Replace(Replace(Replace(s, vbCr, " "), vbLf, " "), vbTab, " "))
    s = " " & Trim$(s) & " "

    If Left$(Trim$(s), 6) <> "SELECT" Then Exit Function

    blocked = Array(" UPDATE ", " DELETE ", " INSERT ", " DROP ", _
                    " ALTER ", " CREATE ", " INTO ", " EXEC ", _
                    " EXECUTE ", " TRANSFORM ", " PARAMETERS ")

    For Each word In blocked
        If InStr(1, s, CStr(word), vbTextCompare) > 0 Then Exit Function
    Next

    IsSafeSelect = True
End Function

Public Sub DeleteQueryIfExists(ByVal queryName As String)
    On Error Resume Next
    DoCmd.Close acQuery, queryName, acSaveNo
    CurrentDb.QueryDefs.Delete queryName
    On Error GoTo 0
End Sub

Private Sub DeleteTableIfExists(ByVal tableName As String)
    On Error Resume Next
    DoCmd.Close acTable, tableName, acSaveNo
    DoCmd.DeleteObject acTable, tableName
    On Error GoTo 0
End Sub

Private Sub ExecSQL(ByVal sqlText As String)
    CurrentDb.Execute sqlText, dbFailOnError
End Sub

Private Function Q(ByVal value As Variant) As String
    Q = "'" & Replace(CStr(value), "'", "''") & "'"
End Function
