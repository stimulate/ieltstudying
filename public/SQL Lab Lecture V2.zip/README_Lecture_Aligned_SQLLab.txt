﻿ACCESS SQL LAB - LECTURE-ALIGNED V2
===================================

This version creates:

Tables:
  product
  contract
  sales
  store
  contract_wide
  t_exercise

Saved queries:
  q_sales_by_contract
  q_active_product
  q_wide_to_long

The 18 exercises have blank starter_sql values, so txtSQL starts empty.

IMPORTANT
---------
Before running the builder, make a backup copy of the ACCDB.
BuildTrainingData deletes and recreates the training data tables and t_exercise.
It does not delete frm_SQLLab or its form VBA.

REPLACE THE MODULE
------------------
1. Close all tables, queries and frm_SQLLab.
2. Press Alt+F11.
3. Find Modules > modSQLLab.
4. Right-click modSQLLab > Remove modSQLLab.
5. Export it first if you want a backup.
6. File > Import File.
7. Import the new modSQLLab.bas.
8. Put the cursor inside Public Sub BuildTrainingData().
9. Press F5.
10. Reopen frm_SQLLab.

If DAO types are not recognized:
Tools > References >
Microsoft Office xx.0 Access database engine Object Library.

KEEP txtSQL EMPTY
-----------------
In Form_frm_SQLLab, use:

Private Sub LoadExercise()
    Dim id As Long

    id = Nz(Me.cboExercise.Value, 0)
    If id = 0 Then Exit Sub

    Me.txtQuestion.Value = Nz( _
        DLookup("question_text", "t_exercise", _
                "exercise_id=" & id), "")

    Me.txtSQL.Value = ""
    Me.txtAnswer.Value = ""
    Me.txtExplanation.Value = ""
End Sub

ACCESS-SPECIFIC CORRECTIONS
---------------------------
1. Use half-width spaces. Do not paste Japanese full-width spaces into SQL.

2. Put spaces between keywords:
   Wrong:
       SELECTCOUNT(*)FROM contract;

   Correct:
       SELECT COUNT(*) FROM [contract];

3. For dates, DateSerial is safest:
       WHERE contract_date
       BETWEEN DateSerial(2025,4,1)
       AND DateSerial(2025,6,30)

4. Access date literals can also use #...#, for example:
       #04/01/2025#
   but month/day order can be confusing on Japanese PCs.

5. Do not put this inside the Access SQL text:
       -- 新契約AP明細

6. JOIN requires ON:
       INNER JOIN product AS p
       ON c.product_code=p.product_code

7. A deliberate Cartesian product can be written:
       FROM [contract] AS c, product AS p

8. The answer SQL uses [contract] with brackets for safety.

CORRECTED LECTURE SQL
---------------------

Multi-condition WHERE:

SELECT
    contract_date,
    product_name,
    amount
FROM
    [contract]
WHERE
    contract_date BETWEEN DateSerial(2025,4,1)
                      AND DateSerial(2025,6,30)
    AND product_name='がん保険'
    AND customer_name<>'テストデータ'
    AND amount IS NOT NULL;

All rows:

SELECT
    COUNT(*) AS contract_count
FROM
    [contract];

Cancer insurance count:

SELECT
    COUNT(*) AS cancer_count
FROM
    [contract]
WHERE
    product_name='がん保険';

Total AP:

SELECT
    SUM(ap_amount) AS total_ap
FROM
    [contract];

AP by product:

SELECT
    product_name,
    SUM(ap_amount) AS total_ap
FROM
    [contract]
GROUP BY
    product_name;

AP by contract date:

SELECT
    contract_date,
    SUM(ap_amount) AS total_ap
FROM
    [contract]
GROUP BY
    contract_date;

Sales amount by store:

SELECT
    store_id,
    SUM(amount) AS total_amount
FROM
    sales
GROUP BY
    store_id;

INNER JOIN:

SELECT
    c.contract_date,
    c.product_code,
    p.product_name,
    c.ap_amount
FROM
    [contract] AS c
    INNER JOIN product AS p
        ON c.product_code=p.product_code;

LEFT JOIN:

SELECT
    c.contract_date,
    c.product_code,
    p.product_name,
    c.ap_amount
FROM
    [contract] AS c
    LEFT JOIN product AS p
        ON c.product_code=p.product_code;

Cartesian product:

SELECT
    c.customer_id,
    c.ap_amount,
    p.product_name
FROM
    [contract] AS c,
    product AS p;

WHY DUPLICATE FIELDS EXIST
--------------------------
The lecture examples query product_name directly from contract and use both
amount and ap_amount in separate examples. This training database deliberately
contains both fields so the lecture SQL can run.

In a real normalized design, product_name would normally be read from product
through product_code, and one consistent AP field name should be used.
