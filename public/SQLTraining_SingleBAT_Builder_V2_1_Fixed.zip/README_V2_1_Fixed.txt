SQL Training Single-BAT Builder - V2.1 Fixed
==================================================

Why V2 Fixed stopped at "first-run setup"
------------------------------------------
The database restore commands were inside:

    if not exist "%TARGET%" (
        ...
    )

Inside a parenthesized batch block, values written with SET are not available
through %VARIABLE% until the block has finished parsing.

Therefore:

    set "PAYLOAD_LINE=..."
    more +%PAYLOAD_LINE% ...

used an empty PAYLOAD_LINE value. MORE could then wait for console input,
which looked like the BAT had frozen.

V2.1 fix
--------
The restore process was moved to:

    :RESTORE_DATABASE

The subroutine runs outside the parenthesized block, so PAYLOAD_LINE and
DECODE_RC are expanded after they are assigned.

No other architecture changes were made.

Build
-----
1. Put SQLTraining_v1.0.accdb in this folder.
2. Run Build_SQLTraining_SingleBAT_V2_1_Fixed.cmd.
3. Distribute SQLTraining_SingleFile_V2_1_Fixed.bat.

Clean test
----------
1. Close all Access windows.
2. Win + R
3. Enter:
   %LOCALAPPDATA%\ADS
4. Delete SQLTraining.
5. Run the generated V2.1 BAT.
6. Confirm stages [1/4] through [4/4].
7. Close Access and run it again.

On the second run, the BAT opens the existing local ACCDB immediately.
