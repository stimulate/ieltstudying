@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion

rem ============================================================
rem SQL Training Single-BAT Builder
rem
rem Usage:
rem   1. Put your ACCDB in the same folder and name it:
rem        SQLTraining_v1.0.accdb
rem      OR drag an ACCDB file onto this CMD.
rem   2. Run this CMD.
rem   3. It creates SQLTraining_SingleFile.bat.
rem
rem certutil and PowerShell are not used.
rem ============================================================

set "DATABASE=%~1"
if not defined DATABASE set "DATABASE=%~dp0SQLTraining_v1.0.accdb"

set "TEMPLATE=%~dp0SingleBAT_Template_NoCertutil.cmd"
set "ENCODER=%~dp0EncodePayload.js"
set "OUTPUT=%~dp0SQLTraining_SingleFile.bat"
set "TEMPBASE64=%TEMP%\SQLTraining_Payload_%RANDOM%_%RANDOM%.b64"

echo.
echo SQL Training用の単一BATを作成します。
echo.

if not exist "%DATABASE%" (
    echo [ERROR] ACCDBファイルが見つかりません。
    echo.
    echo 対象:
    echo %DATABASE%
    echo.
    echo SQLTraining_v1.0.accdbを同じフォルダーに置くか、
    echo ACCDBファイルをこのCMDへドラッグしてください。
    pause
    exit /b 1
)

if not exist "%TEMPLATE%" (
    echo [ERROR] テンプレートが見つかりません。
    echo %TEMPLATE%
    pause
    exit /b 1
)

if not exist "%ENCODER%" (
    echo [ERROR] エンコード用スクリプトが見つかりません。
    echo %ENCODER%
    pause
    exit /b 1
)

where cscript.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] cscript.exeが見つかりません。
    pause
    exit /b 1
)

if exist "%TEMPBASE64%" del /q "%TEMPBASE64%" >nul 2>&1

cscript.exe //nologo "%ENCODER%" "%DATABASE%" "%TEMPBASE64%"
if errorlevel 1 (
    echo.
    echo [ERROR] ACCDBをBase64へ変換できませんでした。
    echo 会社のポリシーでcscript.exeが制限されている可能性があります。
    if exist "%TEMPBASE64%" del /q "%TEMPBASE64%" >nul 2>&1
    pause
    exit /b 1
)

if not exist "%TEMPBASE64%" (
    echo [ERROR] Base64ペイロードが作成されませんでした。
    pause
    exit /b 1
)

copy /B /Y "%TEMPLATE%"+"%TEMPBASE64%" "%OUTPUT%" >nul
if errorlevel 1 (
    echo [ERROR] 単一BATファイルを作成できませんでした。
    del /q "%TEMPBASE64%" >nul 2>&1
    pause
    exit /b 1
)

del /q "%TEMPBASE64%" >nul 2>&1

if not exist "%OUTPUT%" (
    echo [ERROR] 出力ファイルを確認できませんでした。
    pause
    exit /b 1
)

echo.
echo 作成完了:
echo %OUTPUT%
echo.
echo 受講者には次のファイルだけを配布してください。
echo SQLTraining_SingleFile.bat
echo.
pause
endlocal
exit /b 0
