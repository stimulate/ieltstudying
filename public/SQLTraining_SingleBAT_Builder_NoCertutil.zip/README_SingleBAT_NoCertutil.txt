SQL Training Lab - Single BAT Builder (No certutil)
====================================================

目的
----
完成済みのACCDBを、受講者へ配布する1つのBATファイルへ組み込みます。

構築時にも、受講者の実行時にも、以下は使用しません。

- certutil
- PowerShell

代わりにWindows標準のcscript.exe、ADODB.Stream、MSXMLを使用します。

Builderフォルダーの内容
-----------------------
- Build_SQLTraining_SingleBAT_NoCertutil.cmd
- SingleBAT_Template_NoCertutil.cmd
- EncodePayload.js
- SQLTraining_v1.0.accdb  ← 自分で配置

作成方法
--------
方法1:
完成済みACCDBを次の名前でBuilderと同じフォルダーへ置きます。

    SQLTraining_v1.0.accdb

その後、次をダブルクリックします。

    Build_SQLTraining_SingleBAT_NoCertutil.cmd

方法2:
任意の名前のACCDBを
Build_SQLTraining_SingleBAT_NoCertutil.cmdへドラッグします。

作成されるファイル
------------------
    SQLTraining_SingleFile.bat

受講者にはこのBATファイルだけを配布します。

受講者PCでの初回実行
--------------------
1. %LOCALAPPDATA%\ADS\SQLTraining を作成
2. そのフォルダーをAccessの信頼できる場所へ登録
3. BAT内のACCDBを次へ復元
   %LOCALAPPDATA%\ADS\SQLTraining\SQLTraining.accdb
4. MSACCESS.EXEで起動

2回目以降
---------
ローカルACCDBが存在する場合は、すぐにAccessで開きます。

- レジストリを再設定しません
- ACCDBを再復元しません
- 既存のローカルACCDBを上書きしません
- cscript.exeを再実行しません

初期状態へ戻す方法
------------------
Accessを閉じて、次のファイルを削除します。

    %LOCALAPPDATA%\ADS\SQLTraining\SQLTraining.accdb

その後、SQLTraining_SingleFile.batを再実行すると、
初回セットアップが再実行されます。

セキュリティ確認について
------------------------
初回にACCDBを開く前に、保存フォルダーをAccessの
「信頼できる場所」としてHKCUへ登録します。

会社のIntune、Group Policy、Microsoft 365ポリシーで
ユーザーによる信頼できる場所の追加が禁止されている場合は、
BATから登録できません。その場合は処理を停止し、
ACCDBを開きません。

制限
----
- cscript.exe、ADODB.Stream、MSXMLが会社のポリシーで
  制限されている環境では復元できません。
- BAT自体がAppLocker、WDAC、Defender、EDRにより
  ブロックされる場合があります。
- ACCDBは暗号化されていません。
- 知識のある利用者はBATからデータを抽出できます。
- Base64化により、BATは元のACCDBより約33%以上大きくなります。

最初に1台の受講者PCでテストしてください。
