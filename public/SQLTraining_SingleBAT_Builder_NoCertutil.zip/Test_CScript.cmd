@echo off
chcp 65001 >nul
setlocal

set "TESTJS=%TEMP%\SQLTraining_CScript_Test_%RANDOM%_%RANDOM%.js"

> "%TESTJS%" echo WScript.Echo("cscript.exe test: OK");
cscript.exe //nologo "%TESTJS%"
set "RC=%ERRORLEVEL%"

del /q "%TESTJS%" >nul 2>&1

echo.
if "%RC%"=="0" (
    echo cscript.exeは実行可能です。
) else (
    echo cscript.exeを実行できません。
    echo 会社のセキュリティポリシーを確認してください。
)

pause
endlocal
exit /b %RC%
