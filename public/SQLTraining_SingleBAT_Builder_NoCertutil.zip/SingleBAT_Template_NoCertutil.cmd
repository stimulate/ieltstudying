@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion

rem ============================================================
rem SQL Training Lab - Single self-extracting BAT
rem
rem First run:
rem   1. Create the local folder
rem   2. Register it as an Access Trusted Location
rem   3. Restore the embedded ACCDB
rem   4. Open the ACCDB with MSACCESS.EXE
rem
rem Second and later runs:
rem   - If the local ACCDB exists, open it immediately.
rem   - Registry is not changed again.
rem   - The ACCDB is not restored or overwritten.
rem
rem certutil and PowerShell are not used.
rem ============================================================

set "WORKDIR=%LOCALAPPDATA%\ADS\SQLTraining"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "TEMPJS=%TEMP%\SQLTraining_Decode_%RANDOM%_%RANDOM%.js"
set "TRUSTKEY=HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99"

rem ------------------------------------------------------------
rem Second and later launches
rem ------------------------------------------------------------
if exist "%TARGET%" goto OPEN_DATABASE

rem ------------------------------------------------------------
rem First launch
rem ------------------------------------------------------------
echo.
echo SQL Training Labの初回セットアップを開始します。
echo.

if not exist "%WORKDIR%" (
    mkdir "%WORKDIR%" >nul 2>&1
)

if not exist "%WORKDIR%" (
    echo [ERROR] ローカルフォルダーを作成できませんでした。
    echo %WORKDIR%
    pause
    exit /b 1
)

rem Register the trusted location before creating/opening the ACCDB.
reg add "%TRUSTKEY%" /v Path /t REG_SZ /d "%WORKDIR%\" /f >nul 2>&1
if errorlevel 1 goto TRUST_ERROR

reg add "%TRUSTKEY%" /v AllowSubFolders /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 goto TRUST_ERROR

reg add "%TRUSTKEY%" /v Description /t REG_SZ /d "ADS SQL Training Lab" /f >nul 2>&1
if errorlevel 1 goto TRUST_ERROR

echo Accessの信頼できる場所を登録しました。

where cscript.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] cscript.exeが見つかりません。
    pause
    exit /b 1
)

call :WRITE_DECODER "%TEMPJS%"

if not exist "%TEMPJS%" (
    echo [ERROR] 一時デコードスクリプトを作成できませんでした。
    pause
    exit /b 1
)

cscript.exe //nologo "%TEMPJS%" "%~f0" "%TARGET%"
set "DECODE_RC=%ERRORLEVEL%"

del /q "%TEMPJS%" >nul 2>&1

if not "%DECODE_RC%"=="0" (
    echo [ERROR] 内蔵ACCDBを復元できませんでした。
    echo cscript.exe、ADODB.StreamまたはMSXMLが
    echo 会社のポリシーで制限されている可能性があります。
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] 復元後のACCDBを確認できませんでした。
    pause
    exit /b 1
)

echo ACCDBの復元に成功しました。
echo.

goto OPEN_DATABASE

rem ------------------------------------------------------------
rem Open local ACCDB
rem ------------------------------------------------------------
:OPEN_DATABASE

set "ACCESS_EXE="

for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do (
    set "ACCESS_EXE=%%B"
)

if not defined ACCESS_EXE (
    for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do (
        set "ACCESS_EXE=%%B"
    )
)

if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE" (
    set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE"
)

if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE" (
    set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE"
)

if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE" (
    set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE"
)

if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE" (
    set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE"
)

if not defined ACCESS_EXE (
    echo [ERROR] Microsoft Accessが見つかりません。
    echo.
    echo ACCDBの保存先:
    echo %TARGET%
    pause
    exit /b 1
)

echo SQL Training Labを起動します。
start "" "%ACCESS_EXE%" "%TARGET%"

endlocal
exit /b 0

rem ------------------------------------------------------------
rem Trusted Location failure
rem ------------------------------------------------------------
:TRUST_ERROR

echo [ERROR] Accessの信頼できる場所を登録できませんでした。
echo.
echo 会社のセキュリティポリシーで、
echo ユーザーによる登録が禁止されている可能性があります。
echo.
echo データベースはまだ復元していません。
pause

endlocal
exit /b 1

rem ------------------------------------------------------------
rem Create temporary JScript decoder
rem ------------------------------------------------------------
:WRITE_DECODER

> "%~1" echo var args = WScript.Arguments;
>>"%~1" echo if (args.length ^< 2) WScript.Quit(2);
>>"%~1" echo var selfPath = args.Item(0);
>>"%~1" echo var targetPath = args.Item(1);
>>"%~1" echo try {
>>"%~1" echo   var textStream = new ActiveXObject("ADODB.Stream");
>>"%~1" echo   textStream.Type = 2;
>>"%~1" echo   textStream.Charset = "utf-8";
>>"%~1" echo   textStream.Open();
>>"%~1" echo   textStream.LoadFromFile(selfPath);
>>"%~1" echo   var content = textStream.ReadText();
>>"%~1" echo   textStream.Close();
>>"%~1" echo   var marker = ":__SQLTRAINING_PAYLOAD__";
>>"%~1" echo   var pos = content.indexOf(marker);
>>"%~1" echo   if (pos == -1) WScript.Quit(3);
>>"%~1" echo   var base64 = content.substring(pos + marker.length);
>>"%~1" echo   base64 = base64.replace(/\s/g, "");
>>"%~1" echo   var xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
>>"%~1" echo   var node = xml.createElement("base64");
>>"%~1" echo   node.dataType = "bin.base64";
>>"%~1" echo   node.text = base64;
>>"%~1" echo   var bytes = node.nodeTypedValue;
>>"%~1" echo   var binaryStream = new ActiveXObject("ADODB.Stream");
>>"%~1" echo   binaryStream.Type = 1;
>>"%~1" echo   binaryStream.Open();
>>"%~1" echo   binaryStream.Write(bytes);
>>"%~1" echo   binaryStream.SaveToFile(targetPath, 2);
>>"%~1" echo   binaryStream.Close();
>>"%~1" echo   WScript.Quit(0);
>>"%~1" echo } catch (e) {
>>"%~1" echo   WScript.Echo("Decode error: " + e.number + " / " + e.description);
>>"%~1" echo   WScript.Quit(1);
>>"%~1" echo }

exit /b 0

:__SQLTRAINING_PAYLOAD__
