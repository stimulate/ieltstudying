﻿$ErrorActionPreference = "Stop"

#=========================
# CONFIG
#=========================
$tenantId     = "254ed660"
$clientId     = "3209d6f9-c8bacb"
$clientSecret = ""
$siteId       = "ab1e0b57-3335-477c-bb7915b2297"

$folderPath = "新インフラチーム/02.運用/03.運用手順/screensaver_test"

$localFolder  = "C:\ProgramData\CompanyScreensaver"
$manifestFile = "$localFolder\manifest.json"

#=========================
# CREATE LOCAL FOLDER
#=========================
if (!(Test-Path $localFolder)) {
    New-Item -ItemType Directory -Path $localFolder -Force | Out-Null
}

#=========================
# AUTH
#=========================
$tokenBody = @{
    grant_type    = "client_credentials"
    scope         = "https://graph.microsoft.com/.default"
    client_id     = $clientId
    client_secret = $clientSecret
}

$token = (Invoke-RestMethod `
    -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
    -Method POST `
    -Body $tokenBody).access_token

$headers = @{ Authorization = "Bearer $token" }

#=========================
# DRIVE
#=========================
$drive = (Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/sites/$siteId/drives" -Headers $headers).value[0]

#=========================
# GET FILES
#=========================

$uri = "https://graph.microsoft.com/v1.0/drives/" +
       $drive.id +
       "/root:/" +
       $folderPath +
       ":/children"

$response = Invoke-RestMethod -Uri $uri -Headers $headers

$spFiles = $response.value |
    Where-Object { $_.file -ne $null }

#=========================
# CLEAN LOCAL FILES
#=========================
Get-ChildItem $localFolder -File |
    Where-Object Extension -in '.jpg', '.jpeg', '.png' |
    Remove-Item -Force

#=========================
# DOWNLOAD NEW FILES
#=========================
foreach ($file in $spFiles)
{
    $downloadUrl = $file.'@microsoft.graph.downloadUrl'
    $destination = Join-Path $localFolder $file.name

    Invoke-WebRequest -Uri $downloadUrl -OutFile $destination
}

#=========================
# UPDATE MANIFEST
#=========================
$manifest = $spFiles |
    Select-Object name, size, lastModifiedDateTime

$manifest | ConvertTo-Json -Depth 10 | Set-Content $manifestFile -Encoding UTF8

Write-Host "Sync completed"
exit 0