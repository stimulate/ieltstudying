﻿$ErrorActionPreference = "Stop"

$manifestFile = "C:\ProgramData\CompanyScreensaver\manifest.json"

# If manifest doesn't exist → force remediation
if (!(Test-Path $manifestFile)) {
    Write-Output "No manifest found"
    exit 1
}

# Load stored manifest
$localManifest = Get-Content $manifestFile -Raw | ConvertFrom-Json

#=========================
# CONFIG (same as remediation)
#=========================
$tenantId     = "2a400-740c080ed660"
$clientId     = "3209d6f9-1b8a3f2c8bacb"
$clientSecret = "q"
$siteId       = "b57-3335-477"

$folderPath = "新インフラチーム/02.運用/03.運用手順/screensaver_test"

#=========================
# AUTH
#=========================
$tokenBody = @{
    grant_type    = "client_credentials"
    scope         = "https://graph.microsoft.com/.default"
    client_id     = $clientId
    client_secret = $clientSecret
}

$token = (Invoke-RestMethod `
    -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
    -Method POST `
    -Body $tokenBody).access_token

$headers = @{ Authorization = "Bearer $token" }

#=========================
# GET DRIVE
#=========================
$drive = (Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/sites/$siteId/drives" -Headers $headers).value[0]

#=========================
# GET SHAREPOINT FILE LIST
#=========================
$uri = "https://graph.microsoft.com/v1.0/drives/" +
       $drive.id +
       "/root:/" +
       $folderPath +
       ":/children"

$spFiles = (Invoke-RestMethod -Uri $uri -Headers $headers).value |
    Where-Object { $_.file } |
    Select-Object name, size, lastModifiedDateTime

#=========================
# COMPARE STATE
#=========================
# $diff = Compare-Object `
#     -ReferenceObject $localManifest `
#     -DifferenceObject $spFiles `
#     -Property name, size, lastModifiedDateTime

# if ($diff) {
#     Write-Output "Change detected"
#     exit 1
# }

# Write-Output "No changes"
# exit 0

Write-Output "Manifest count: $($localManifest.Count)"
Write-Output "SharePoint count: $($spFiles.Count)"

$diff = Compare-Object `
    -ReferenceObject $localManifest `
    -DifferenceObject $spFiles `
    -Property name,size,lastModifiedDateTime

if ($diff)
{
    Write-Output "Difference:"
    $diff | Out-String | Write-Output
    exit 1
}

Write-Output "No changes"
exit 0