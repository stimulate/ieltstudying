output "dev_account_id" {
  value = aws_organizations_account.eol_dev.id
}

output "dev_account_arn" {
  value = aws_organizations_account.eol_dev.arn
}
