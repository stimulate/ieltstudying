variable "dev_account_email" {
  description = "Unique email address for eol-dev."
  type        = string
}

variable "parent_id" {
  description = "Organizations OU ID (ou-...) or Root ID (r-...)."
  type        = string
}
