variable "management_profile" {
  type    = string
  default = "management"
}

provider "aws" {
  profile = var.management_profile
  region  = "ap-northeast-1"

  default_tags {
    tags = {
      Project   = "eol"
      ManagedBy = "Terraform"
    }
  }
}
