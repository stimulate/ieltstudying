resource "aws_organizations_account" "eol_dev" {
  name      = "eol-dev"
  email     = var.dev_account_email
  parent_id = var.parent_id

  role_name         = "OrganizationAccountAccessRole"
  close_on_deletion = false

  tags = {
    Project     = "eol"
    Environment = "dev"
    ManagedBy   = "Terraform"
  }

  lifecycle {
    prevent_destroy = true
    ignore_changes  = [role_name]
  }
}
