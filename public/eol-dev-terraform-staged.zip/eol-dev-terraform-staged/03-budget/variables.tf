variable "budget_email" {
  type = string
}

variable "monthly_budget_usd" {
  type    = number
  default = 100
}
