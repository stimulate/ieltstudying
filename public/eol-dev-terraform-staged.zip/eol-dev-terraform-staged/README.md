# eol-dev Terraform — staged / per-service version

此版本专门用于**分阶段、分服务 `terraform apply`**。

与上一版最大的区别：

- 每个主要阶段都是独立 Terraform root module。
- 每个阶段使用独立 S3 State。
- 不需要长期依赖 `terraform -target`。
- 后一阶段通过 `terraform_remote_state` 读取前一阶段输出。
- 某个服务出错时，可以停在该阶段排查，不影响其他服务的 State。

## 构筑顺序

```text
00-account
    ↓
01-bootstrap
    ↓
02-dev-dns
    ↓
02b-parent-dns（必要时）
    ↓
03-budget
    ↓
04-s3
    ↓
05-amplify-iam
    ↓
06-amplify
    ↓
07-acm
    ↓
08-cloudfront
    ↓
09-route53-alias
```

依赖关系：

```text
02-dev-dns ───────────→ 07-acm ───────┐
                                       │
04-s3 ─────────────────────────────────┤
                                       ├→ 08-cloudfront → 09-route53-alias
05-amplify-iam → 06-amplify ──────────┤
                                       │
02-dev-dns ────────────────────────────┘
```

`03-budget` 完全独立，可以很早就创建。

---

# 0. 前提

建议：

- Terraform >= 1.10
- AWS CLI v2
- 已存在 Management Account profile，例如 `management`
- 新成员账号 profile 使用 `eol-dev`
- Organization 未使用 Control Tower

先确认：

```bash
aws sts get-caller-identity --profile management
aws organizations describe-organization --profile management
```

---

# 1. 00-account — 创建 eol-dev Member Account

```bash
cd 00-account
cp terraform.tfvars.example terraform.tfvars
```

填写：

```hcl
management_profile = "management"
dev_account_email   = "aws-eol-dev@company.example"
parent_id           = "ou-xxxx-xxxxxxxx"
```

执行：

```bash
terraform init
terraform fmt -check
terraform validate
terraform plan -out=account.tfplan
terraform apply account.tfplan
```

取得 Account ID：

```bash
terraform output -raw dev_account_id
```

然后在 `~/.aws/config` 配置：

```ini
[profile eol-dev]
role_arn = arn:aws:iam::<ACCOUNT_ID>:role/OrganizationAccountAccessRole
source_profile = management
region = ap-northeast-1
output = json
```

验证：

```bash
aws sts get-caller-identity --profile eol-dev
```

---

# 2. 01-bootstrap — Terraform State Bucket

```bash
cd ../01-bootstrap
terraform init
terraform plan -out=bootstrap.tfplan
terraform apply bootstrap.tfplan
terraform output -raw tfstate_bucket
```

Bucket 名为：

```text
eol-dev-<ACCOUNT_ID>-tfstate
```

`00-account` 和 `01-bootstrap` 自己使用 local state，请安全保存，不要提交 Git。

后续 stack 使用 S3 remote state + `use_lockfile=true`。

---

# 3. 初始化任意后续 stack

包内提供：

```text
scripts/init-stack.sh
```

例如：

```bash
./scripts/init-stack.sh 03-budget
./scripts/init-stack.sh 04-s3
```

脚本会：

1. 用 `eol-dev` profile 获取当前 Account ID。
2. 推导 State Bucket：
   `eol-dev-<account-id>-tfstate`
3. 根据 stack 名设置独立 state key。
4. 执行 `terraform init -reconfigure`。

也可以手动 init，README 后面列出了所有 state key。

---

# 4. 02-dev-dns — DEV Hosted Zone

如果 DEV 域名是：

```text
dev.example.com
```

```bash
cd ../02-dev-dns
cp terraform.tfvars.example terraform.tfvars
```

修改域名，然后：

```bash
../scripts/init-stack.sh 02-dev-dns
terraform plan -out=dns.tfplan
terraform apply dns.tfplan
terraform output dev_name_servers
```

---

# 5. 02b-parent-dns — 父域 NS delegation

如果 `example.com` 在另一 AWS Account：

```text
example.com
   └── dev.example.com NS
           → eol-dev Route53 Zone 的4个NS
```

此 stack 是可选的，因为父域可能由其他团队管理。

如果你没有父 DNS Terraform 权限，可以把 4 个 NS 发给 DNS 管理员手工创建。

验证：

```bash
dig NS dev.example.com
```

确认公网 delegation 正常后，再执行 ACM。

---

# 6. 03-budget — 单独创建预算提醒

```bash
cd ../03-budget
cp terraform.tfvars.example terraform.tfvars
../scripts/init-stack.sh 03-budget

terraform plan -out=budget.tfplan
terraform apply budget.tfplan
```

默认：

```text
$100 / month
50% Actual
80% Forecasted
100% Actual
```

Budget 是提醒，不是硬上限。

---

# 7. 04-s3 — 单独创建 S3

```bash
cd ../04-s3
../scripts/init-stack.sh 04-s3

terraform plan -out=s3.tfplan
terraform apply s3.tfplan
```

创建：

```text
eol-dev-<account>-static
eol-dev-<account>-uploads
```

两者：

- Block Public Access
- BucketOwnerEnforced
- Versioning
- SSE-S3

`uploads` 不给 CloudFront 读取。

---

# 8. 05-amplify-iam — 单独创建 Amplify Service Role

```bash
cd ../05-amplify-iam
../scripts/init-stack.sh 05-amplify-iam

terraform plan -out=iam.tfplan
terraform apply iam.tfplan
```

只授予当前 SSR CloudWatch Logs 所需：

```text
logs:CreateLogGroup
logs:CreateLogStream
logs:DescribeLogGroups
logs:PutLogEvents
```

没有附加 `AdministratorAccess-Amplify`。

---

# 9. 06-amplify — 单独创建 Amplify

```bash
cd ../06-amplify
cp terraform.tfvars.example terraform.tfvars
```

设置 Repository 和 Branch。

不要把 GitHub PAT 放进 tfvars：

```bash
export TF_VAR_amplify_access_token="YOUR_TOKEN"
```

然后：

```bash
../scripts/init-stack.sh 06-amplify

terraform plan -out=amplify.tfplan
terraform apply amplify.tfplan
```

检查：

```bash
aws amplify list-apps \
  --region ap-northeast-1 \
  --profile eol-dev
```

如果创建 Branch 后尚未产生首次 Build，可按实际 branch 触发：

```bash
aws amplify start-job \
  --app-id <APP_ID> \
  --branch-name develop \
  --job-type RELEASE \
  --region ap-northeast-1 \
  --profile eol-dev
```

先确保 Amplify 默认域名能够正常打开，再继续 CloudFront。

---

# 10. 07-acm — 单独创建 CloudFront ACM

```bash
cd ../07-acm
../scripts/init-stack.sh 07-acm
```

它会读取：

```text
eol/dev/02-dev-dns.tfstate
```

自动取得 DEV Zone ID。

执行：

```bash
terraform plan -out=acm.tfplan
terraform apply acm.tfplan
```

ACM 创建在：

```text
us-east-1
```

确认：

```bash
terraform output -raw certificate_arn
```

以及：

```bash
aws acm describe-certificate \
  --certificate-arn <ARN> \
  --region us-east-1 \
  --profile eol-dev \
  --query 'Certificate.Status' \
  --output text
```

应为：

```text
ISSUED
```

---

# 11. 08-cloudfront — 单独创建 CloudFront

这个 stack 会读取：

```text
04-s3
06-amplify
07-acm
```

三个独立 State。

```bash
cd ../08-cloudfront
cp terraform.tfvars.example terraform.tfvars
../scripts/init-stack.sh 08-cloudfront

terraform plan -out=cloudfront.tfplan
terraform apply cloudfront.tfplan
```

创建：

- OAC
- CloudFront Distribution
- Static S3 Bucket Policy

默认行为：

```text
default → Amplify SSR
/assets/* → S3 static
```

DEV 对 Amplify 默认使用 `Managed-CachingDisabled`，优先避免动态/登录数据误缓存。

CloudFront 完全部署可能需要十几分钟。

---

# 12. 09-route53-alias — 最后创建业务域名

读取：

```text
02-dev-dns
08-cloudfront
```

执行：

```bash
cd ../09-route53-alias
../scripts/init-stack.sh 09-route53-alias

terraform plan -out=alias.tfplan
terraform apply alias.tfplan
```

创建：

```text
A Alias    → CloudFront
AAAA Alias → CloudFront
```

---

# 13. Smoke Test

```bash
curl -I https://dev.example.com/
```

Static：

```bash
echo "eol-dev test" > /tmp/eol-test.txt

aws s3 cp /tmp/eol-test.txt \
  s3://eol-dev-<ACCOUNT_ID>-static/assets/test.txt \
  --profile eol-dev

curl https://dev.example.com/assets/test.txt
```

CloudFront 应成功。

S3 Object URL 直接读取应失败。

最后逐个 stack：

```bash
terraform plan
```

应为：

```text
No changes.
```

---

# 独立 State Key

| Stack | State key |
|---|---|
| 02-dev-dns | `eol/dev/02-dev-dns.tfstate` |
| 03-budget | `eol/dev/03-budget.tfstate` |
| 04-s3 | `eol/dev/04-s3.tfstate` |
| 05-amplify-iam | `eol/dev/05-amplify-iam.tfstate` |
| 06-amplify | `eol/dev/06-amplify.tfstate` |
| 07-acm | `eol/dev/07-acm.tfstate` |
| 08-cloudfront | `eol/dev/08-cloudfront.tfstate` |
| 09-route53-alias | `eol/dev/09-route53-alias.tfstate` |

这样你可以删除/修改一个服务 Stack，而不会让所有资源共享同一个 State。

---

# 为什么不用 `-target`

临时排错可以：

```bash
terraform apply -target=...
```

但正式 DEV/STG/PROD 不建议把它当部署流程。

此包通过真正拆分 root module/state，实现：

```text
terraform apply
```

本身就只影响当前阶段。

---

# Git

提交：

```text
*.tf
.terraform.lock.hcl
terraform.tfvars.example
README.md
scripts/
```

不要提交：

```text
.terraform/
terraform.tfvars
*.tfstate*
*.tfplan
PAT / Access Key / Secret Key
```

---

# 后续 Prod

DEV 稳定后，可以把这些 stack 抽成 modules：

```text
modules/
  s3/
  amplify/
  acm/
  cloudfront/

environments/
  dev/
  stg/
  prod/
```

但第一次 DEV 构筑阶段，独立 Stack 比过早模块化更容易排错。
