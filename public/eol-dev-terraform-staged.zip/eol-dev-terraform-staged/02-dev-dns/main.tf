resource "aws_route53_zone" "dev" {
  name = var.dev_domain_name
}
