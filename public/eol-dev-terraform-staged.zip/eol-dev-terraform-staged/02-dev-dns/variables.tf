variable "dev_domain_name" {
  description = "DEV public subdomain."
  type        = string
}
