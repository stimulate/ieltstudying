output "dev_zone_id" {
  value = aws_route53_zone.dev.zone_id
}

output "dev_domain_name" {
  value = aws_route53_zone.dev.name
}

output "dev_name_servers" {
  value = aws_route53_zone.dev.name_servers
}
