variable "aws_profile" {
  type    = string
  default = "eol-dev"
}

provider "aws" {
  profile = var.aws_profile
  region  = "ap-northeast-1"
}

provider "aws" {
  alias   = "us_east_1"
  profile = var.aws_profile
  region  = "us-east-1"
}

data "aws_caller_identity" "current" {}

locals {
  tfstate_bucket = "eol-dev-${data.aws_caller_identity.current.account_id}-tfstate"
}
