data "terraform_remote_state" "dns" {
  backend = "s3"

  config = {
    bucket  = local.tfstate_bucket
    key     = "eol/dev/02-dev-dns.tfstate"
    region  = "ap-northeast-1"
    profile = var.aws_profile
  }
}
