variable "s3_path_pattern" {
  type    = string
  default = "/assets/*"
}

variable "cloudfront_price_class" {
  type    = string
  default = "PriceClass_200"

  validation {
    condition = contains(
      ["PriceClass_100", "PriceClass_200", "PriceClass_All"],
      var.cloudfront_price_class
    )
    error_message = "Use PriceClass_100, PriceClass_200, or PriceClass_All."
  }
}
