data "terraform_remote_state" "s3" {
  backend = "s3"
  config = {
    bucket  = local.tfstate_bucket
    key     = "eol/dev/04-s3.tfstate"
    region  = local.tfstate_region
    profile = var.aws_profile
  }
}

data "terraform_remote_state" "amplify" {
  backend = "s3"
  config = {
    bucket  = local.tfstate_bucket
    key     = "eol/dev/06-amplify.tfstate"
    region  = local.tfstate_region
    profile = var.aws_profile
  }
}

data "terraform_remote_state" "acm" {
  backend = "s3"
  config = {
    bucket  = local.tfstate_bucket
    key     = "eol/dev/07-acm.tfstate"
    region  = local.tfstate_region
    profile = var.aws_profile
  }
}
