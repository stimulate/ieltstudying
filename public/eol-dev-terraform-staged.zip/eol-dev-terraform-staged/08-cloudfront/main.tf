resource "aws_cloudfront_origin_access_control" "static" {
  name                              = "eol-dev-static-oac"
  description                       = "OAC for eol-dev static assets"
  origin_access_control_origin_type = "s3"
  signing_behavior                  = "always"
  signing_protocol                  = "sigv4"
}

data "aws_cloudfront_cache_policy" "s3" {
  name = "Managed-CachingOptimized"
}

data "aws_cloudfront_cache_policy" "amplify_dev" {
  name = "Managed-CachingDisabled"
}

data "aws_cloudfront_origin_request_policy" "amplify" {
  name = "Managed-AllViewerExceptHostHeader"
}

resource "aws_cloudfront_distribution" "main" {
  enabled         = true
  is_ipv6_enabled = true
  comment         = "eol-dev"
  price_class     = var.cloudfront_price_class

  origin {
    domain_name              = data.terraform_remote_state.s3.outputs.static_bucket_regional_domain_name
    origin_id                = "s3-static"
    origin_access_control_id = aws_cloudfront_origin_access_control.static.id
  }

  origin {
    domain_name = data.terraform_remote_state.amplify.outputs.amplify_branch_origin_domain
    origin_id   = "amplify-ssr"

    custom_origin_config {
      http_port              = 80
      https_port             = 443
      origin_protocol_policy = "https-only"
      origin_ssl_protocols   = ["TLSv1.2"]
    }
  }

  default_cache_behavior {
    target_origin_id       = "amplify-ssr"
    viewer_protocol_policy = "redirect-to-https"

    allowed_methods = [
      "GET", "HEAD", "OPTIONS", "PUT", "POST", "PATCH", "DELETE"
    ]

    cached_methods = ["GET", "HEAD"]

    cache_policy_id          = data.aws_cloudfront_cache_policy.amplify_dev.id
    origin_request_policy_id = data.aws_cloudfront_origin_request_policy.amplify.id
    compress                 = true
  }

  ordered_cache_behavior {
    path_pattern           = var.s3_path_pattern
    target_origin_id       = "s3-static"
    viewer_protocol_policy = "redirect-to-https"

    allowed_methods = ["GET", "HEAD"]
    cached_methods  = ["GET", "HEAD"]

    cache_policy_id = data.aws_cloudfront_cache_policy.s3.id
    compress        = true
  }

  restrictions {
    geo_restriction {
      restriction_type = "none"
    }
  }

  viewer_certificate {
    acm_certificate_arn      = data.terraform_remote_state.acm.outputs.certificate_arn
    ssl_support_method       = "sni-only"
    minimum_protocol_version = "TLSv1.2_2021"
  }
}

data "aws_iam_policy_document" "static_cloudfront" {
  statement {
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["cloudfront.amazonaws.com"]
    }

    actions = ["s3:GetObject"]

    resources = [
      "${data.terraform_remote_state.s3.outputs.static_bucket_arn}/*"
    ]

    condition {
      test     = "StringEquals"
      variable = "AWS:SourceArn"
      values   = [aws_cloudfront_distribution.main.arn]
    }
  }
}

resource "aws_s3_bucket_policy" "static" {
  bucket = data.terraform_remote_state.s3.outputs.static_bucket_name
  policy = data.aws_iam_policy_document.static_cloudfront.json
}
