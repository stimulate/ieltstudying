data "aws_route53_zone" "parent" {
  name         = var.parent_zone_name
  private_zone = false
}

resource "aws_route53_record" "dev_delegation" {
  zone_id = data.aws_route53_zone.parent.zone_id
  name    = var.dev_domain_name
  type    = "NS"
  ttl     = 300
  records = var.dev_name_servers
}
