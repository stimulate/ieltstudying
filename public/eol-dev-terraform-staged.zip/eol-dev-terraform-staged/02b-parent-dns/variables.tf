variable "parent_zone_name" {
  type = string
}

variable "dev_domain_name" {
  type = string
}

variable "dev_name_servers" {
  type = list(string)

  validation {
    condition     = length(var.dev_name_servers) == 4
    error_message = "Exactly four Route53 name servers are required."
  }
}
