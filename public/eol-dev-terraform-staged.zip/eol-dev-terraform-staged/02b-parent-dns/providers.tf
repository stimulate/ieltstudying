variable "parent_dns_profile" {
  type = string
}

provider "aws" {
  profile = var.parent_dns_profile
  region  = "ap-northeast-1"
}
