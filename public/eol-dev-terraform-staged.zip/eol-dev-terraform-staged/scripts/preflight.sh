#!/usr/bin/env bash
set -euo pipefail

echo "== AWS CLI =="
aws --version

echo
echo "== Terraform =="
terraform version

echo
echo "== eol-dev identity =="
aws sts get-caller-identity --profile eol-dev

echo
echo "== Profiles =="
aws configure list-profiles
