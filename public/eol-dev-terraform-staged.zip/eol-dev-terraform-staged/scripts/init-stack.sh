#!/usr/bin/env bash
set -euo pipefail

STACK="${1:-}"
PROFILE="${AWS_PROFILE:-eol-dev}"
REGION="ap-northeast-1"

if [[ -z "$STACK" ]]; then
  echo "Usage: $0 <stack>"
  exit 1
fi

case "$STACK" in
  02-dev-dns)        KEY="eol/dev/02-dev-dns.tfstate" ;;
  03-budget)         KEY="eol/dev/03-budget.tfstate" ;;
  04-s3)             KEY="eol/dev/04-s3.tfstate" ;;
  05-amplify-iam)    KEY="eol/dev/05-amplify-iam.tfstate" ;;
  06-amplify)        KEY="eol/dev/06-amplify.tfstate" ;;
  07-acm)            KEY="eol/dev/07-acm.tfstate" ;;
  08-cloudfront)     KEY="eol/dev/08-cloudfront.tfstate" ;;
  09-route53-alias)  KEY="eol/dev/09-route53-alias.tfstate" ;;
  *)
    echo "Unsupported stack: $STACK"
    exit 1
    ;;
esac

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
STACK_DIR="$ROOT_DIR/$STACK"

if [[ ! -d "$STACK_DIR" ]]; then
  echo "Stack directory not found: $STACK_DIR"
  exit 1
fi

ACCOUNT_ID="$(
  aws sts get-caller-identity \
    --profile "$PROFILE" \
    --query Account \
    --output text
)"

BUCKET="eol-dev-${ACCOUNT_ID}-tfstate"

echo "Profile : $PROFILE"
echo "Account : $ACCOUNT_ID"
echo "Bucket  : $BUCKET"
echo "State   : $KEY"
echo "Stack   : $STACK_DIR"

terraform -chdir="$STACK_DIR" init -reconfigure \
  -backend-config="bucket=$BUCKET" \
  -backend-config="key=$KEY" \
  -backend-config="region=$REGION" \
  -backend-config="profile=$PROFILE" \
  -backend-config="use_lockfile=true"
