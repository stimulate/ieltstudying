#!/usr/bin/env bash
set -euo pipefail

STACK="${1:-}"
if [[ -z "$STACK" ]]; then
  echo "Usage: $0 <stack>"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

"$SCRIPT_DIR/init-stack.sh" "$STACK"

terraform -chdir="$ROOT_DIR/$STACK" fmt -check
terraform -chdir="$ROOT_DIR/$STACK" validate
terraform -chdir="$ROOT_DIR/$STACK" plan -out="${STACK}.tfplan"

echo
echo "Plan created:"
echo "  $ROOT_DIR/$STACK/${STACK}.tfplan"
echo
echo "Apply after review:"
echo "  terraform -chdir=\"$ROOT_DIR/$STACK\" apply \"${STACK}.tfplan\""
