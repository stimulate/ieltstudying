output "amplify_app_id" {
  value = aws_amplify_app.web.id
}

output "amplify_default_domain" {
  value = aws_amplify_app.web.default_domain
}

output "amplify_branch_name" {
  value = aws_amplify_branch.dev.branch_name
}

output "amplify_branch_origin_domain" {
  value = "${aws_amplify_branch.dev.branch_name}.${aws_amplify_app.web.default_domain}"
}
