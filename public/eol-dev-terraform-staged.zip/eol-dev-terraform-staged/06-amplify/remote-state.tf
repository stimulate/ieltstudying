data "terraform_remote_state" "iam" {
  backend = "s3"

  config = {
    bucket  = local.tfstate_bucket
    key     = "eol/dev/05-amplify-iam.tfstate"
    region  = local.tfstate_region
    profile = var.aws_profile
  }
}
