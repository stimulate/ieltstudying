variable "aws_profile" {
  description = "AWS CLI profile for the eol-dev member account."
  type        = string
  default     = "eol-dev"
}

provider "aws" {
  profile = var.aws_profile
  region  = "ap-northeast-1"

  default_tags {
    tags = {
      Project     = "eol"
      Environment = "dev"
      ManagedBy   = "Terraform"
    }
  }
}

data "aws_caller_identity" "current" {}


locals {
  tfstate_bucket = "eol-dev-${data.aws_caller_identity.current.account_id}-tfstate"
  tfstate_region = "ap-northeast-1"
}
