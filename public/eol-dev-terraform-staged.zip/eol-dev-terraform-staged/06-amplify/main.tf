resource "aws_amplify_app" "web" {
  name       = "eol-dev-web"
  repository = var.repository_url

  # Required only for initial repository connection.
  # The AWS provider documentation states that the token is not stored by Amplify.
  access_token = var.amplify_access_token

  platform             = "WEB_COMPUTE"
  iam_service_role_arn = data.terraform_remote_state.iam.outputs.amplify_service_role_arn

  enable_branch_auto_deletion = true

  environment_variables = {
    APP_ENV = "dev"
  }
}

resource "aws_amplify_branch" "dev" {
  app_id      = aws_amplify_app.web.id
  branch_name = var.amplify_branch
  framework   = "Next.js - SSR"
  stage       = "DEVELOPMENT"

  enable_auto_build = true

  environment_variables = {
    APP_ENV = "dev"
  }
}
