variable "repository_url" {
  type = string
}

variable "amplify_branch" {
  type    = string
  default = "develop"
}

variable "amplify_access_token" {
  type      = string
  sensitive = true
}
