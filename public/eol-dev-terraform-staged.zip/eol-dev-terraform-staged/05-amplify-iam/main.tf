data "aws_iam_policy_document" "amplify_assume" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["amplify.amazonaws.com"]
    }

    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = [data.aws_caller_identity.current.account_id]
    }

    condition {
      test     = "ArnLike"
      variable = "aws:SourceArn"
      values = [
        "arn:aws:amplify:ap-northeast-1:${data.aws_caller_identity.current.account_id}:apps/*"
      ]
    }
  }
}

resource "aws_iam_role" "amplify_service" {
  name               = "eol-dev-amplify-service-role"
  assume_role_policy = data.aws_iam_policy_document.amplify_assume.json
  description        = "Amplify SSR CloudWatch Logs service role for eol-dev."
}

data "aws_iam_policy_document" "amplify_logs" {
  statement {
    effect = "Allow"

    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:DescribeLogGroups",
      "logs:PutLogEvents",
    ]

    resources = ["*"]
  }
}

resource "aws_iam_role_policy" "amplify_logs" {
  name   = "eol-dev-amplify-ssr-logs"
  role   = aws_iam_role.amplify_service.id
  policy = data.aws_iam_policy_document.amplify_logs.json
}
