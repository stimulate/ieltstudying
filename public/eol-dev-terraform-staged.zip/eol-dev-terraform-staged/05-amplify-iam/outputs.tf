output "amplify_service_role_arn" {
  value = aws_iam_role.amplify_service.arn
}
