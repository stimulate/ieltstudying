output "dev_url" {
  value = "https://${data.terraform_remote_state.dns.outputs.dev_domain_name}"
}
