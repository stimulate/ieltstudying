resource "aws_route53_record" "app_a" {
  zone_id = data.terraform_remote_state.dns.outputs.dev_zone_id
  name    = data.terraform_remote_state.dns.outputs.dev_domain_name
  type    = "A"

  alias {
    name                   = data.terraform_remote_state.cloudfront.outputs.distribution_domain_name
    zone_id                = data.terraform_remote_state.cloudfront.outputs.distribution_hosted_zone_id
    evaluate_target_health = false
  }
}

resource "aws_route53_record" "app_aaaa" {
  zone_id = data.terraform_remote_state.dns.outputs.dev_zone_id
  name    = data.terraform_remote_state.dns.outputs.dev_domain_name
  type    = "AAAA"

  alias {
    name                   = data.terraform_remote_state.cloudfront.outputs.distribution_domain_name
    zone_id                = data.terraform_remote_state.cloudfront.outputs.distribution_hosted_zone_id
    evaluate_target_health = false
  }
}
