data "terraform_remote_state" "dns" {
  backend = "s3"
  config = {
    bucket  = local.tfstate_bucket
    key     = "eol/dev/02-dev-dns.tfstate"
    region  = local.tfstate_region
    profile = var.aws_profile
  }
}

data "terraform_remote_state" "cloudfront" {
  backend = "s3"
  config = {
    bucket  = local.tfstate_bucket
    key     = "eol/dev/08-cloudfront.tfstate"
    region  = local.tfstate_region
    profile = var.aws_profile
  }
}
