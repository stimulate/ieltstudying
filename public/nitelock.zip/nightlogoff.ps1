#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Lite - 強制ログオフ＆ログオン拒否スクリプト v1.1
.DESCRIPTION
    2 つのタスクから呼ばれる唯一の実行スクリプト:
      - NightLockLite-MinuteCheck : 1 分毎に定期実行（既存セッションを監視）
      - NightLockLite-OnLogon     : ユーザーログオン直後に実行（ログイン拒否）

    ★ 時刻判定は (Get-Date).Hour を使用 → 常にPC のローカル時刻で判断
       トリガー時刻のタイムゾーン設定に依存しない

    ★ ロックファイルで多重実行を防止
       （MinuteCheck と OnLogon が同時に走っても競合しない）
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "SilentlyContinue"

# ── 定数（ここを変更して制限時間帯・警告秒数・除外アカウントを設定）─────────

# 制限開始時刻（24 時間表記）
$RESTRICT_START = 22   # 22:00

# 制限終了時刻（24 時間表記）
$RESTRICT_END   = 5    # 05:00

# ログオフ前の警告ポップアップ表示秒数
# 0 にすると即時ログオフ（警告なし）
$WARNING_SECONDS = 30

# 常時除外するアカウント（SAM アカウント名で記載）
# 夜間作業が必要な IT 管理者などを追加する
$PERMANENT_EXEMPTIONS = @(
    "Administrator"
)

# ── パス ──────────────────────────────────────────────────────────────────────
$INSTALL_DIR = "C:\ProgramData\NightLockLite"
$LOG_DIR     = "$INSTALL_DIR\logs"
$KILL_SWITCH = "$INSTALL_DIR\MAINTENANCE_MODE"
$LOCK_FILE   = "$INSTALL_DIR\nightlogoff.lock"

# ── ログ関数 ──────────────────────────────────────────────────────────────────
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts      = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line    = "[$ts][$Level] $Message"
    Write-Output $line
    $logFile = "$LOG_DIR\nightlogoff-$(Get-Date -Format 'yyyyMM').log"
    Add-Content -Path $logFile -Value $line -Encoding UTF8
    # 3 ヶ月以上前のログを自動削除
    Get-ChildItem "$LOG_DIR\nightlogoff-*.log" -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt (Get-Date).AddMonths(-3) } |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

# ── 多重実行防止ロック ────────────────────────────────────────────────────────
# MinuteCheck と OnLogon が同時に呼ばれた場合に競合を防ぐ
function Get-Lock {
    if (Test-Path $LOCK_FILE) {
        $age = (Get-Date) - (Get-Item $LOCK_FILE).LastWriteTime
        if ($age.TotalMinutes -lt 5) {
            Write-Log "Another instance is running (lock age: $([int]$age.TotalSeconds)s). Skipping."
            return $false
        }
        # 5 分以上古いロックは異常終了の残骸とみなして削除
        Remove-Item $LOCK_FILE -Force -ErrorAction SilentlyContinue
        Write-Log "Stale lock removed." "WARN"
    }
    New-Item $LOCK_FILE -ItemType File -Force | Out-Null
    return $true
}

function Release-Lock {
    Remove-Item $LOCK_FILE -Force -ErrorAction SilentlyContinue
}

# ── 制限時間帯チェック（ローカル時刻で判定）──────────────────────────────────
function Test-RestrictedHours {
    # (Get-Date).Hour は PC のローカルタイムゾーンの時刻を返す
    # タスクスケジューラのトリガー時刻設定とは完全に独立
    $hour = (Get-Date).Hour
    $result = ($hour -ge $RESTRICT_START) -or ($hour -lt $RESTRICT_END)
    Write-Log "Local time: $(Get-Date -Format 'HH:mm') | Restricted: $result"
    return $result
}

# ── アクティブセッション取得 ──────────────────────────────────────────────────
function Get-ActiveSessions {
    $sessions = @()
    try {
        $raw = quser 2>&1
        if ($LASTEXITCODE -ne 0) { return $sessions }
        foreach ($line in $raw) {
            if ($line -match "^\s*USERNAME") { continue }
            # quser: USERNAME  SESSIONNAME  ID  STATE  IDLE TIME  LOGON TIME
            if ($line -match "^\s*>?(\S+)\s+\S*\s+(\d+)\s+(\S+)") {
                $sessions += [PSCustomObject]@{
                    Username  = $Matches[1]
                    SessionId = [int]$Matches[2]
                    State     = $Matches[3]
                }
            }
        }
    }
    catch {
        Write-Log "quser error: $($_.Exception.Message)" "WARN"
    }
    return $sessions
}

# ── 警告ポップアップ ──────────────────────────────────────────────────────────
function Send-Warning {
    param([int]$SessionId, [string]$Username)
    $msg = "【NightLock 警告 / Warning】`n`n" +
           "このPCは夜間（$($RESTRICT_START):00 〜 $($RESTRICT_END):00）は利用できません。`n" +
           "${WARNING_SECONDS}秒後に自動ログオフされます。`n" +
           "作業中のファイルを保存してください。`n`n" +
           "This PC is restricted from $($RESTRICT_START):00 to $($RESTRICT_END):00.`n" +
           "You will be logged off in ${WARNING_SECONDS} seconds.`n" +
           "Please save your work now."
    try {
        msg $SessionId /TIME:$WARNING_SECONDS $msg 2>&1 | Out-Null
        Write-Log "  Warning sent to: $Username (session $SessionId)"
    }
    catch {
        Write-Log "  msg.exe failed for session $SessionId" "WARN"
    }
}

# ── ログオフ実行 ──────────────────────────────────────────────────────────────
function Invoke-Logoff {
    param([int]$SessionId, [string]$Username)
    logoff $SessionId 2>&1 | Out-Null
    Write-Log "  LOGOFF executed: $Username (session $SessionId)" "WARN"
    Write-EventLog -LogName Application -Source "NightLockLite" -EventId 4001 `
        -EntryType Warning `
        -Message "NightLock Lite: Forced logoff | User=$Username Session=$SessionId Time=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" `
        -ErrorAction SilentlyContinue
}

# ── Main ─────────────────────────────────────────────────────────────────────
Write-Log "===== Check START (caller: $($MyInvocation.ScriptName | Split-Path -Leaf)) ====="

# メンテナンスモード（MAINTENANCE_MODE ファイルがあれば全処理停止）
if (Test-Path $KILL_SWITCH) {
    Write-Log "MAINTENANCE MODE active. All enforcement suspended." "WARN"
    exit 0
}

# 制限時間帯でなければ即終了（1 分毎タスクはほぼここで終わる）
if (!(Test-RestrictedHours)) {
    Write-Log "Not in restricted hours. No action."
    Write-Log "===== Check END ====="
    exit 0
}

# ロック取得（別タスクが既に実行中なら終了）
if (!(Get-Lock)) {
    exit 0
}

try {
    # 除外アカウントを HashSet に変換（大文字小文字を無視）
    $exemptSet = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )
    foreach ($u in $PERMANENT_EXEMPTIONS) { $exemptSet.Add($u) | Out-Null }
    Write-Log "Exempt accounts: $($PERMANENT_EXEMPTIONS -join ', ')"

    $sessions = Get-ActiveSessions
    Write-Log "Sessions found: $($sessions.Count)"

    if ($sessions.Count -eq 0) {
        Write-Log "No active sessions."
        Write-Log "===== Check END ====="
        exit 0
    }

    foreach ($session in $sessions) {
        $user = $session.Username
        Write-Log "Checking: $user | session=$($session.SessionId) state=$($session.State)"

        # 除外アカウントはスキップ
        if ($exemptSet.Contains($user)) {
            Write-Log "  EXEMPT - skipping: $user"
            continue
        }

        # Windows 組み込みシステムセッションはスキップ
        if ($user -match "^(SYSTEM|DWM-\d+|UMFD-\d+)$") {
            Write-Log "  System session - skipping: $user"
            continue
        }

        # 警告 → 待機 → 強制ログオフ
        if ($WARNING_SECONDS -gt 0) {
            Send-Warning -SessionId $session.SessionId -Username $user
            Start-Sleep -Seconds $WARNING_SECONDS
        }
        Invoke-Logoff -SessionId $session.SessionId -Username $user
    }
}
finally {
    Release-Lock
}

Write-Log "===== Check END ====="
exit 0
