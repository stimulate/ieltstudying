#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Lite - インストーラー v1.1（タイムゾーン修正・1分毎チェック版）
.DESCRIPTION
    修正点（v1.0 → v1.1）:
      1. タスク登録を XML 方式に変更 → タイムゾーン依存の Bug を根本排除
      2. チェック間隔を 10 分 → 1 分に短縮
      3. logincheck.ps1 を廃止。OnLogon タスクも nightlogoff.ps1 を直接呼ぶ
      4. 時刻判定はスクリプト内で (Get-Date).Hour を使用（常にローカル時間）
.VERSION
    1.1.0
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$INSTALL_DIR     = "C:\ProgramData\NightLockLite"
$SCRIPT_DIR      = "$INSTALL_DIR\scripts"
$LOG_DIR         = "$INSTALL_DIR\logs"
$VERSION_FILE    = "$INSTALL_DIR\version.txt"
$CURRENT_VERSION = "1.1.0"
$SOURCE_DIR      = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts][$Level] $Message"
    Write-Output $line
    if (!(Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR -Force | Out-Null }
    Add-Content -Path "$LOG_DIR\install.log" -Value $line -Encoding UTF8
}

function Test-AlreadyInstalled {
    if (Test-Path $VERSION_FILE) {
        if ((Get-Content $VERSION_FILE -Raw).Trim() -eq $CURRENT_VERSION) {
            Write-Log "Version $CURRENT_VERSION already installed. Skipping."
            return $true
        }
    }
    return $false
}

function Initialize-Directories {
    Write-Log "Creating directories..."
    @($INSTALL_DIR, $SCRIPT_DIR, $LOG_DIR) | ForEach-Object {
        if (!(Test-Path $_)) { New-Item -ItemType Directory -Path $_ -Force | Out-Null }
    }
    # SYSTEM + Administrators のみ書き込み可（社員による改ざん防止）
    $acl = Get-Acl $INSTALL_DIR
    $acl.SetAccessRuleProtection($true, $false)
    $acl.Access | ForEach-Object { $acl.RemoveAccessRule($_) | Out-Null }
    foreach ($id in @("SYSTEM", "BUILTIN\Administrators")) {
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $id, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow"
        )
        $acl.AddAccessRule($rule)
    }
    Set-Acl -Path $INSTALL_DIR -AclObject $acl
    Write-Log "Directory ACL secured."
}

function Copy-Scripts {
    Write-Log "Copying scripts..."
    $src = Join-Path $SOURCE_DIR "scripts\nightlogoff.ps1"
    $dst = Join-Path $SCRIPT_DIR "nightlogoff.ps1"
    if (!(Test-Path $src)) { throw "nightlogoff.ps1 not found in package: $src" }
    Copy-Item -Path $src -Destination $dst -Force
    Write-Log "  Copied: nightlogoff.ps1"
    # logincheck.ps1 は v1.1 で廃止。両タスクとも nightlogoff.ps1 を直接呼ぶ。
}

function Register-ScheduledTasks {
    Write-Log "Registering Scheduled Tasks (XML method)..."

    # ── 重要: XML 方式を使う理由 ─────────────────────────────────────────────
    # PowerShell の New-ScheduledTaskTrigger は SYSTEM コンテキストで
    # タイムゾーンを誤解釈する既知の不具合がある。
    # XML 方式は Task Scheduler のネイティブ形式で、ローカル時刻として確実に登録される。
    # さらに、時刻判定をスクリプト内部（(Get-Date).Hour）で行うため、
    # トリガー時刻のタイムゾーン問題に左右されない。
    # ─────────────────────────────────────────────────────────────────────────

    $scriptPath = "$SCRIPT_DIR\nightlogoff.ps1"

    # 旧バージョンのタスクを削除（v1.0 からのアップグレード対応）
    @(
        "NightLockLite-LogoffAt2200",
        "NightLockLite-IntervalCheck",
        "NightLockLite-OnLogon",
        "NightLockLite-MinuteCheck"
    ) | ForEach-Object {
        Unregister-ScheduledTask -TaskName $_ -Confirm:$false -ErrorAction SilentlyContinue
    }

    # ── Task 1: 1 分毎チェック（24 時間 365 日）──────────────────────────────
    # StartBoundary を過去日付にすることで即時開始。
    # PT1M = 1 分間隔、StopAtDurationEnd=false = 無期限繰り返し。
    # 制限時間帯かどうかの判定は nightlogoff.ps1 の内部ロジックで行う。
    $t1Name = "NightLockLite-MinuteCheck"
    $t1Xml  = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>NightLock Lite: 夜間アクセス制限チェック（1分毎、制限時間帯の判定はスクリプト内部）</Description>
  </RegistrationInfo>
  <Triggers>
    <TimeTrigger>
      <Repetition>
        <Interval>PT1M</Interval>
        <StopAtDurationEnd>false</StopAtDurationEnd>
      </Repetition>
      <StartBoundary>2000-01-01T00:00:00</StartBoundary>
      <Enabled>true</Enabled>
    </TimeTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>S-1-5-18</UserId>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <ExecutionTimeLimit>PT5M</ExecutionTimeLimit>
    <Priority>7</Priority>
    <Enabled>true</Enabled>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>powershell.exe</Command>
      <Arguments>-NonInteractive -NoProfile -ExecutionPolicy Bypass -File "$scriptPath"</Arguments>
    </Exec>
  </Actions>
</Task>
"@
    Register-ScheduledTask -TaskName $t1Name -Xml $t1Xml -Force | Out-Null
    Write-Log "  Registered: $t1Name (every 1 minute, time check inside script)"

    # ── Task 2: ユーザーがログオンした瞬間に即時チェック ─────────────────────
    # ログオン後 5 秒待ってからセッションが確立した状態で nightlogoff.ps1 を実行。
    # Parallel = 複数ユーザーが同時ログオンしても全員分のチェックを実行する。
    $t2Name = "NightLockLite-OnLogon"
    $t2Xml  = @"
<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.4" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>NightLock Lite: ログオン時即時アクセスチェック</Description>
  </RegistrationInfo>
  <Triggers>
    <LogonTrigger>
      <Delay>PT5S</Delay>
      <Enabled>true</Enabled>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>S-1-5-18</UserId>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>Parallel</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <ExecutionTimeLimit>PT2M</ExecutionTimeLimit>
    <Priority>0</Priority>
    <Enabled>true</Enabled>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>powershell.exe</Command>
      <Arguments>-NonInteractive -NoProfile -ExecutionPolicy Bypass -File "$scriptPath"</Arguments>
    </Exec>
  </Actions>
</Task>
"@
    Register-ScheduledTask -TaskName $t2Name -Xml $t2Xml -Force | Out-Null
    Write-Log "  Registered: $t2Name (at logon, 5s delay)"
}

function Register-EventSource {
    if (![System.Diagnostics.EventLog]::SourceExists("NightLockLite")) {
        New-EventLog -LogName Application -Source "NightLockLite" -ErrorAction SilentlyContinue
    }
}

function Write-VersionMarker {
    Set-Content -Path $VERSION_FILE -Value $CURRENT_VERSION -Encoding ASCII
    Write-Log "Version marker written: $CURRENT_VERSION"
}

try {
    Write-Log "================================================"
    Write-Log " NightLock Lite Installer v$CURRENT_VERSION"
    Write-Log "================================================"

    if (Test-AlreadyInstalled) { exit 0 }

    Initialize-Directories
    Copy-Scripts
    Register-ScheduledTasks
    Register-EventSource
    Write-VersionMarker

    Write-Log "Installation completed successfully."
    exit 0
}
catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log $_.ScriptStackTrace "ERROR"
    exit 1
}
