#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Lite - アンインストーラー v1.1
#>

$INSTALL_DIR = "C:\ProgramData\NightLockLite"

# v1.0 と v1.1 両方のタスク名を削除対象にする（バージョン混在環境への対応）
$TASK_NAMES = @(
    "NightLockLite-MinuteCheck",   # v1.1
    "NightLockLite-OnLogon",       # v1.0 / v1.1
    "NightLockLite-LogoffAt2200",  # v1.0（旧名）
    "NightLockLite-IntervalCheck"  # v1.0（旧名）
)

function Write-Log { param([string]$m)
    Write-Output "[$(Get-Date -Format 'HH:mm:ss')] $m"
}

Write-Log "=== NightLock Lite Uninstall START ==="

foreach ($name in $TASK_NAMES) {
    Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue
    Write-Log "Task removed (if existed): $name"
}

if (Test-Path $INSTALL_DIR) {
    Remove-Item -Path $INSTALL_DIR -Recurse -Force -ErrorAction SilentlyContinue
    Write-Log "Removed: $INSTALL_DIR"
}

Remove-EventLog -Source "NightLockLite" -ErrorAction SilentlyContinue
Write-Log "Event source removed."

Write-Log "=== NightLock Lite Uninstall END ==="
