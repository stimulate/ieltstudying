SQL Training Lab Final Fix (2026-09-15)

Important:
The current conversation does NOT contain the actual ACCDB binary, so I cannot safely modify the binary ACCDB itself here.
Instead, this package contains:
1) modSQLLab_FinalFix.bas
   - Apply to the existing ACCDB.
   - Run ApplyFinalFix once.
2) modSQLLab_V3_Rebuild_Final.bas
   - Updated full rebuild source if you prefer rebuilding the database.

Changes:
- q_active_contract now uses FROM contract, not t_contract.
- product 00004 is deleted if present.
- Q1 starts with 「contractテーブルより、」
- Displayed SQL no longer uses [contract].
- Q9 explanation matches the intended orphan contract 00004.
- Q11 changes AND in JOIN to WHERE.
- Q18 now retrieves the product_code for 「介護保険」 through an inner SELECT.
  This makes the nested SELECT meaningful without changing product status or
  other data.
- The other tables/data are not modified by the patch except for deleting
  product 00004.

Recommended existing-ACCDB procedure:
1. Make a backup copy of the ACCDB.
2. Import modSQLLab_FinalFix.bas.
3. Run ApplyFinalFix.
4. Confirm q_active_contract opens.
5. Confirm product table no longer contains 00004.
6. Test questions 1, 9, 10, 11, 12, 13, 14, 15, 18.
