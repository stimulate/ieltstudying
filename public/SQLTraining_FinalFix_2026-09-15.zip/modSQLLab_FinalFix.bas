﻿Attribute VB_Name = "modSQLLab_FinalFix"
Option Compare Database
Option Explicit

'=========================================================
' SQL Training Lab - Final Fix
'
' This patch is intended for the already-built ACCDB.
' It does NOT rebuild the database.
'
' Fixes:
' 1. q_active_contract -> FROM contract (not t_contract)
' 2. Delete product 00004 if it exists
' 3. Q1 wording
' 4. Remove [ ] from displayed SQL
' 5. Q9 explanation
' 6. Q11 AND -> WHERE
' 7. Q18 nested SELECT is made meaningful without changing data
'
' Run ApplyFinalFix once.
'=========================================================

Public Sub ApplyFinalFix()
    On Error GoTo EH

    Dim db As DAO.Database
    Dim rs As DAO.Recordset

    Set db = CurrentDb

    '----- Saved query: q_active_contract -----
    DeleteQueryIfExists "q_active_contract"

    db.CreateQueryDef _
        "q_active_contract", _
        "SELECT contract_id, contract_date, product_code, " & _
        "product_name, customer_id, customer_name, " & _
        "contract_status, amount, ap_amount, store_id " & _
        "FROM contract " & _
        "WHERE contract_status='有効';"

    '----- Remove product 00004 only if present -----
    db.Execute _
        "DELETE FROM product WHERE product_code='00004';", _
        dbFailOnError

    '----- Exercise 1 -----
    UpdateExercise db, 1, _
        "contractテーブルより、2025/4/1～2025/6/30のがん保険のうち、" & _
        "顧客名がテストデータではなく、amountがNULLではない契約を表示してください。", _
        Replace(Exercise1SQL(), "[contract]", "contract")

    '----- Exercise 9 -----
    UpdateExplanation db, 9, _
        "contractには00004の契約がありますが、productには00004が存在しないため、" & _
        "INNER JOINでは00004の契約は表示されません。"

    '----- Exercise 11: AND -> WHERE -----
    UpdateExercise db, 11, _
        "", _
        Exercise11SQL()

    '----- Exercise 18 -----
    UpdateExercise db, 18, _
        "商品マスタから「介護保険」の商品コードを取得し、" & _
        "その商品コードに該当する契約を表示してください。", _
        Exercise18SQL()

    '----- Remove [contract] from all displayed answer SQL -----
    Set rs = db.OpenRecordset( _
        "SELECT exercise_id, answer_sql FROM t_exercise", _
        dbOpenDynaset)

    Do While Not rs.EOF
        rs.Edit
        rs!answer_sql = Replace(Nz(rs!answer_sql, ""), "[contract]", "contract")
        rs.Update
        rs.MoveNext
    Loop

    rs.Close
    Set rs = Nothing
    Set db = Nothing

    MsgBox _
        "最終修正版を適用しました。" & vbCrLf & _
        "・q_active_contract" & vbCrLf & _
        "・product 00004削除" & vbCrLf & _
        "・第1/9/11/18問" & vbCrLf & _
        "・SQLの[contract]表記", _
        vbInformation, "SQL Training Lab"

    Exit Sub

EH:
    On Error Resume Next
    If Not rs Is Nothing Then rs.Close
    Set rs = Nothing
    Set db = Nothing

    MsgBox _
        "修正に失敗しました。" & vbCrLf & _
        "Error " & Err.Number & ": " & Err.Description, _
        vbCritical, "SQL Training Lab"
End Sub

Private Sub UpdateExercise( _
    ByVal db As DAO.Database, _
    ByVal exerciseId As Long, _
    ByVal questionText As String, _
    ByVal answerSql As String)

    Dim rs As DAO.Recordset

    Set rs = db.OpenRecordset( _
        "SELECT * FROM t_exercise WHERE exercise_id=" & CStr(exerciseId), _
        dbOpenDynaset)

    If rs.EOF Then
        rs.Close
        Err.Raise vbObjectError + 2001, _
                  "UpdateExercise", _
                  "exercise_id " & exerciseId & " が見つかりません。"
    End If

    rs.Edit

    If Len(questionText) > 0 Then
        rs!question_text = questionText
    End If

    If Len(answerSql) > 0 Then
        rs!answer_sql = answerSql
    End If

    rs.Update
    rs.Close
End Sub

Private Sub UpdateExplanation( _
    ByVal db As DAO.Database, _
    ByVal exerciseId As Long, _
    ByVal explanationText As String)

    Dim rs As DAO.Recordset

    Set rs = db.OpenRecordset( _
        "SELECT * FROM t_exercise WHERE exercise_id=" & CStr(exerciseId), _
        dbOpenDynaset)

    If rs.EOF Then
        rs.Close
        Err.Raise vbObjectError + 2002, _
                  "UpdateExplanation", _
                  "exercise_id " & exerciseId & " が見つかりません。"
    End If

    rs.Edit
    rs!explanation_text = explanationText
    rs.Update
    rs.Close
End Sub

Private Sub DeleteQueryIfExists(ByVal queryName As String)
    On Error Resume Next
    CurrentDb.QueryDefs.Delete queryName
    On Error GoTo 0
End Sub

Private Function Exercise1SQL() As String
    Exercise1SQL = _
        "SELECT" & vbCrLf & _
        "    contract_date," & vbCrLf & _
        "    product_name," & vbCrLf & _
        "    amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    contract" & vbCrLf & _
        "WHERE" & vbCrLf & _
        "    contract_date BETWEEN DateSerial(2025,4,1)" & vbCrLf & _
        "                      AND DateSerial(2025,6,30)" & vbCrLf & _
        "    AND product_name = 'がん保険'" & vbCrLf & _
        "    AND customer_name <> 'テストデータ'" & vbCrLf & _
        "    AND amount IS NOT NULL;"
End Function

Private Function Exercise11SQL() As String
    Exercise11SQL = _
        "SELECT" & vbCrLf & _
        "    c.contract_date," & vbCrLf & _
        "    c.product_code," & vbCrLf & _
        "    p.product_name," & vbCrLf & _
        "    p.product_status," & vbCrLf & _
        "    c.ap_amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    contract AS c" & vbCrLf & _
        "    LEFT JOIN product AS p" & vbCrLf & _
        "        ON c.product_code = p.product_code" & vbCrLf & _
        "WHERE" & vbCrLf & _
        "    p.product_status = '有効';"
End Function

Private Function Exercise18SQL() As String
    Exercise18SQL = _
        "SELECT" & vbCrLf & _
        "    contract_id," & vbCrLf & _
        "    contract_date," & vbCrLf & _
        "    product_code," & vbCrLf & _
        "    ap_amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    contract" & vbCrLf & _
        "WHERE" & vbCrLf & _
        "    product_code IN" & vbCrLf & _
        "    (" & vbCrLf & _
        "        SELECT" & vbCrLf & _
        "            product_code" & vbCrLf & _
        "        FROM" & vbCrLf & _
        "            product" & vbCrLf & _
        "        WHERE" & vbCrLf & _
        "            product_name = '介護保険'" & vbCrLf & _
        "    );"
End Function
