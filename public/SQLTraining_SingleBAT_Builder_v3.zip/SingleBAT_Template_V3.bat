@if (@CodeSection == @Batch) @then
@echo off
setlocal EnableExtensions DisableDelayedExpansion
for /f "tokens=2 delims=:" %%G in ('chcp') do set "SQLTRAIN_OLD_CP=%%G"
chcp 932 >nul
cscript.exe //nologo //E:JScript "%~f0" "%~f0"
set "SQLTRAIN_RC=%ERRORLEVEL%"
if not "%SQLTRAIN_RC%"=="0" pause
if defined SQLTRAIN_OLD_CP chcp %SQLTRAIN_OLD_CP% >nul
exit /b %SQLTRAIN_RC%
@end
var CONFIG = {id:"UNBUILT", passwordHash:"684d952794c0f01954f1eaf98b38512b5db23fae1802f66f429d815e653229a4", payloadHash:""};

// SHA-256 over UTF-8 text. Password and embedded payload integrity checks.
function sha256(text) {
    var s = unescape(encodeURIComponent(text)), words = [], i, j;
    var k = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    var h = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    function rr(n,b) { return (n >>> b) | (n << (32-b)); }
    for(i=0;i<s.length;i++) words[i>>2] = (words[i>>2] || 0) | (s.charCodeAt(i) << (24-(i%4)*8));
    words[s.length>>2] = (words[s.length>>2] || 0) | (0x80 << (24-(s.length%4)*8));
    var end = (((s.length+8)>>6)+1)*16;
    words[end-2] = Math.floor(s.length / 0x20000000);
    words[end-1] = s.length << 3;
    for(i=0;i<end;i+=16) {
        var w=[], a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
        for(j=0;j<64;j++) {
            if(j<16) w[j]=words[i+j]|0;
            else { var x=w[j-15],y=w[j-2]; w[j]=(w[j-16]+(rr(x,7)^rr(x,18)^(x>>>3))+w[j-7]+(rr(y,17)^rr(y,19)^(y>>>10)))|0; }
            var t1=(hh+(rr(e,6)^rr(e,11)^rr(e,25))+((e&f)^(~e&g))+k[j]+w[j])|0;
            var t2=((rr(a,2)^rr(a,13)^rr(a,22))+((a&b)^(a&c)^(b&c)))|0;
            hh=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;
        }
        var v=[a,b,c,d,e,f,g,hh];for(j=0;j<8;j++)h[j]=(h[j]+v[j])|0;
    }
    var result='';for(i=0;i<8;i++)result+=('00000000'+(h[i]>>>0).toString(16)).slice(-8);
    return result;
}

var fso = new ActiveXObject("Scripting.FileSystemObject");
var shell = new ActiveXObject("WScript.Shell");
var LIMIT = 48 * 1024 * 1024; // Base64/WSH memory guard; see README.
function say(s) { WScript.Echo(s); }
function ask(s) { WScript.StdOut.Write(s); return WScript.StdIn.ReadLine(); }
function pause() { ask("\u7d9a\u884c\u3059\u308b\u306b\u306f Enter \u30ad\u30fc\u3092\u62bc\u3057\u3066\u304f\u3060\u3055\u3044\u3002"); }
function fail(s) { throw new Error(s); }
function readText(path) {
    var t=fso.OpenTextFile(path,1,false,0);try{return t.ReadAll();}finally{t.Close();}
}
function writeNew(path,text) {
    var t=fso.CreateTextFile(path,false,false);try{t.Write(text);}finally{t.Close();}
}
function mkdir(path) {
    if(fso.FolderExists(path))return;
    var parent=fso.GetParentFolderName(path);if(parent && !fso.FolderExists(parent))mkdir(parent);
    fso.CreateFolder(path);
}
function token() {
    return (new Date().getTime()).toString(16)+Math.floor(Math.random()*0x100000000).toString(16)+Math.floor(Math.random()*0x100000000).toString(16);
}
function xmlNode() {
    var doc;try{doc=new ActiveXObject("Msxml2.DOMDocument.6.0");}catch(e){doc=new ActiveXObject("Msxml2.DOMDocument.3.0");}
    var n=doc.createElement("base64");n.dataType="bin.base64";return n;
}
function encodeFile(path) {
    if(!fso.FileExists(path))fail("\u30d5\u30a1\u30a4\u30eb\u304c\u898b\u3064\u304b\u308a\u307e\u305b\u3093\uff1a"+path);
    var size=Number(fso.GetFile(path).Size);
    if(size<1024 || size>LIMIT)fail("ACCDB \u306e\u30b5\u30a4\u30ba\u306f 1 KB\uff5e48 MB \u306b\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u73fe\u5728\u306e\u30b5\u30a4\u30ba\uff1a"+size);
    var st=new ActiveXObject("ADODB.Stream");st.Type=1;st.Open();
    try{st.LoadFromFile(path);var n=xmlNode();n.nodeTypedValue=st.Read();return n.text.replace(/\s/g,"");}finally{st.Close();}
}
function decodeNew(b64,path) {
    var n=xmlNode();n.text=b64;
    var st=new ActiveXObject("ADODB.Stream");st.Type=1;st.Open();
    try{st.Write(n.nodeTypedValue);st.SaveToFile(path,1);}finally{st.Close();}
}
function requireAccessClosed() {
    // Fail closed if process enumeration is unavailable. Never kill Access.
    var svc=GetObject("winmgmts:{impersonationLevel=impersonate}!\\\\.\\root\\cimv2");
    var procs=svc.ExecQuery("SELECT ProcessId FROM Win32_Process WHERE Name='MSACCESS.EXE'");
    if(procs.Count>0)fail("\u3059\u3079\u3066\u306e Microsoft Access \u3092\u9589\u3058\u3066\u304b\u3089\u3001\u3082\u3046\u4e00\u5ea6\u64cd\u4f5c\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u521d\u671f\u5316\u30fb\u914d\u5e03\u7528 BAT \u306e\u4f5c\u6210\u306f\u884c\u3063\u3066\u3044\u307e\u305b\u3093\u3002");
}
function requireUnlocked(path) {
    var lock=path.replace(/\.accdb$/i,".laccdb");
    if(fso.FileExists(lock))fail("Access \u306e\u30ed\u30c3\u30af\u30d5\u30a1\u30a4\u30eb\u304c\u5b58\u5728\u3057\u307e\u3059\uff1a"+lock+"\n\u5148\u306b Access \u3092\u9589\u3058\u3066\u304f\u3060\u3055\u3044\u3002\u7570\u5e38\u7d42\u4e86\u3057\u305f\u5834\u5408\u306f\u3001\u30bf\u30b9\u30af\u30de\u30cd\u30fc\u30b8\u30e3\u30fc\u3067\u78ba\u8a8d\u3057\u3066\u304b\u3089\u6b8b\u3063\u305f\u30ed\u30c3\u30af\u3092\u524a\u9664\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
}
function q(s) { if(s.indexOf('"')>=0)fail("\u30d1\u30b9\u306b\u4f7f\u7528\u3067\u304d\u306a\u3044\u5f15\u7528\u7b26\u304c\u542b\u307e\u308c\u3066\u3044\u307e\u3059\u3002");return '"'+s+'"'; }
// Markers are deliberately constructed here so the separator occurs only once.
function marker() { return "\r\n//__SQLTRAINING_"+"PAYLOAD_V3__\r\n/*\r\n"; }
function readPackage(text) {
    var mark=marker(), at=text.indexOf(mark);
    if(at<0 || text.indexOf(mark,at+mark.length)>=0)fail("\u57cb\u3081\u8fbc\u307f\u30c7\u30fc\u30bf\u306e\u533a\u5207\u308a\u304c\u6b63\u3057\u304f\u3042\u308a\u307e\u305b\u3093\u3002");
    var tail=text.substring(at+mark.length);
    if(!/\r\n\*\/\r\n?$/.test(tail))fail("BAT \u30d5\u30a1\u30a4\u30eb\u306e\u30c7\u30fc\u30bf\u304c\u4e0d\u5b8c\u5168\u3067\u3059\u3002");
    var b64=tail.replace(/\r\n\*\/\r\n?$/,"").replace(/\s/g,"");
    if(b64.length && (!/^[A-Za-z0-9+/]*={0,2}$/.test(b64)||b64.length%4!==0))fail("\u57cb\u3081\u8fbc\u307f\u30c7\u30fc\u30bf\u306e\u5f62\u5f0f\u304c\u6b63\u3057\u304f\u3042\u308a\u307e\u305b\u3093\u3002");
    return {head:text.substring(0,at),b64:b64};
}
function renderPackage(head,b64,id,passwordHash) {
    var re=/^var CONFIG = .*;$/m;
    if(!re.test(head))fail("\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8\u306e\u8a2d\u5b9a\u304c\u898b\u3064\u304b\u308a\u307e\u305b\u3093\u3002");
    var cfg='var CONFIG = {id:"'+id+'", passwordHash:"'+passwordHash+'", payloadHash:"'+sha256(b64)+'"};';
    head=head.replace(re,cfg);
    return head+marker()+b64.replace(/.{1,76}/g,"$&\r\n")+"*/\r\n";
}
function savePackage(head,b64,path,passwordHash) {
    if(fso.FileExists(path))fail("\u540c\u540d\u306e\u30d5\u30a1\u30a4\u30eb\u304c\u5b58\u5728\u3057\u307e\u3059\u3002\u5225\u306e\u540d\u524d\u3092\u6307\u5b9a\u3057\u3066\u304f\u3060\u3055\u3044\uff1a"+path);
    var content=renderPackage(head,b64,token(),passwordHash);
    var tmp=path+"."+token()+".tmp";
    try {
        writeNew(tmp,content);
        var verify=readPackage(readText(tmp));
        if(verify.b64!==b64)fail("\u4f5c\u6210\u3057\u305f BAT \u306e\u30c7\u30fc\u30bf\u691c\u8a3c\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002");
        fso.MoveFile(tmp,path); // Never overwrite an existing release.
    } finally { if(fso.FileExists(tmp))fso.DeleteFile(tmp); }
}

function findAccess() {
    var keys=["HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\MSACCESS.EXE\\",
      "HKLM\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\App Paths\\MSACCESS.EXE\\"];
    var i,p;
    for(i=0;i<keys.length;i++) {try{p=String(shell.RegRead(keys[i])).replace(/^"|"$/g,"");if(fso.FileExists(p))return p;}catch(ignore){} }
    var roots=[shell.ExpandEnvironmentStrings("%ProgramFiles%"),shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%")];
    var paths=["\\Microsoft Office\\root\\Office16\\MSACCESS.EXE","\\Microsoft Office\\Office16\\MSACCESS.EXE"];
    for(i=0;i<roots.length;i++)for(var j=0;j<paths.length;j++){p=roots[i]+paths[j];if(fso.FileExists(p))return p;}
    fail("Microsoft Access\uff08Office 16.0\uff09\u304c\u898b\u3064\u304b\u308a\u307e\u305b\u3093\u3002");
}
function ensureTrust(folder) {
    var policies=["HKCU\\Software\\Policies\\Microsoft\\Office\\16.0\\Access\\Security\\",
        "HKLM\\Software\\Policies\\Microsoft\\Office\\16.0\\Access\\Security\\"];
    function value(k) {try{return Number(shell.RegRead(k));}catch(e){return null;} }
    for(var i=0;i<policies.length;i++) {
        if(value(policies[i]+"Trusted Locations\\AllLocationsDisabled")===1 || value(policies[i]+"AllLocationsDisabled")===1)
            fail("\u7d44\u7e54\u306e\u30dd\u30ea\u30b7\u30fc\u306b\u3088\u308a\u4fe1\u983c\u3067\u304d\u308b\u5834\u6240\u304c\u7121\u52b9\u306b\u306a\u3063\u3066\u3044\u307e\u3059\u3002IT \u7ba1\u7406\u8005\u306b\u8a2d\u5b9a\u3092\u4f9d\u983c\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
        if(value(policies[i]+"AllowUserLocations")===0 || value(policies[i]+"Trusted Locations\\AllowUserLocations")===0)
            fail("\u7d44\u7e54\u306e\u30dd\u30ea\u30b7\u30fc\u306b\u3088\u308a\u30e6\u30fc\u30b6\u30fc\u306b\u3088\u308b\u4fe1\u983c\u3067\u304d\u308b\u5834\u6240\u306e\u8a2d\u5b9a\u304c\u7981\u6b62\u3055\u308c\u3066\u3044\u307e\u3059\u3002IT \u7ba1\u7406\u8005\u306b\u3054\u76f8\u8ac7\u304f\u3060\u3055\u3044\u3002");
    }
    // Dedicated key, exact path, no subfolders. Do not overwrite the old Location99.
    var key="HKCU\\Software\\Microsoft\\Office\\16.0\\Access\\Security\\Trusted Locations\\SQLTraining_V3_"+CONFIG.id+"\\";
    var path=folder.replace(/\\+$/,"")+"\\";
    shell.RegWrite(key+"Path",path,"REG_SZ");
    shell.RegWrite(key+"AllowSubFolders",0,"REG_DWORD");
    shell.RegWrite(key+"Description","ADS SQL Training - "+CONFIG.id,"REG_SZ");
    if(String(shell.RegRead(key+"Path")).toLowerCase()!==path.toLowerCase() || Number(shell.RegRead(key+"AllowSubFolders"))!==0)
        fail("\u4fe1\u983c\u3067\u304d\u308b\u5834\u6240\u306e\u8a2d\u5b9a\u3092\u78ba\u8a8d\u3067\u304d\u307e\u305b\u3093\u3067\u3057\u305f\u3002");
}
function authenticate() {
    say("\u7ba1\u7406\u8005\u30d1\u30b9\u30ef\u30fc\u30c9\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u5927\u6587\u5b57\u30fb\u5c0f\u6587\u5b57\u306f\u533a\u5225\u3055\u308c\u307e\u3059\u3002\u5165\u529b\u3057\u305f\u6587\u5b57\u306f\u753b\u9762\u306b\u8868\u793a\u3055\u308c\u307e\u3059\u3002");
    for(var i=0;i<3;i++) {
        var input=ask("\u30d1\u30b9\u30ef\u30fc\u30c9\uff08\u672a\u5165\u529b\u3067 Enter\uff1a\u30ad\u30e3\u30f3\u30bb\u30eb\uff09\uff1a");
        if(!input)return false;
        var ok=sha256(input)===CONFIG.passwordHash; input="";
        if(ok)return true;
        say("\u30d1\u30b9\u30ef\u30fc\u30c9\u304c\u6b63\u3057\u304f\u3042\u308a\u307e\u305b\u3093\u3002");
    }
    return false;
}
function runtimeMain() {
    var self=fso.GetAbsolutePathName(WScript.Arguments.Item(0));
    var pkg=readPackage(readText(self));
    if(!/^[a-f0-9]{20,40}$/.test(CONFIG.id) || !pkg.b64)fail("\u3053\u308c\u306f\u672a\u4f5c\u6210\u306e\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8\u3067\u3059\u3002\u5148\u306b ACCDB \u3092 Build_SQLTraining_V3.cmd \u306b\u30c9\u30e9\u30c3\u30b0\u3057\u3066 BAT \u3092\u4f5c\u6210\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
    if(sha256(pkg.b64)!==CONFIG.payloadHash)fail("\u57cb\u3081\u8fbc\u307f\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\u306e\u6574\u5408\u6027\u78ba\u8a8d\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002BAT \u3092\u4f5c\u308a\u76f4\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
    var root=shell.ExpandEnvironmentStrings("%LOCALAPPDATA%")+"\\ADS\\SQLTrainingV3\\"+CONFIG.id;
    mkdir(root);
    var practice=root+"\\Practice.accdb", editor=root+"\\Editor.accdb", opLock=root+"\\operation.lock";
    function operation(fn) {
        if(fso.FolderExists(opLock))fail("\u5225\u306e\u51e6\u7406\u304c\u5b9f\u884c\u4e2d\u3001\u307e\u305f\u306f\u524d\u56de\u306e\u51e6\u7406\u304c\u4e2d\u65ad\u3055\u308c\u3066\u3044\u307e\u3059\u3002\n\u3059\u3079\u3066\u306e\u5b66\u7fd2\u7528 BAT \u3068 Access \u3092\u9589\u3058\u3066\u304f\u3060\u3055\u3044\u3002\u30ed\u30c3\u30af\u304c\u6b8b\u3063\u3066\u3044\u308b\u5834\u5408\u306f\u3001\u6b21\u306e\u7a7a\u30d5\u30a9\u30eb\u30c0\u30fc\u3060\u3051\u3092\u524a\u9664\u3057\u3066\u304f\u3060\u3055\u3044\uff1a\n"+opLock);
        fso.CreateFolder(opLock);
        try {requireAccessClosed(); fn();} finally {if(fso.FolderExists(opLock))fso.DeleteFolder(opLock);}
    }
    function launch(path,isPractice) {
        requireUnlocked(path);
        var exe=findAccess();
        ensureTrust(root);
        if(isPractice || !fso.FileExists(path)) {
            var temp=root+"\\extract_"+token()+".accdb";
            try {
                decodeNew(pkg.b64,temp);
                if(encodeFile(temp)!==pkg.b64)fail("\u5c55\u958b\u3057\u305f\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\u306e\u691c\u8a3c\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002");
                if(fso.FileExists(path))fso.DeleteFile(path);
                fso.MoveFile(temp,path);
            } finally {if(fso.FileExists(temp))fso.DeleteFile(temp);}
        }
        say((isPractice?"\u521d\u671f\u72b6\u614b\u304b\u3089\u7df4\u7fd2\u3092\u958b\u59cb\u3057\u307e\u3059\uff1a":"\u7de8\u96c6\u7528\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\u3092\u958b\u304d\u307e\u3059\uff1a")+path);
        say("\u3053\u306e\u753b\u9762\u306f\u9589\u3058\u305a\u306b\u304a\u5f85\u3061\u304f\u3060\u3055\u3044\u3002Access \u3092\u4fdd\u5b58\u3057\u3066\u9589\u3058\u308b\u3068\u30e1\u30cb\u30e5\u30fc\u306b\u623b\u308a\u307e\u3059\u3002");
        var rc=shell.Run(q(exe)+" "+q(path),1,true);
        if(rc!==0)fail("Access \u306e\u7d42\u4e86\u30b3\u30fc\u30c9\uff1a"+rc+"\u3002\u4fdd\u5b58\u6e08\u307f\u306e\u7de8\u96c6\u5185\u5bb9\u306f\u30ed\u30fc\u30ab\u30eb\u30d5\u30a1\u30a4\u30eb\u306b\u6b8b\u3063\u3066\u3044\u307e\u3059\u3002");
    }
    function publish() {
        if(!fso.FileExists(editor))fail("\u7de8\u96c6\u7528\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\u304c\u3042\u308a\u307e\u305b\u3093\u3002\u5148\u306b\u300c\u554f\u984c\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\u3092\u7de8\u96c6\u300d\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
        requireUnlocked(editor);
        say("\u6b21\u306e\u7de8\u96c6\u7528\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\u304b\u3089\u914d\u5e03\u7528 BAT \u3092\u4f5c\u6210\u3057\u307e\u3059\uff1a"+editor);
        var name=ask("\u914d\u5e03\u7528\u30d5\u30a1\u30a4\u30eb\u540d\uff08\u534a\u89d2\u82f1\u6570\u5b57\u30fb_\u30fb-\u3001\u4f8b\uff1aFinance\uff09\uff1a");
        if(!/^[A-Za-z0-9][A-Za-z0-9_-]{0,59}$/.test(name))fail("\u540d\u524d\u306f 1\uff5e60 \u6587\u5b57\u3067\u3001\u5148\u982d\u306f\u534a\u89d2\u82f1\u6570\u5b57\u306b\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u4f7f\u7528\u3067\u304d\u308b\u6587\u5b57\u306f\u534a\u89d2\u82f1\u6570\u5b57\u30fb_\u30fb- \u3067\u3059\u3002");
        var releases=fso.GetParentFolderName(self)+"\\Published";mkdir(releases);
        var output=releases+"\\SQLTraining_"+name+".bat";
        var b64=encodeFile(editor);
        savePackage(pkg.head,b64,output,CONFIG.passwordHash);
        say("\u914d\u5e03\u7528 BAT \u306e\u4f5c\u6210\u3068\u30c7\u30fc\u30bf\u691c\u8a3c\u304c\u5b8c\u4e86\u3057\u307e\u3057\u305f\uff1a\n"+output);
        say("\u914d\u5e03\u3059\u308b\u306e\u306f\u3053\u306e BAT \u3060\u3051\u3067\u3059\u3002\u5b66\u7fd2\u7528\u30fb\u7ba1\u7406\u8005\u7528\u306e\u4e21\u30e1\u30cb\u30e5\u30fc\u3068\u540c\u3058\u7ba1\u7406\u8005\u30d1\u30b9\u30ef\u30fc\u30c9\u304c\u542b\u307e\u308c\u307e\u3059\u3002");
        say("\u5143\u306e BAT \u3068\u7de8\u96c6\u7528\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\u306f\u4fdd\u6301\u3055\u308c\u3066\u3044\u307e\u3059\u3002\u65b0\u3057\u3044 BAT \u306f\u5c02\u7528\u306e\u4f5c\u696d\u30d5\u30a9\u30eb\u30c0\u30fc\u3092\u4f7f\u7528\u3057\u307e\u3059\u3002");
    }
    function adminMenu() {
        if(!authenticate())return;
        while(true) {
            say("\n\u7ba1\u7406\u8005\u30e1\u30cb\u30e5\u30fc\n1. \u554f\u984c\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\u3092\u7de8\u96c6\uff08\u5909\u66f4\u3092\u4fdd\u5b58\uff09\n2. \u914d\u5e03\u7528 BAT \u3092\u65b0\u898f\u4f5c\u6210\n3. \u7de8\u96c6\u7528\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\u306e\u4fdd\u5b58\u5148\u3092\u8868\u793a\n0. \u30ed\u30b0\u30a2\u30a6\u30c8\u3057\u3066\u623b\u308b");
            var a=ask("\u756a\u53f7\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\uff1a");
            if(a==="0")return;
            try {
                if(a==="1")operation(function(){launch(editor,false);});
                else if(a==="2")operation(publish);
                else if(a==="3")say("\u7de8\u96c6\u7528\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\uff1a"+editor+"\nAccess \u3092\u9589\u3058\u3066\u304b\u3089\u3001\u3053\u306e ACCDB \u3092\u30d0\u30c3\u30af\u30a2\u30c3\u30d7\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u4f5c\u696d\u30d5\u30a9\u30eb\u30c0\u30fc\u306f\u524a\u9664\u3057\u306a\u3044\u3067\u304f\u3060\u3055\u3044\u3002");
                else say("0\u30011\u30012\u30013 \u306e\u3044\u305a\u308c\u304b\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
            }catch(e){say("\u3010\u30a8\u30e9\u30fc\u3011"+(e.description||e.message));}
        }
    }
    while(true) {
        say("\nSQL \u5b66\u7fd2\u30c4\u30fc\u30eb\n1. \u7df4\u7fd2\u3092\u958b\u59cb\uff08\u6bce\u56de\u3001\u521d\u671f\u72b6\u614b\u306b\u623b\u308a\u307e\u3059\uff09\n2. \u7ba1\u7406\u8005\u30e1\u30cb\u30e5\u30fc\uff08\u30d1\u30b9\u30ef\u30fc\u30c9\u304c\u5fc5\u8981\u3067\u3059\uff09\n0. \u7d42\u4e86");
        var choice=ask("\u756a\u53f7\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\uff3bEnter\uff1a1\uff3d\uff1a");
        if(choice==="0")return;
        try {
            if(choice==="1" || choice==="")operation(function(){launch(practice,true);});
            else if(choice==="2")adminMenu();
            else say("0\u30011\u30012 \u306e\u3044\u305a\u308c\u304b\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
        }catch(e){say("\u3010\u30a8\u30e9\u30fc\u3011"+(e.description||e.message));}
    }
}
try {runtimeMain();} catch(e) {say("\u3010\u30a8\u30e9\u30fc\u3011"+(e.description||e.message));pause();WScript.Quit(1);}

//__SQLTRAINING_PAYLOAD_V3__
/*

*/
