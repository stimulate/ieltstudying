@echo off
setlocal EnableExtensions DisableDelayedExpansion
for /f "tokens=2 delims=:" %%G in ('chcp') do set "SQLTRAIN_OLD_CP=%%G"
chcp 932 >nul
set "DATABASE=%~1"
if not defined DATABASE set "DATABASE=%~dp0SQLTraining_v1.0.accdb"
cscript.exe //nologo //E:JScript "%~dp0Build.js" "%DATABASE%" "%~dp0SingleBAT_Template_V3.bat"
set "SQLTRAIN_RC=%ERRORLEVEL%"
pause
if defined SQLTRAIN_OLD_CP chcp %SQLTRAIN_OLD_CP% >nul
exit /b %SQLTRAIN_RC%
