
// SHA-256 over UTF-8 text. Password and embedded payload integrity checks.
function sha256(text) {
    var s = unescape(encodeURIComponent(text)), words = [], i, j;
    var k = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    var h = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    function rr(n,b) { return (n >>> b) | (n << (32-b)); }
    for(i=0;i<s.length;i++) words[i>>2] = (words[i>>2] || 0) | (s.charCodeAt(i) << (24-(i%4)*8));
    words[s.length>>2] = (words[s.length>>2] || 0) | (0x80 << (24-(s.length%4)*8));
    var end = (((s.length+8)>>6)+1)*16;
    words[end-2] = Math.floor(s.length / 0x20000000);
    words[end-1] = s.length << 3;
    for(i=0;i<end;i+=16) {
        var w=[], a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
        for(j=0;j<64;j++) {
            if(j<16) w[j]=words[i+j]|0;
            else { var x=w[j-15],y=w[j-2]; w[j]=(w[j-16]+(rr(x,7)^rr(x,18)^(x>>>3))+w[j-7]+(rr(y,17)^rr(y,19)^(y>>>10)))|0; }
            var t1=(hh+(rr(e,6)^rr(e,11)^rr(e,25))+((e&f)^(~e&g))+k[j]+w[j])|0;
            var t2=((rr(a,2)^rr(a,13)^rr(a,22))+((a&b)^(a&c)^(b&c)))|0;
            hh=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;
        }
        var v=[a,b,c,d,e,f,g,hh];for(j=0;j<8;j++)h[j]=(h[j]+v[j])|0;
    }
    var result='';for(i=0;i<8;i++)result+=('00000000'+(h[i]>>>0).toString(16)).slice(-8);
    return result;
}

var fso = new ActiveXObject("Scripting.FileSystemObject");
var shell = new ActiveXObject("WScript.Shell");
var LIMIT = 48 * 1024 * 1024; // Base64/WSH memory guard; see README.
function say(s) { WScript.Echo(s); }
function ask(s) { WScript.StdOut.Write(s); return WScript.StdIn.ReadLine(); }
function pause() { ask("\u7d9a\u884c\u3059\u308b\u306b\u306f Enter \u30ad\u30fc\u3092\u62bc\u3057\u3066\u304f\u3060\u3055\u3044\u3002"); }
function fail(s) { throw new Error(s); }
function readText(path) {
    var t=fso.OpenTextFile(path,1,false,0);try{return t.ReadAll();}finally{t.Close();}
}
function writeNew(path,text) {
    var t=fso.CreateTextFile(path,false,false);try{t.Write(text);}finally{t.Close();}
}
function mkdir(path) {
    if(fso.FolderExists(path))return;
    var parent=fso.GetParentFolderName(path);if(parent && !fso.FolderExists(parent))mkdir(parent);
    fso.CreateFolder(path);
}
function token() {
    return (new Date().getTime()).toString(16)+Math.floor(Math.random()*0x100000000).toString(16)+Math.floor(Math.random()*0x100000000).toString(16);
}
function xmlNode() {
    var doc;try{doc=new ActiveXObject("Msxml2.DOMDocument.6.0");}catch(e){doc=new ActiveXObject("Msxml2.DOMDocument.3.0");}
    var n=doc.createElement("base64");n.dataType="bin.base64";return n;
}
function encodeFile(path) {
    if(!fso.FileExists(path))fail("\u30d5\u30a1\u30a4\u30eb\u304c\u898b\u3064\u304b\u308a\u307e\u305b\u3093\uff1a"+path);
    var size=Number(fso.GetFile(path).Size);
    if(size<1024 || size>LIMIT)fail("ACCDB \u306e\u30b5\u30a4\u30ba\u306f 1 KB\uff5e48 MB \u306b\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u73fe\u5728\u306e\u30b5\u30a4\u30ba\uff1a"+size);
    var st=new ActiveXObject("ADODB.Stream");st.Type=1;st.Open();
    try{st.LoadFromFile(path);var n=xmlNode();n.nodeTypedValue=st.Read();return n.text.replace(/\s/g,"");}finally{st.Close();}
}
function decodeNew(b64,path) {
    var n=xmlNode();n.text=b64;
    var st=new ActiveXObject("ADODB.Stream");st.Type=1;st.Open();
    try{st.Write(n.nodeTypedValue);st.SaveToFile(path,1);}finally{st.Close();}
}
function requireAccessClosed() {
    // Fail closed if process enumeration is unavailable. Never kill Access.
    var svc=GetObject("winmgmts:{impersonationLevel=impersonate}!\\\\.\\root\\cimv2");
    var procs=svc.ExecQuery("SELECT ProcessId FROM Win32_Process WHERE Name='MSACCESS.EXE'");
    if(procs.Count>0)fail("\u3059\u3079\u3066\u306e Microsoft Access \u3092\u9589\u3058\u3066\u304b\u3089\u3001\u3082\u3046\u4e00\u5ea6\u64cd\u4f5c\u3057\u3066\u304f\u3060\u3055\u3044\u3002\u521d\u671f\u5316\u30fb\u914d\u5e03\u7528 BAT \u306e\u4f5c\u6210\u306f\u884c\u3063\u3066\u3044\u307e\u305b\u3093\u3002");
}
function requireUnlocked(path) {
    var lock=path.replace(/\.accdb$/i,".laccdb");
    if(fso.FileExists(lock))fail("Access \u306e\u30ed\u30c3\u30af\u30d5\u30a1\u30a4\u30eb\u304c\u5b58\u5728\u3057\u307e\u3059\uff1a"+lock+"\n\u5148\u306b Access \u3092\u9589\u3058\u3066\u304f\u3060\u3055\u3044\u3002\u7570\u5e38\u7d42\u4e86\u3057\u305f\u5834\u5408\u306f\u3001\u30bf\u30b9\u30af\u30de\u30cd\u30fc\u30b8\u30e3\u30fc\u3067\u78ba\u8a8d\u3057\u3066\u304b\u3089\u6b8b\u3063\u305f\u30ed\u30c3\u30af\u3092\u524a\u9664\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
}
function q(s) { if(s.indexOf('"')>=0)fail("\u30d1\u30b9\u306b\u4f7f\u7528\u3067\u304d\u306a\u3044\u5f15\u7528\u7b26\u304c\u542b\u307e\u308c\u3066\u3044\u307e\u3059\u3002");return '"'+s+'"'; }
// Markers are deliberately constructed here so the separator occurs only once.
function marker() { return "\r\n//__SQLTRAINING_"+"PAYLOAD_V3__\r\n/*\r\n"; }
function readPackage(text) {
    var mark=marker(), at=text.indexOf(mark);
    if(at<0 || text.indexOf(mark,at+mark.length)>=0)fail("\u57cb\u3081\u8fbc\u307f\u30c7\u30fc\u30bf\u306e\u533a\u5207\u308a\u304c\u6b63\u3057\u304f\u3042\u308a\u307e\u305b\u3093\u3002");
    var tail=text.substring(at+mark.length);
    if(!/\r\n\*\/\r\n?$/.test(tail))fail("BAT \u30d5\u30a1\u30a4\u30eb\u306e\u30c7\u30fc\u30bf\u304c\u4e0d\u5b8c\u5168\u3067\u3059\u3002");
    var b64=tail.replace(/\r\n\*\/\r\n?$/,"").replace(/\s/g,"");
    if(b64.length && (!/^[A-Za-z0-9+/]*={0,2}$/.test(b64)||b64.length%4!==0))fail("\u57cb\u3081\u8fbc\u307f\u30c7\u30fc\u30bf\u306e\u5f62\u5f0f\u304c\u6b63\u3057\u304f\u3042\u308a\u307e\u305b\u3093\u3002");
    return {head:text.substring(0,at),b64:b64};
}
function renderPackage(head,b64,id,passwordHash) {
    var re=/^var CONFIG = .*;$/m;
    if(!re.test(head))fail("\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8\u306e\u8a2d\u5b9a\u304c\u898b\u3064\u304b\u308a\u307e\u305b\u3093\u3002");
    var cfg='var CONFIG = {id:"'+id+'", passwordHash:"'+passwordHash+'", payloadHash:"'+sha256(b64)+'"};';
    head=head.replace(re,cfg);
    return head+marker()+b64.replace(/.{1,76}/g,"$&\r\n")+"*/\r\n";
}
function savePackage(head,b64,path,passwordHash) {
    if(fso.FileExists(path))fail("\u540c\u540d\u306e\u30d5\u30a1\u30a4\u30eb\u304c\u5b58\u5728\u3057\u307e\u3059\u3002\u5225\u306e\u540d\u524d\u3092\u6307\u5b9a\u3057\u3066\u304f\u3060\u3055\u3044\uff1a"+path);
    var content=renderPackage(head,b64,token(),passwordHash);
    var tmp=path+"."+token()+".tmp";
    try {
        writeNew(tmp,content);
        var verify=readPackage(readText(tmp));
        if(verify.b64!==b64)fail("\u4f5c\u6210\u3057\u305f BAT \u306e\u30c7\u30fc\u30bf\u691c\u8a3c\u306b\u5931\u6557\u3057\u307e\u3057\u305f\u3002");
        fso.MoveFile(tmp,path); // Never overwrite an existing release.
    } finally { if(fso.FileExists(tmp))fso.DeleteFile(tmp); }
}

try {
    if(WScript.Arguments.length<2)fail("\u4f7f\u7528\u65b9\u6cd5\uff1aBuild.js ACCDB \u30c6\u30f3\u30d7\u30ec\u30fc\u30c8");
    var input=fso.GetAbsolutePathName(WScript.Arguments.Item(0));
    var templatePath=fso.GetAbsolutePathName(WScript.Arguments.Item(1));
    if(!/\.accdb$/i.test(input))fail(".accdb \u30d5\u30a1\u30a4\u30eb\u3092\u6307\u5b9a\u3057\u3066\u304f\u3060\u3055\u3044\u3002");
    requireAccessClosed();requireUnlocked(input);
    var pkg=readPackage(readText(templatePath));
    var hashMatch=/passwordHash:"([a-f0-9]{64})"/.exec(pkg.head);
    if(!hashMatch)fail("\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8\u306b\u30d1\u30b9\u30ef\u30fc\u30c9\u306e\u8a2d\u5b9a\u304c\u3042\u308a\u307e\u305b\u3093\u3002");
    var folder=fso.GetParentFolderName(templatePath)+"\\Output";mkdir(folder);
    var path=folder+"\\SQLTraining_"+token()+".bat";
    say("\u6b21\u306e\u30c7\u30fc\u30bf\u30d9\u30fc\u30b9\u304b\u3089 BAT \u3092\u4f5c\u6210\u3057\u307e\u3059\uff1a"+input);
    savePackage(pkg.head,encodeFile(input),path,hashMatch[1]);
    say("BAT \u306e\u4f5c\u6210\u3068\u30c7\u30fc\u30bf\u691c\u8a3c\u304c\u5b8c\u4e86\u3057\u307e\u3057\u305f\uff1a\n"+path+"\n\u914d\u5e03\u3059\u308b\u306e\u306f\u3053\u306e BAT \u3060\u3051\u3067\u3059\u3002");
} catch(e) {say("\u3010\u30a8\u30e9\u30fc\u3011"+(e.description||e.message));WScript.Quit(1);}
