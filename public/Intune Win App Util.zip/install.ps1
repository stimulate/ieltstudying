$ErrorActionPreference = "Stop"

$folder = "C:\ProgramData\CompanyScreensaver"

# Create folder
New-Item -Path $folder -ItemType Directory -Force

# Get script location
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Copy images
Copy-Item "$ScriptDir\image1.jpg" "$folder\image1.jpg" -Force
Copy-Item "$ScriptDir\image2.jpg" "$folder\image2.jpg" -Force

# Registry
New-Item `
    -Path "HKLM:\SOFTWARE\CompanyScreensaver" `
    -Force

Set-ItemProperty `
    -Path "HKLM:\SOFTWARE\CompanyScreensaver" `
    -Name "Installed" `
    -Value "1"

Write-Output "Images deployed successfully."
exit 0