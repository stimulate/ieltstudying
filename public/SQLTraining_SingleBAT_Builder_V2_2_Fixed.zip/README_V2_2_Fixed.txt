SQL Training Single-BAT Builder V2.2 Fixed
==================================================

Trusted Location behavior
-------------------------
V2.2 does not blindly write the registry.

1. It queries Location99.
2. If Path already equals:
   %LOCALAPPDATA%\ADS\SQLTraining\
   it skips every registry write.
3. If Location99 is missing or contains another path, it deletes only
   Location99 and recreates it.
4. The REG ADD output is visible, so a blocked command can be identified.

Important
---------
REG ADD /F already overwrites an existing value without asking.
Repeated old Location entries normally do not make REG ADD wait.

If execution visibly stops on one of these lines:
- Writing Path...
- Writing AllowSubFolders...
- Writing Description...
- Verifying Location99...

the problem is more likely an enterprise security control blocking or
inspecting REG.EXE, rather than too many registered locations.

Build
-----
1. Put SQLTraining_v1.0.accdb in this folder.
2. Run Build_SQLTraining_SingleBAT_V2_2_Fixed.cmd.
3. Distribute SQLTraining_SingleFile_V2_2_Fixed.bat.

Clean test
----------
1. Close Microsoft Access.
2. Win + R
3. Enter:
   %LOCALAPPDATA%\ADS
4. Delete SQLTraining.
5. Run the generated V2.2 BAT.
6. Note the last displayed registry step if it stops.

Second run
----------
If both SQLTraining.accdb and the V2.2 ready marker exist, the BAT opens
Access immediately without checking or changing the registry.
