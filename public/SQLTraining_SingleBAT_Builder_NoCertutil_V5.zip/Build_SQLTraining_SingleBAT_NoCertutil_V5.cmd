@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion

set "DATABASE=%~1"
if not defined DATABASE set "DATABASE=%~dp0SQLTraining_v1.0.accdb"

set "TEMPLATE=%~dp0SingleBAT_Template_NoCertutil_V5.cmd"
set "ENCODER=%~dp0EncodePayload.js"
set "VALIDATOR=%~dp0ValidateSingleBAT.js"
set "OUTPUT=%~dp0SQLTraining_SingleFile_V5.bat"
set "TEMPBASE64=%TEMP%\SQLTraining_Payload_%RANDOM%_%RANDOM%.b64"
set "TEMPDECODED=%TEMP%\SQLTraining_Validate_%RANDOM%_%RANDOM%.accdb"

echo.
echo SQL Training Single-BAT V5 Builder
echo.

if not exist "%DATABASE%" (
    echo [ERROR] ACCDBファイルが見つかりません。
    echo %DATABASE%
    echo.
    echo SQLTraining_v1.0.accdbを同じフォルダーへ置くか、
    echo ACCDBファイルをこのCMDへドラッグしてください。
    pause
    exit /b 1
)

if not exist "%TEMPLATE%" (
    echo [ERROR] テンプレートが見つかりません。
    echo %TEMPLATE%
    pause
    exit /b 1
)

if not exist "%ENCODER%" (
    echo [ERROR] EncodePayload.jsが見つかりません。
    pause
    exit /b 1
)

if not exist "%VALIDATOR%" (
    echo [ERROR] ValidateSingleBAT.jsが見つかりません。
    pause
    exit /b 1
)

where cscript.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] cscript.exeが見つかりません。
    pause
    exit /b 1
)

if exist "%TEMPBASE64%" del /q "%TEMPBASE64%" >nul 2>&1
if exist "%TEMPDECODED%" del /q "%TEMPDECODED%" >nul 2>&1
if exist "%OUTPUT%" del /q "%OUTPUT%" >nul 2>&1

cscript.exe //nologo "%ENCODER%" "%DATABASE%" "%TEMPBASE64%"
if errorlevel 1 (
    echo [ERROR] ACCDBをBase64へ変換できませんでした。
    goto CLEANUP_ERROR
)

if not exist "%TEMPBASE64%" (
    echo [ERROR] Base64ペイロードが作成されませんでした。
    goto CLEANUP_ERROR
)

copy /B /Y "%TEMPLATE%"+"%TEMPBASE64%" "%OUTPUT%" >nul
if errorlevel 1 (
    echo [ERROR] 単一BATを作成できませんでした。
    goto CLEANUP_ERROR
)

if not exist "%OUTPUT%" (
    echo [ERROR] 出力BATを確認できませんでした。
    goto CLEANUP_ERROR
)

echo 作成したBATの内蔵データを検証しています...

cscript.exe //nologo "%VALIDATOR%" "%OUTPUT%" "%TEMPDECODED%"
if errorlevel 1 (
    echo [ERROR] 作成したBATからACCDBを正しく復元できませんでした。
    goto CLEANUP_ERROR
)

if not exist "%TEMPDECODED%" (
    echo [ERROR] 検証用ACCDBが作成されませんでした。
    goto CLEANUP_ERROR
)

fc /B "%DATABASE%" "%TEMPDECODED%" >nul
if errorlevel 1 (
    echo [ERROR] 復元したACCDBが元ファイルと一致しません。
    goto CLEANUP_ERROR
)

del /q "%TEMPBASE64%" >nul 2>&1
del /q "%TEMPDECODED%" >nul 2>&1

echo.
echo 構築と二進数比較に成功しました。
echo.
echo 作成完了:
echo %OUTPUT%
echo.
echo 受講者にはSQLTraining_SingleFile_V5.batだけを配布してください。
echo.
pause
endlocal
exit /b 0

:CLEANUP_ERROR

if exist "%TEMPBASE64%" del /q "%TEMPBASE64%" >nul 2>&1
if exist "%TEMPDECODED%" del /q "%TEMPDECODED%" >nul 2>&1
if exist "%OUTPUT%" del /q "%OUTPUT%" >nul 2>&1

echo.
echo 出力BATは削除しました。
pause
endlocal
exit /b 1
