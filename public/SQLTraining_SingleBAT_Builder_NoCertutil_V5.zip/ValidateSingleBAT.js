// Reads payload line by line after the exact marker.
// Used by the builder before it releases the output BAT.

(function () {
    if (WScript.Arguments.length < 2) WScript.Quit(2);

    var selfPath = WScript.Arguments.Item(0);
    var targetPath = WScript.Arguments.Item(1);
    var marker = ":" + "__SQLTRAINING_V5_" + "PAYLOAD_BEGIN__";

    try {
        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var input = fso.OpenTextFile(selfPath, 1, false, 0);
        var found = false;
        var base64 = "";
        var line;

        while (!input.AtEndOfStream) {
            line = input.ReadLine();

            if (!found) {
                if (line === marker) {
                    found = true;
                }
                continue;
            }

            line = line.replace(/^\s+|\s+$/g, "");
            if (line.length === 0) continue;

            if (!/^[A-Za-z0-9+/]*={0,2}$/.test(line)) {
                input.Close();
                WScript.Echo("Invalid payload line.");
                WScript.Quit(6);
            }

            base64 += line;
        }

        input.Close();

        if (!found) WScript.Quit(3);
        if (base64.length === 0) WScript.Quit(4);
        if ((base64.length % 4) !== 0) WScript.Quit(5);

        var xml;
        try {
            xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
        } catch (e1) {
            xml = new ActiveXObject("Msxml2.DOMDocument.3.0");
        }

        var node = xml.createElement("base64");
        node.dataType = "bin.base64";
        node.text = base64;
        var bytes = node.nodeTypedValue;

        if (bytes.length < 1024) WScript.Quit(7);

        var output = new ActiveXObject("ADODB.Stream");
        output.Type = 1;
        output.Open();
        output.Write(bytes);
        output.SaveToFile(targetPath, 2);
        output.Close();

        WScript.Quit(0);
    } catch (e) {
        WScript.Echo("Validation error: " + e.number + " / " + e.description);
        WScript.Quit(1);
    }
})();
