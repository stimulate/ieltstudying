(function () {
    if (WScript.Arguments.length < 2) WScript.Quit(2);

    var inputPath = WScript.Arguments.Item(0);
    var outputPath = WScript.Arguments.Item(1);

    try {
        var binaryStream = new ActiveXObject("ADODB.Stream");
        binaryStream.Type = 1;
        binaryStream.Open();
        binaryStream.LoadFromFile(inputPath);
        var bytes = binaryStream.Read();
        binaryStream.Close();

        var xml;
        try {
            xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
        } catch (e1) {
            xml = new ActiveXObject("Msxml2.DOMDocument.3.0");
        }

        var node = xml.createElement("base64");
        node.dataType = "bin.base64";
        node.nodeTypedValue = bytes;

        var base64 = node.text.replace(/\r/g, "").replace(/\n/g, "");
        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var output = fso.CreateTextFile(outputPath, true, false);

        for (var i = 0; i < base64.length; i += 76) {
            output.WriteLine(base64.substr(i, 76));
        }

        output.Close();
        WScript.Quit(0);
    } catch (e) {
        WScript.Echo("Encode error: " + e.number + " / " + e.description);
        WScript.Quit(1);
    }
})();
