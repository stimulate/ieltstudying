@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion

rem ============================================================
rem SQL Training Lab - Single self-extracting BAT V5
rem
rem Payload is read line by line only after one exact marker.
rem No certutil. No PowerShell.
rem ============================================================

set "WORKDIR=%LOCALAPPDATA%\ADS\SQLTraining"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "TEMPJS=%TEMP%\SQLTraining_Decode_%RANDOM%_%RANDOM%.js"
set "TRUSTKEY=HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99"

rem Existing ACCDB:
rem check the trusted path, then open without extracting again.
if exist "%TARGET%" (
    call :CHECK_TRUST
    if not errorlevel 1 goto OPEN_DATABASE

    echo.
    echo ローカルACCDBは存在しますが、信頼できる場所がありません。
    echo 登録だけを修復します。
    echo.

    call :REGISTER_TRUST
    if errorlevel 1 goto TRUST_ERROR

    goto OPEN_DATABASE
)

echo.
echo SQL Training Labの初回セットアップを開始します。
echo.

tasklist /FI "IMAGENAME eq MSACCESS.EXE" 2>nul | find /I "MSACCESS.EXE" >nul
if not errorlevel 1 (
    echo [ERROR] Microsoft Accessが起動中です。
    echo すべてのAccess画面を閉じてから再実行してください。
    pause
    exit /b 1
)

if not exist "%WORKDIR%" mkdir "%WORKDIR%" >nul 2>&1

if not exist "%WORKDIR%" (
    echo [ERROR] ローカルフォルダーを作成できませんでした。
    echo %WORKDIR%
    pause
    exit /b 1
)

where cscript.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] cscript.exeが見つかりません。
    pause
    exit /b 1
)

call :WRITE_DECODER "%TEMPJS%"

if not exist "%TEMPJS%" (
    echo [ERROR] 一時デコーダーを作成できませんでした。
    pause
    exit /b 1
)

cscript.exe //nologo "%TEMPJS%" "%~f0" "%TARGET%"
set "DECODE_RC=%ERRORLEVEL%"

del /q "%TEMPJS%" >nul 2>&1

if not "%DECODE_RC%"=="0" (
    echo.
    echo [ERROR] 内蔵ACCDBを復元できませんでした。
    echo Exit code: %DECODE_RC%
    echo.
    echo 3 = payload marker not found
    echo 4 = payload is empty
    echo 5 = invalid Base64 length
    echo 6 = invalid payload line
    echo 7 = decoded file is too small
    echo 1 = COM / ADODB / MSXML error
    echo.
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] 復元したACCDBが見つかりません。
    pause
    exit /b 1
)

for %%F in ("%TARGET%") do set "TARGET_SIZE=%%~zF"

if %TARGET_SIZE% LSS 1024 (
    echo [ERROR] 復元したACCDBのサイズが不正です。
    del /q "%TARGET%" >nul 2>&1
    pause
    exit /b 1
)

attrib +h "%WORKDIR%" >nul 2>&1
attrib +h "%TARGET%" >nul 2>&1
del "%TARGET%:Zone.Identifier" >nul 2>&1

call :REGISTER_TRUST
if errorlevel 1 goto TRUST_ERROR

goto OPEN_DATABASE

:REGISTER_TRUST

reg add "%TRUSTKEY%" /v Path /t REG_SZ /d "%WORKDIR%\" /f >nul 2>&1
if errorlevel 1 exit /b 1

reg add "%TRUSTKEY%" /v AllowSubFolders /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 exit /b 1

reg add "%TRUSTKEY%" /v Description /t REG_SZ /d "ADS SQL Training Lab" /f >nul 2>&1
if errorlevel 1 exit /b 1

call :CHECK_TRUST
if errorlevel 1 exit /b 1

echo Accessの信頼できる場所を登録しました。
exit /b 0

:CHECK_TRUST

reg query "%TRUSTKEY%" /v Path 2>nul ^
    | findstr /I /C:"%WORKDIR%\" >nul

if errorlevel 1 exit /b 1
exit /b 0

:OPEN_DATABASE

set "ACCESS_EXE="

for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"

if not defined ACCESS_EXE (
    for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"
)

if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE"

if not defined ACCESS_EXE (
    echo [ERROR] Microsoft Accessが見つかりません。
    echo %TARGET%
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] ローカルACCDBが見つかりません。
    echo %TARGET%
    pause
    exit /b 1
)

start "" "%ACCESS_EXE%" "%TARGET%"
endlocal
exit /b 0

:TRUST_ERROR

echo [ERROR] Accessの信頼できる場所を登録できませんでした。
echo.
echo Intune、Group Policy、またはOfficeポリシーで
echo ユーザー設定が制限されている可能性があります。
echo.
echo %WORKDIR%
pause
endlocal
exit /b 1

:WRITE_DECODER

> "%~1" echo var args = WScript.Arguments;
>>"%~1" echo if (args.length ^< 2) WScript.Quit(2);
>>"%~1" echo var selfPath = args.Item(0);
>>"%~1" echo var targetPath = args.Item(1);
>>"%~1" echo var marker = ":" + "__SQLTRAINING_V5_" + "PAYLOAD_BEGIN__";
>>"%~1" echo try {
>>"%~1" echo   var fso = new ActiveXObject("Scripting.FileSystemObject");
>>"%~1" echo   var input = fso.OpenTextFile(selfPath, 1, false, 0);
>>"%~1" echo   var found = false;
>>"%~1" echo   var base64 = "";
>>"%~1" echo   var line;
>>"%~1" echo   while (!input.AtEndOfStream) {
>>"%~1" echo     line = input.ReadLine();
>>"%~1" echo     if (!found) {
>>"%~1" echo       if (line === marker) found = true;
>>"%~1" echo       continue;
>>"%~1" echo     }
>>"%~1" echo     line = line.replace(/^\s+^|\s+$/g, "");
>>"%~1" echo     if (line.length === 0) continue;
>>"%~1" echo     if (!/^[A-Za-z0-9+\/]*={0,2}$/.test(line)) {
>>"%~1" echo       input.Close();
>>"%~1" echo       WScript.Quit(6);
>>"%~1" echo     }
>>"%~1" echo     base64 += line;
>>"%~1" echo   }
>>"%~1" echo   input.Close();
>>"%~1" echo   if (!found) WScript.Quit(3);
>>"%~1" echo   if (base64.length === 0) WScript.Quit(4);
>>"%~1" echo   if ((base64.length %% 4) !== 0) WScript.Quit(5);
>>"%~1" echo   var xml;
>>"%~1" echo   try {
>>"%~1" echo     xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
>>"%~1" echo   } catch (e1) {
>>"%~1" echo     xml = new ActiveXObject("Msxml2.DOMDocument.3.0");
>>"%~1" echo   }
>>"%~1" echo   var node = xml.createElement("base64");
>>"%~1" echo   node.dataType = "bin.base64";
>>"%~1" echo   node.text = base64;
>>"%~1" echo   var bytes = node.nodeTypedValue;
>>"%~1" echo   if (bytes.length ^< 1024) WScript.Quit(7);
>>"%~1" echo   var output = new ActiveXObject("ADODB.Stream");
>>"%~1" echo   output.Type = 1;
>>"%~1" echo   output.Open();
>>"%~1" echo   output.Write(bytes);
>>"%~1" echo   output.SaveToFile(targetPath, 2);
>>"%~1" echo   output.Close();
>>"%~1" echo   WScript.Quit(0);
>>"%~1" echo } catch (e) {
>>"%~1" echo   WScript.Echo("Decode error: " + e.number + " / " + e.description);
>>"%~1" echo   WScript.Quit(1);
>>"%~1" echo }

exit /b 0

:__SQLTRAINING_V5_PAYLOAD_BEGIN__
