SQL Training Single-BAT Builder V5
==================================

Why V4 failed
-------------
V4 read the complete mixed BAT as one UTF-8 string and sliced it by character
position. A self-extracting BAT contains both script text and appended Base64.
That approach was too sensitive to encoding, line endings, and concatenation.

Exit code 6 meant the extracted text contained characters outside Base64.
The additional exit-code list did not create more failures; it only exposed
where validation stopped.

V5 design
---------
- Reads the generated BAT line by line.
- Does not decode anything before the one exact marker line.
- Reads only ASCII Base64 lines after the marker.
- Builder restores the payload immediately after construction.
- Builder performs FC /B binary comparison with the original ACCDB.
- If validation or comparison fails, the output BAT is deleted.
- No certutil.
- No PowerShell.

Build
-----
1. Put the final ACCDB in the folder as:
   SQLTraining_v1.0.accdb

2. Run:
   Build_SQLTraining_SingleBAT_NoCertutil_V5.cmd

3. A successful build must display:
   構築と二進数比較に成功しました。

4. Distribute only:
   SQLTraining_SingleFile_V5.bat

Clean test
----------
1. Close all Microsoft Access windows.
2. Win + R
3. Enter:
   %LOCALAPPDATA%\ADS
4. Delete SQLTraining.
5. Run SQLTraining_SingleFile_V5.bat.
6. Close Access.
7. Run it a second time.

Second run
----------
If SQLTraining.accdb exists and Location99 is correct:
- no extraction
- no cscript
- no registry rewrite
- direct Access launch

If the ACCDB exists but Location99 is missing:
- repairs only Location99
- does not overwrite the local database
