<#
.SYNOPSIS
    NightLock - Azure / SharePoint セットアップヘルパー
.DESCRIPTION
    Run ONCE on your admin workstation to:
    1. Create the Entra ID App Registration (with Sites.Read.All)
    2. Create the SharePoint List for overtime approvals
    3. Output IDs to paste into settings.json

    Prerequisites:
    - Install-Module Microsoft.Graph -Scope CurrentUser
    - Install-Module PnP.PowerShell -Scope CurrentUser
    - Global Admin or appropriate delegated permissions
#>

param(
    [Parameter(Mandatory)][string]$TenantId,
    [Parameter(Mandatory)][string]$SharePointUrl,      # e.g. https://contoso.sharepoint.com/sites/IT
    [string]$AppName      = "NightLock-Sync",
    [string]$ListName     = "NightLockExemptions"
)

Import-Module Microsoft.Graph.Applications -ErrorAction Stop
Import-Module PnP.PowerShell -ErrorAction Stop

Write-Host "Connecting to Microsoft Graph..." -ForegroundColor Cyan
Connect-MgGraph -TenantId $TenantId -Scopes "Application.ReadWrite.All","Sites.FullControl.All"

# ── 1. Create App Registration ────────────────────────────────────────────────
Write-Host "Creating App Registration: $AppName..." -ForegroundColor Cyan

$app = New-MgApplication -DisplayName $AppName -SignInAudience "AzureADMyOrg"

# Add Sites.Read.All application permission
$graphSp    = Get-MgServicePrincipal -Filter "AppId eq '00000003-0000-0000-c000-000000000000'"
$sitesRead  = $graphSp.AppRoles | Where-Object { $_.Value -eq "Sites.Read.All" }

Update-MgApplication -ApplicationId $app.Id -RequiredResourceAccess @{
    ResourceAppId  = "00000003-0000-0000-c000-000000000000"
    ResourceAccess = @(@{
        Id   = $sitesRead.Id
        Type = "Role"
    })
}

# Create client secret (12-month validity)
$secretCred = Add-MgApplicationPassword -ApplicationId $app.Id -PasswordCredential @{
    DisplayName = "NightLock-Sync-Secret"
    EndDateTime = (Get-Date).AddMonths(12)
}

# Create Service Principal and grant admin consent
$sp = New-MgServicePrincipal -AppId $app.AppId
New-MgServicePrincipalAppRoleAssignment -ServicePrincipalId $sp.Id `
    -PrincipalId $sp.Id `
    -ResourceId $graphSp.Id `
    -AppRoleId $sitesRead.Id | Out-Null

Write-Host "  App Registration created." -ForegroundColor Green

# ── 2. Create SharePoint List ─────────────────────────────────────────────────
Write-Host "Creating SharePoint List: $ListName..." -ForegroundColor Cyan
Connect-PnPOnline -Url $SharePointUrl -Interactive

$list = New-PnPList -Title $ListName -Template GenericList -EnableVersioning

# Add custom columns
Add-PnPField -List $ListName -DisplayName "UPN"          -InternalName "UPN"          -Type Text      -Required | Out-Null
Add-PnPField -List $ListName -DisplayName "ApprovedUntil"-InternalName "ApprovedUntil"-Type DateTime  -Required | Out-Null
Add-PnPField -List $ListName -DisplayName "Requester"    -InternalName "Requester"    -Type Text                | Out-Null
Add-PnPField -List $ListName -DisplayName "Reason"       -InternalName "Reason"       -Type Text                | Out-Null
Add-PnPField -List $ListName -DisplayName "Status"       -InternalName "Status"       -Type Choice    -Required `
    -Choices @("Approved","Revoked","Expired") | Out-Null

# Get Site ID for Graph API
$siteInfo  = Get-PnPSite -Includes Id
$siteId    = $siteInfo.Id
$listObj   = Get-PnPList -Identity $ListName
$listId    = $listObj.Id.ToString()

Write-Host "  SharePoint List created." -ForegroundColor Green

# ── Output ────────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "=========================================" -ForegroundColor Yellow
Write-Host "  Copy these values into settings.json" -ForegroundColor Yellow
Write-Host "=========================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "tenantId:            $TenantId"
Write-Host "clientId:            $($app.AppId)"
Write-Host "Client Secret:       $($secretCred.SecretText)"
Write-Host "  (Store securely! This is shown only once.)"
Write-Host ""
Write-Host "sharePointSiteId:    $siteId"
Write-Host "sharePointListId:    $listId"
Write-Host ""
Write-Host "=========================================" -ForegroundColor Yellow
Write-Host "REMINDER: Admin consent has been granted." -ForegroundColor Green
Write-Host "Secret expires: $(($secretCred.EndDateTime).ToString('yyyy-MM-dd'))" -ForegroundColor Yellow
Write-Host "Set a calendar reminder to rotate the secret before expiry!" -ForegroundColor Red
