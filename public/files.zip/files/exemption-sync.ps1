#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock - Exemption List Sync
    加班例外名单云端同步スクリプト
.DESCRIPTION
    Runs every 5 minutes via Scheduled Task.
    Pulls current overtime approvals from SharePoint List (via Graph API)
    and writes them to local allowedusers.json.
    Completely independent of Intune deployment cycle.
.NOTES
    Requires an Entra ID App Registration with:
    - Sites.Read.All (for SharePoint List read)
    - Application permission (client credentials flow, no user interaction)
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$INSTALL_DIR  = "C:\ProgramData\NightLock"
$LOG_DIR      = "$INSTALL_DIR\logs"
$CONFIG_FILE  = "$INSTALL_DIR\config\settings.json"
$EXEMPT_FILE  = "$INSTALL_DIR\config\allowedusers.json"
$EXEMPT_BACKUP= "$INSTALL_DIR\config\allowedusers.json.bak"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts      = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line    = "[$ts][$Level][exemption-sync] $Message"
    Write-Output $line
    $logFile = "$LOG_DIR\exemption-sync-$(Get-Date -Format 'yyyyMM').log"
    Add-Content -Path $logFile -Value $line -Encoding UTF8
}

# ── Get OAuth2 Token (Client Credentials) ────────────────────────────────────
function Get-GraphToken {
    param($Settings)

    $sync        = $Settings.exemptionSync
    $tenantId    = $sync.tenantId
    $clientId    = $sync.clientId

    # Client secret stored encrypted (DPAPI, LocalMachine scope)
    # Encrypted during install via: ConvertTo-SecureString | ConvertFrom-SecureString
    $secretFile  = "$INSTALL_DIR\config\.svc_secret"
    if (!(Test-Path $secretFile)) {
        throw "Service credential file not found: $secretFile"
    }
    $encSecret   = Get-Content $secretFile
    $secStr      = ConvertTo-SecureString $encSecret
    $clientSecret= [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
                       [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secStr)
                   )

    $tokenUrl    = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token"
    $body = @{
        grant_type    = "client_credentials"
        client_id     = $clientId
        client_secret = $clientSecret
        scope         = "https://graph.microsoft.com/.default"
    }

    $response = Invoke-RestMethod -Method Post -Uri $tokenUrl -Body $body `
                    -ContentType "application/x-www-form-urlencoded"
    return $response.access_token
}

# ── Read SharePoint List Items ────────────────────────────────────────────────
function Get-SharePointExemptions {
    param([string]$Token, $Settings)

    $sync      = $Settings.exemptionSync
    $siteId    = $sync.sharePointSiteId    # e.g. "contoso.sharepoint.com,abc123,def456"
    $listId    = $sync.sharePointListId    # GUID of the list
    $now       = [uri]::EscapeDataString((Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"))

    # Filter: only active approvals (ApprovedUntil > now AND Status == 'Approved')
    $filter    = "fields/Status eq 'Approved' and fields/ApprovedUntil gt '$now'"
    $select    = "fields/UPN,fields/ApprovedUntil,fields/Requester,fields/Reason"
    $url       = "https://graph.microsoft.com/v1.0/sites/$siteId/lists/$listId/items" +
                 "?`$filter=$filter&`$expand=$select&`$top=500"

    $headers   = @{ Authorization = "Bearer $Token" }
    $response  = Invoke-RestMethod -Method Get -Uri $url -Headers $headers

    $exemptions = @()
    foreach ($item in $response.value) {
        $f = $item.fields
        if ($f.UPN -and $f.ApprovedUntil) {
            $exemptions += [PSCustomObject]@{
                username     = $f.UPN.Split("@")[0]   # SAM account name
                upn          = $f.UPN
                approvedUntil= $f.ApprovedUntil
                requester    = $f.Requester
                reason       = $f.Reason
            }
        }
    }
    return $exemptions
}

# ── Write Local Exemption Cache ───────────────────────────────────────────────
function Write-ExemptionCache {
    param($Exemptions)

    # Backup current file before overwriting
    if (Test-Path $EXEMPT_FILE) {
        Copy-Item $EXEMPT_FILE $EXEMPT_BACKUP -Force
    }

    $output = @{
        lastSynced  = (Get-Date -Format "o")
        syncSource  = "SharePoint"
        exemptions  = $Exemptions
    }

    $json = $output | ConvertTo-Json -Depth 5
    Set-Content -Path $EXEMPT_FILE -Value $json -Encoding UTF8
    Write-Log "Exemption cache written: $($Exemptions.Count) active exemption(s)"
}

# ── Fallback: Use Backup If Sync Fails ───────────────────────────────────────
function Restore-BackupIfNeeded {
    if (Test-Path $EXEMPT_BACKUP) {
        Write-Log "Using backup exemption list as fallback." "WARN"
        Copy-Item $EXEMPT_BACKUP $EXEMPT_FILE -Force
    } else {
        Write-Log "No backup available. Exemption list may be stale." "WARN"
    }
}

# ── Health Check: Report Sync Status ─────────────────────────────────────────
function Write-SyncHealthStatus {
    param([bool]$Success, [int]$Count = 0, [string]$Error = "")

    $status = @{
        timestamp = (Get-Date -Format "o")
        success   = $Success
        count     = $Count
        error     = $Error
        hostname  = $env:COMPUTERNAME
    }
    $healthFile = "$INSTALL_DIR\logs\sync-health.json"
    $status | ConvertTo-Json | Set-Content -Path $healthFile -Encoding UTF8
}

# ── Main ─────────────────────────────────────────────────────────────────────
try {
    Write-Log "===== Exemption sync START ====="

    if (!(Test-Path $CONFIG_FILE)) {
        Write-Log "settings.json not found. Skipping sync." "WARN"
        exit 0
    }

    $settings = Get-Content $CONFIG_FILE | ConvertFrom-Json

    if (!$settings.exemptionSync.enabled) {
        Write-Log "Exemption sync disabled in settings. Skipping."
        exit 0
    }

    $token       = Get-GraphToken -Settings $settings
    Write-Log "Graph token acquired."

    $exemptions  = Get-SharePointExemptions -Token $token -Settings $settings
    Write-Log "Retrieved $($exemptions.Count) active exemption(s) from SharePoint."

    foreach ($e in $exemptions) {
        Write-Log "  Active: $($e.username) until $($e.approvedUntil) (reason: $($e.reason))"
    }

    Write-ExemptionCache -Exemptions $exemptions
    Write-SyncHealthStatus -Success $true -Count $exemptions.Count
    Write-Log "===== Exemption sync END ====="
    exit 0
}
catch {
    Write-Log "Sync FAILED: $($_.Exception.Message)" "ERROR"
    Restore-BackupIfNeeded
    Write-SyncHealthStatus -Success $false -Error $_.Exception.Message
    # Do NOT re-throw: a failed sync is non-fatal, use cached data
    exit 0
}
