#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Access Control System - Installer
    夜間ログオン制限システム インストーラー
.DESCRIPTION
    Deploys NightLock components via Intune Win32 App:
    - Copies all scripts and config files to C:\ProgramData\NightLock\
    - Installs NightLock Windows Service (nightlock-service.ps1)
    - Registers Scheduled Tasks (primary + fallback)
    - Creates local Break Glass account
.VERSION
    2.0.0
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── Constants ────────────────────────────────────────────────────────────────
$INSTALL_DIR    = "C:\ProgramData\NightLock"
$LOG_DIR        = "$INSTALL_DIR\logs"
$CONFIG_DIR     = "$INSTALL_DIR\config"
$SCRIPT_DIR     = "$INSTALL_DIR\scripts"
$SERVICE_NAME   = "NightLockSvc"
$SERVICE_DISPLAY= "NightLock Access Control Service"
$VERSION_FILE   = "$INSTALL_DIR\version.txt"
$CURRENT_VERSION= "2.0.0"

# Source path (Intune deploys to this temp location)
$SOURCE_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path

# ── Logging ──────────────────────────────────────────────────────────────────
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$timestamp][$Level] $Message"
    Write-Output $line
    if (!(Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR -Force | Out-Null }
    Add-Content -Path "$LOG_DIR\install.log" -Value $line -Encoding UTF8
}

# ── Version Check (Intune detection rule uses version.txt) ───────────────────
function Test-AlreadyInstalled {
    if (Test-Path $VERSION_FILE) {
        $installed = Get-Content $VERSION_FILE -Raw
        if ($installed.Trim() -eq $CURRENT_VERSION) {
            Write-Log "Version $CURRENT_VERSION already installed. Skipping."
            return $true
        }
    }
    return $false
}

# ── Directory Setup ──────────────────────────────────────────────────────────
function Initialize-Directories {
    Write-Log "Creating directory structure..."
    @($INSTALL_DIR, $LOG_DIR, $CONFIG_DIR, $SCRIPT_DIR) | ForEach-Object {
        if (!(Test-Path $_)) {
            New-Item -ItemType Directory -Path $_ -Force | Out-Null
            Write-Log "  Created: $_"
        }
    }

    # Restrict access: SYSTEM + Administrators only (employees cannot tamper)
    $acl = Get-Acl $INSTALL_DIR
    $acl.SetAccessRuleProtection($true, $false)
    $acl.Access | ForEach-Object { $acl.RemoveAccessRule($_) | Out-Null }
    @("SYSTEM", "BUILTIN\Administrators") | ForEach-Object {
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $_, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow"
        )
        $acl.AddAccessRule($rule)
    }
    Set-Acl -Path $INSTALL_DIR -AclObject $acl
    Write-Log "Directory ACL secured."
}

# ── Copy Scripts ─────────────────────────────────────────────────────────────
function Copy-Scripts {
    Write-Log "Copying scripts..."
    $filesToCopy = @(
        "nightlogoff.ps1",
        "logincheck.ps1",
        "exemption-sync.ps1",
        "nightlock-service.ps1"
    )
    foreach ($file in $filesToCopy) {
        $src = Join-Path $SOURCE_DIR $file
        $dst = Join-Path $SCRIPT_DIR $file
        if (Test-Path $src) {
            Copy-Item -Path $src -Destination $dst -Force
            Write-Log "  Copied: $file"
        } else {
            Write-Log "  WARNING: $file not found in source. Skipping." "WARN"
        }
    }
}

# ── Copy Config Files ─────────────────────────────────────────────────────────
function Copy-ConfigFiles {
    Write-Log "Copying config files..."
    $configFiles = @("settings.json", "allowedusers.json")
    foreach ($file in $configFiles) {
        $src = Join-Path $SOURCE_DIR $file
        $dst = Join-Path $CONFIG_DIR $file
        # Never overwrite allowedusers.json if it exists (preserves local exemptions)
        if ($file -eq "allowedusers.json" -and (Test-Path $dst)) {
            Write-Log "  Skipped: $file (already exists, preserving local exemptions)"
            continue
        }
        if (Test-Path $src) {
            Copy-Item -Path $src -Destination $dst -Force
            Write-Log "  Copied: $file"
        }
    }
}

# ── Install Windows Service ───────────────────────────────────────────────────
function Install-NightLockService {
    Write-Log "Installing NightLock Windows Service (native sc.exe)..."

    # 停止并删除旧服务（幂等）
    $existingSvc = Get-Service -Name $SERVICE_NAME -ErrorAction SilentlyContinue
    if ($existingSvc) {
        Write-Log "  Stopping existing service..."
        Stop-Service -Name $SERVICE_NAME -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
        sc.exe delete $SERVICE_NAME | Out-Null
        Start-Sleep -Seconds 2
    }

    $serviceScript = "$SCRIPT_DIR\nightlock-service.ps1"
    $pwsh = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"

    # BinaryPathName にスペースが含まれる場合に備えてエスケープ
    $binPath = "`"$pwsh`" -NonInteractive -NoProfile -ExecutionPolicy Bypass -File `"$serviceScript`""

    New-Service `
        -Name        $SERVICE_NAME `
        -BinaryPathName $binPath `
        -DisplayName $SERVICE_DISPLAY `
        -Description "NightLock enforces after-hours logoff policy and syncs exemption lists." `
        -StartupType Automatic | Out-Null

    # クラッシュ時の自動再起動ポリシー
    # reset=3600: 1時間後に失敗カウントリセット
    # actions: 1回目5秒後, 2回目10秒後, 3回目以降30秒後に再起動
    sc.exe failure $SERVICE_NAME reset= 3600 actions= restart/5000/restart/10000/restart/30000 | Out-Null

    Start-Service -Name $SERVICE_NAME
    Write-Log "  Service installed and started: $SERVICE_NAME"
}

# ── Register Scheduled Tasks ──────────────────────────────────────────────────
function Register-ScheduledTasks {
    Write-Log "Registering Scheduled Tasks..."

    $pwsh = "powershell.exe"
    $flags = "-NonInteractive -NoProfile -ExecutionPolicy Bypass"

    # ── Task 1: Primary logoff at 22:00 ──────────────────────────────────────
    $taskName1 = "NightLock-LogoffAt2200"
    Unregister-ScheduledTask -TaskName $taskName1 -Confirm:$false -ErrorAction SilentlyContinue
    $trigger1  = New-ScheduledTaskTrigger -Daily -At "22:00"
    $action1   = New-ScheduledTaskAction -Execute $pwsh `
                    -Argument "$flags -File `"$SCRIPT_DIR\nightlogoff.ps1`""
    $settings1 = New-ScheduledTaskSettingsSet `
                    -StartWhenAvailable `
                    -RunOnlyIfNetworkAvailable:$false `
                    -ExecutionTimeLimit (New-TimeSpan -Minutes 5) `
                    -RestartCount 2 -RestartInterval (New-TimeSpan -Minutes 1)
    Register-ScheduledTask -TaskName $taskName1 `
        -Trigger $trigger1 -Action $action1 -Settings $settings1 `
        -RunLevel Highest -User "SYSTEM" -Force | Out-Null
    Write-Log "  Registered: $taskName1"

    # ── Task 2: Interval check every 10min during restricted hours ───────────
    $taskName2 = "NightLock-IntervalCheck"
    Unregister-ScheduledTask -TaskName $taskName2 -Confirm:$false -ErrorAction SilentlyContinue

    # Trigger: daily 22:00 → repeat every 10min → duration 7hrs (until 05:00)
    $trigger2 = New-ScheduledTaskTrigger -Daily -At "22:00"
    $trigger2.Repetition = (New-CimInstance -CimClass (
        Get-CimClass -Namespace Root/Microsoft/Windows/TaskScheduler -ClassName MSFT_TaskRepetitionPattern
    ) -Property @{
        Interval = "PT10M"
        Duration = "PT7H"
        StopAtDurationEnd = $true
    } -ClientOnly)

    $action2 = New-ScheduledTaskAction -Execute $pwsh `
                  -Argument "$flags -File `"$SCRIPT_DIR\nightlogoff.ps1`""
    $settings2 = New-ScheduledTaskSettingsSet `
                    -StartWhenAvailable `
                    -RunOnlyIfNetworkAvailable:$false `
                    -ExecutionTimeLimit (New-TimeSpan -Minutes 5) `
                    -MultipleInstances IgnoreNew
    Register-ScheduledTask -TaskName $taskName2 `
        -Trigger $trigger2 -Action $action2 -Settings $settings2 `
        -RunLevel Highest -User "SYSTEM" -Force | Out-Null
    Write-Log "  Registered: $taskName2"

    # ── Task 3: On-logon immediate check ─────────────────────────────────────
    $taskName3 = "NightLock-OnLogon"
    Unregister-ScheduledTask -TaskName $taskName3 -Confirm:$false -ErrorAction SilentlyContinue
    $trigger3  = New-ScheduledTaskTrigger -AtLogOn
    $action3   = New-ScheduledTaskAction -Execute $pwsh `
                    -Argument "$flags -File `"$SCRIPT_DIR\logincheck.ps1`""
    $settings3 = New-ScheduledTaskSettingsSet `
                    -StartWhenAvailable `
                    -RunOnlyIfNetworkAvailable:$false `
                    -ExecutionTimeLimit (New-TimeSpan -Minutes 2)
    Register-ScheduledTask -TaskName $taskName3 `
        -Trigger $trigger3 -Action $action3 -Settings $settings3 `
        -RunLevel Highest -User "SYSTEM" -Force | Out-Null
    Write-Log "  Registered: $taskName3"

    # ── Task 4: Exemption list sync every 5min ───────────────────────────────
    $taskName4 = "NightLock-ExemptionSync"
    Unregister-ScheduledTask -TaskName $taskName4 -Confirm:$false -ErrorAction SilentlyContinue
    $trigger4 = New-ScheduledTaskTrigger -RepetitionInterval (New-TimeSpan -Minutes 5) `
                    -Once -At (Get-Date)
    $action4  = New-ScheduledTaskAction -Execute $pwsh `
                    -Argument "$flags -File `"$SCRIPT_DIR\exemption-sync.ps1`""
    $settings4 = New-ScheduledTaskSettingsSet `
                    -StartWhenAvailable `
                    -RunOnlyIfNetworkAvailable:$false `
                    -ExecutionTimeLimit (New-TimeSpan -Minutes 3) `
                    -MultipleInstances IgnoreNew
    Register-ScheduledTask -TaskName $taskName4 `
        -Trigger $trigger4 -Action $action4 -Settings $settings4 `
        -RunLevel Highest -User "SYSTEM" -Force | Out-Null
    Write-Log "  Registered: $taskName4"
}

# ── Create Break Glass Local Account ─────────────────────────────────────────
function New-BreakGlassAccount {
    Write-Log "Configuring Break Glass local account..."

    # Read break glass settings from config
    $settings = Get-Content "$CONFIG_DIR\settings.json" | ConvertFrom-Json
    $bgUser   = $settings.breakGlass.username

    $existingUser = Get-LocalUser -Name $bgUser -ErrorAction SilentlyContinue
    if ($existingUser) {
        Write-Log "  Break Glass account '$bgUser' already exists. Skipping creation."
        return
    }

    # Generate a strong random password (128-bit entropy)
    $chars    = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+"
    $rng      = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    $bytes    = New-Object byte[] 24
    $rng.GetBytes($bytes)
    $password = -join ($bytes | ForEach-Object { $chars[$_ % $chars.Length] })
    $secPwd   = ConvertTo-SecureString $password -AsPlainText -Force

    New-LocalUser -Name $bgUser -Password $secPwd `
        -Description "NightLock Break Glass - Emergency Access Only" `
        -PasswordNeverExpires:$true -UserMayNotChangePassword:$true | Out-Null
    Add-LocalGroupMember -Group "Administrators" -Member $bgUser | Out-Null

    # Log password securely (masked in log file, written to secure location)
    # IMPORTANT: In production, store this in Azure Key Vault or LAPS instead
    $credFile = "$INSTALL_DIR\breakglass.enc"
    $password | ConvertTo-SecureString -AsPlainText -Force |
        ConvertFrom-SecureString | Out-File $credFile -Encoding ASCII
    Write-Log "  Break Glass account '$bgUser' created. Credentials stored in $credFile"
    Write-Log "  ACTION REQUIRED: Retrieve and store credential in LAPS/Key Vault, then delete $credFile" "WARN"
}

# ── Firewall: Block outbound policy tampering port ───────────────────────────
function Set-FirewallRules {
    # Optional: prevent employees from disabling the sync endpoint
    # Customize as needed for your environment
    Write-Log "Firewall rules: no changes (managed by Intune baseline)."
}

# ── Write Version Marker (Intune detection file) ──────────────────────────────
function Write-VersionMarker {
    Set-Content -Path $VERSION_FILE -Value $CURRENT_VERSION -Encoding ASCII
    Write-Log "Version marker written: $CURRENT_VERSION"
}

# ── Main ─────────────────────────────────────────────────────────────────────
try {
    Write-Log "========================================="
    Write-Log "NightLock Installer v$CURRENT_VERSION starting"
    Write-Log "========================================="

    # Idempotency check
    if (Test-AlreadyInstalled) { exit 0 }

    Initialize-Directories
    Copy-Scripts
    Copy-ConfigFiles
    Install-NightLockService
    Register-ScheduledTasks
    New-BreakGlassAccount
    Set-FirewallRules
    Write-VersionMarker

    Write-Log "========================================="
    Write-Log "Installation completed successfully."
    Write-Log "========================================="
    exit 0
}
catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log $_.ScriptStackTrace "ERROR"
    exit 1
}
