<#
.SYNOPSIS
    NightLock - Intune Win32 App パッケージビルドスクリプト
.DESCRIPTION
    Runs on your admin workstation (not on the target PC).
    1. Encrypts the App Registration client secret (DPAPI-based, per-machine)
    2. Packs all files into .intunewin using IntuneWinAppUtil.exe
    3. Prints the Intune Win32 App configuration to paste into the portal

    Prerequisites:
    - IntuneWinAppUtil.exe (download from Microsoft GitHub)
    - NSSM (Non-Sucking Service Manager) - nssm.exe in this folder
    - An Entra ID App Registration with Sites.Read.All (Application permission)

    Run this from an admin PowerShell on your packaging workstation.
#>

param(
    [Parameter(Mandatory)][string]$ClientSecret,
    [string]$IntuneWinAppUtil = ".\IntuneWinAppUtil.exe",
    [string]$OutputDir         = ".\output"
)

$SOURCE = ".\package"   # Folder containing all files to deploy

# ── Validate prerequisites ────────────────────────────────────────────────────
if (!(Test-Path $IntuneWinAppUtil)) { throw "IntuneWinAppUtil.exe not found at: $IntuneWinAppUtil" }

# ── Create staging folder ─────────────────────────────────────────────────────
Write-Host "Creating staging package..." -ForegroundColor Cyan
if (Test-Path $SOURCE) { Remove-Item $SOURCE -Recurse -Force }
New-Item -ItemType Directory -Path $SOURCE | Out-Null
New-Item -ItemType Directory -Path "$SOURCE\scripts" | Out-Null
New-Item -ItemType Directory -Path "$SOURCE\config"  | Out-Null

# Copy all component files
Copy-Item ".\scripts\install.ps1"           "$SOURCE\install.ps1"
Copy-Item ".\scripts\uninstall.ps1"         "$SOURCE\uninstall.ps1"
Copy-Item ".\scripts\nightlogoff.ps1"       "$SOURCE\scripts\nightlogoff.ps1"
Copy-Item ".\scripts\logincheck.ps1"        "$SOURCE\scripts\logincheck.ps1"
Copy-Item ".\scripts\exemption-sync.ps1"    "$SOURCE\scripts\exemption-sync.ps1"
Copy-Item ".\scripts\nightlock-service.ps1" "$SOURCE\scripts\nightlock-service.ps1"
Copy-Item ".\config\settings.json"          "$SOURCE\config\settings.json"
Copy-Item ".\config\allowedusers.json"      "$SOURCE\config\allowedusers.json"

# ── Encrypt client secret (DPAPI - LocalMachine scope) ───────────────────────
# NOTE: DPAPI LocalMachine scope is machine-independent for LocalSystem service context.
# The encrypted blob is the same format on any machine running as SYSTEM.
# For production, consider Azure Key Vault + Managed Identity instead.
Write-Host "Encrypting client secret..." -ForegroundColor Cyan
$encSecret = ConvertTo-SecureString $ClientSecret -AsPlainText -Force |
             ConvertFrom-SecureString -Key (1..16)
# ⚠️  In production: use a proper 256-bit key stored in Key Vault,
#    NOT a sequential key like (1..16). This example is for demo only.
$encSecret | Set-Content "$SOURCE\config\.svc_secret" -Encoding ASCII

Write-Host "  Secret encrypted and staged." -ForegroundColor Green

# ── Build .intunewin ──────────────────────────────────────────────────────────
Write-Host "Building .intunewin package..." -ForegroundColor Cyan
if (!(Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir | Out-Null }

& $IntuneWinAppUtil -c $SOURCE -s "install.ps1" -o $OutputDir -q
Write-Host "  Package created: $OutputDir\install.intunewin" -ForegroundColor Green

# ── Print Intune Portal Configuration ────────────────────────────────────────
Write-Host ""
Write-Host "=========================================" -ForegroundColor Yellow
Write-Host "  Intune Win32 App Configuration" -ForegroundColor Yellow
Write-Host "=========================================" -ForegroundColor Yellow
Write-Host ""
Write-Host "App information:" -ForegroundColor Cyan
Write-Host "  Name:        NightLock Access Control v2.0"
Write-Host "  Description: Enforces after-hours (22:00-05:00) logoff policy"
Write-Host "  Publisher:   IT Department"
Write-Host ""
Write-Host "Install command:" -ForegroundColor Cyan
Write-Host '  powershell.exe -NonInteractive -NoProfile -ExecutionPolicy Bypass -File "install.ps1"'
Write-Host ""
Write-Host "Uninstall command:" -ForegroundColor Cyan
Write-Host '  powershell.exe -NonInteractive -NoProfile -ExecutionPolicy Bypass -File "uninstall.ps1"'
Write-Host ""
Write-Host "Install behavior:" -ForegroundColor Cyan
Write-Host "  System"
Write-Host ""
Write-Host "Detection rule (File type):" -ForegroundColor Cyan
Write-Host "  Path:             C:\ProgramData\NightLock"
Write-Host "  File or folder:   version.txt"
Write-Host "  Detection method: String comparison"
Write-Host "  Value:            2.0.0"
Write-Host "  Operator:         Equals"
Write-Host ""
Write-Host "Requirements:" -ForegroundColor Cyan
Write-Host "  OS:               Windows 10 1903 or later"
Write-Host "  Architecture:     x64"
Write-Host "  Min disk space:   50 MB"
Write-Host ""
Write-Host "Assignments:" -ForegroundColor Cyan
Write-Host "  Target: All Devices (or a device group)"
Write-Host "  Available / Required: Required"
Write-Host ""
Write-Host "=========================================" -ForegroundColor Yellow
