#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Windows Service - Real-time Session Monitor
    リアルタイムセッション監視サービス
.DESCRIPTION
    Runs as a Windows Service via NSSM.
    Uses WMI event subscription to react to session logon/logoff events in real-time.
    Complements the Scheduled Tasks (which handle the periodic sweeps).
    This catches edge cases: RDP reconnects, Fast User Switching, wake-from-sleep logins.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "SilentlyContinue"

$INSTALL_DIR  = "C:\ProgramData\NightLock"
$LOG_DIR      = "$INSTALL_DIR\logs"
$CONFIG_FILE  = "$INSTALL_DIR\config\settings.json"
$EXEMPT_FILE  = "$INSTALL_DIR\config\allowedusers.json"
$KILL_SWITCH  = "$INSTALL_DIR\MAINTENANCE_MODE"
$HEARTBEAT    = "$INSTALL_DIR\logs\service-heartbeat.json"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts      = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line    = "[$ts][$Level][service] $Message"
    Write-Output $line
    $logFile = "$LOG_DIR\service-$(Get-Date -Format 'yyyyMM').log"
    Add-Content -Path $logFile -Value $line -Encoding UTF8
}

function Update-Heartbeat {
    @{
        timestamp = (Get-Date -Format "o")
        hostname  = $env:COMPUTERNAME
        status    = "running"
        pid       = $PID
    } | ConvertTo-Json | Set-Content -Path $HEARTBEAT -Encoding UTF8
}

function Get-Settings {
    try {
        return Get-Content $CONFIG_FILE | ConvertFrom-Json
    } catch {
        return $null
    }
}

function Get-ExemptUsers {
    param($Settings)
    $exempt = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )
    if ($null -eq $Settings) { return $exempt }

    foreach ($u in $Settings.permanentExemptions) { $exempt.Add($u) | Out-Null }
    $exempt.Add($Settings.breakGlass.username) | Out-Null

    if (Test-Path $EXEMPT_FILE) {
        try {
            $data = Get-Content $EXEMPT_FILE | ConvertFrom-Json
            $now  = Get-Date
            foreach ($e in $data.exemptions) {
                if ([datetime]::Parse($e.approvedUntil) -gt $now) {
                    $exempt.Add($e.username) | Out-Null
                }
            }
        } catch {}
    }
    return $exempt
}

function Test-RestrictedHours {
    param($Settings)
    if ($null -eq $Settings) { return $false }
    $hour = (Get-Date).Hour
    return ($hour -ge $Settings.restrictedHours.startHour) -or
           ($hour -lt $Settings.restrictedHours.endHour)
}

function Invoke-UserCheck {
    param([string]$Username, [int]$SessionId)

    Write-Log "Session event: user='$Username', session=$SessionId"

    if (Test-Path $KILL_SWITCH) {
        Write-Log "MAINTENANCE MODE. Skipping check." "WARN"
        return
    }

    $settings = Get-Settings
    if ($null -eq $settings -or !$settings.enabled) { return }
    if (!(Test-RestrictedHours -Settings $settings)) { return }

    $exempt = Get-ExemptUsers -Settings $settings
    if ($exempt.Contains($Username)) {
        Write-Log "User '$Username' is exempt."
        return
    }

    Write-Log "User '$Username' NOT exempt during restricted hours. Initiating logoff." "WARN"

    $warningSeconds = $settings.warningBeforeLogoffSeconds
    $msg = "【NightLock】夜間アクセス制限 / After-Hours Restriction`n" +
           "${warningSeconds}秒後に自動ログオフされます。作業を保存してください。`n" +
           "You will be logged off in ${warningSeconds} seconds. Please save your work."

    msg $SessionId /TIME:$warningSeconds $msg 2>&1 | Out-Null
    Start-Sleep -Seconds $warningSeconds
    logoff $SessionId 2>&1 | Out-Null
    Write-Log "LOGOFF: '$Username' (session $SessionId)" "WARN"
}

# ── WMI Event Subscription for Session Logon ─────────────────────────────────
function Register-SessionEvents {
    Write-Log "Registering WMI session event watcher..."

    # Win32_LogonSession: Type 2 = Interactive, Type 10 = RemoteInteractive (RDP)
    $query = "SELECT * FROM __InstanceCreationEvent WITHIN 5 " +
             "WHERE TargetInstance ISA 'Win32_LogonSession' " +
             "AND (TargetInstance.LogonType = 2 OR TargetInstance.LogonType = 10)"

    $watcher = New-Object System.Management.ManagementEventWatcher
    $watcher.Query = New-Object System.Management.WqlEventQuery($query)
    $watcher.Scope = New-Object System.Management.ManagementScope("\\.\root\cimv2")
    $watcher.Options.Timeout = [System.TimeSpan]::FromSeconds(30)

    return $watcher
}

# ── Main Service Loop ─────────────────────────────────────────────────────────
Write-Log "NightLock Service starting (PID: $PID)"
Update-Heartbeat

# Register Event Source
if (![System.Diagnostics.EventLog]::SourceExists("NightLock")) {
    New-EventLog -LogName Application -Source "NightLock" -ErrorAction SilentlyContinue
}

$watcher = Register-SessionEvents
$watcher.Start()
Write-Log "WMI event watcher started."

$heartbeatInterval = 60   # seconds between heartbeat updates
$lastHeartbeat     = Get-Date

while ($true) {
    try {
        # Update heartbeat
        if (((Get-Date) - $lastHeartbeat).TotalSeconds -ge $heartbeatInterval) {
            Update-Heartbeat
            $lastHeartbeat = Get-Date
        }

        # Wait for WMI event (30s timeout, then loop)
        $event = $watcher.WaitForNextEvent()

        $logonSession = $event.NewEvent.TargetInstance
        $logonId      = $logonSession.LogonId

        # Resolve username from logon session
        $assoc = Get-CimInstance -Query "ASSOCIATORS OF {Win32_LogonSession.LogonId='$logonId'} WHERE AssocClass=Win32_LoggedOnUser" -ErrorAction SilentlyContinue
        if ($assoc) {
            $username  = $assoc.Name
            # Get session ID from quser
            $quserOut = quser 2>&1 | Where-Object { $_ -match $username }
            $sessionId = -1
            if ($quserOut -match "\s+(\d+)\s+") { $sessionId = [int]$Matches[1] }

            if ($username -and $sessionId -ge 0) {
                Invoke-UserCheck -Username $username -SessionId $sessionId
            }
        }
    }
    catch [System.Management.ManagementException] {
        # WMI timeout - normal, just loop
        continue
    }
    catch {
        Write-Log "Service loop error: $($_.Exception.Message)" "ERROR"
        Start-Sleep -Seconds 10

        # Re-register watcher if it died
        try {
            $watcher.Stop()
            $watcher.Dispose()
            $watcher = Register-SessionEvents
            $watcher.Start()
            Write-Log "WMI watcher re-registered after error."
        } catch {
            Write-Log "Failed to re-register WMI watcher: $($_.Exception.Message)" "ERROR"
            Start-Sleep -Seconds 30
        }
    }
}
