#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock - On-Logon Check
    ユーザーログオン時即時チェック
.DESCRIPTION
    Triggered by "At logon" Scheduled Task.
    If user logs on during restricted hours and is not exempt, logs them off immediately.
    This handles the gap where the interval task hasn't fired yet after a new logon.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$INSTALL_DIR = "C:\ProgramData\NightLock"
$LOG_DIR     = "$INSTALL_DIR\logs"
$CONFIG_FILE = "$INSTALL_DIR\config\settings.json"
$EXEMPT_FILE = "$INSTALL_DIR\config\allowedusers.json"
$KILL_SWITCH = "$INSTALL_DIR\MAINTENANCE_MODE"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts      = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line    = "[$ts][$Level][logincheck] $Message"
    Write-Output $line
    $logFile = "$LOG_DIR\logincheck-$(Get-Date -Format 'yyyyMM').log"
    Add-Content -Path $logFile -Value $line -Encoding UTF8
}

function Test-RestrictedHours {
    param($Settings)
    $hour      = (Get-Date).Hour
    $startHour = $Settings.restrictedHours.startHour
    $endHour   = $Settings.restrictedHours.endHour
    return ($hour -ge $startHour) -or ($hour -lt $endHour)
}

function Get-ExemptUsers {
    param($Settings)
    $exempt = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )
    foreach ($u in $Settings.permanentExemptions) { $exempt.Add($u) | Out-Null }
    $exempt.Add($Settings.breakGlass.username) | Out-Null

    if (Test-Path $EXEMPT_FILE) {
        try {
            $exemptions = Get-Content $EXEMPT_FILE | ConvertFrom-Json
            $now = Get-Date
            foreach ($entry in $exemptions.exemptions) {
                if ([datetime]::Parse($entry.approvedUntil) -gt $now) {
                    $exempt.Add($entry.username) | Out-Null
                }
            }
        } catch {
            Write-Log "Could not parse allowedusers.json: $($_.Exception.Message)" "WARN"
        }
    }
    return $exempt
}

function Get-LoggedOnUser {
    # Get the user who just logged on (current interactive session)
    # In SYSTEM context, query the newest non-SYSTEM session
    try {
        $sessions = query session 2>&1 | Where-Object { $_ -match "Active" }
        foreach ($line in $sessions) {
            if ($line -match "^\s*(\S+)\s+(\S+)\s+(\d+)\s+Active") {
                $username = $Matches[2]
                $sessionId = [int]$Matches[3]
                if ($username -notin @("SYSTEM","DWM-1","DWM-2","UMFD-0","UMFD-1")) {
                    return [PSCustomObject]@{ Username = $username; SessionId = $sessionId }
                }
            }
        }
    } catch {}

    # Fallback: Explorer process owner (most recently logged-on interactive user)
    try {
        $explorer = Get-CimInstance Win32_Process -Filter "Name='explorer.exe'" |
            Select-Object -First 1
        if ($explorer) {
            $owner = Invoke-CimMethod -InputObject $explorer -MethodName GetOwner
            return [PSCustomObject]@{
                Username  = $owner.User
                SessionId = $explorer.SessionId
            }
        }
    } catch {}

    return $null
}

# ── Main ─────────────────────────────────────────────────────────────────────
try {
    # Small delay to let the desktop session fully establish
    Start-Sleep -Seconds 5

    if (Test-Path $KILL_SWITCH) {
        Write-Log "MAINTENANCE MODE active. Login check suspended." "WARN"
        exit 0
    }

    $settings = Get-Content $CONFIG_FILE | ConvertFrom-Json
    if (!$settings.enabled) { exit 0 }

    if (!(Test-RestrictedHours -Settings $settings)) {
        Write-Log "Login at non-restricted hour. Allowed."
        exit 0
    }

    $currentUser = Get-LoggedOnUser
    if (!$currentUser) {
        Write-Log "Could not determine logged-on user. Falling back to nightlogoff." "WARN"
        # Delegate to full enforcement script
        & "$INSTALL_DIR\scripts\nightlogoff.ps1"
        exit 0
    }

    Write-Log "Logon detected during restricted hours: $($currentUser.Username)"

    $exemptUsers = Get-ExemptUsers -Settings $settings
    if ($exemptUsers.Contains($currentUser.Username)) {
        Write-Log "User $($currentUser.Username) is EXEMPT. Allowing."
        exit 0
    }

    # Not exempt: warn and logoff
    $warningSeconds = $settings.warningBeforeLogoffSeconds
    $msg = "【NightLock】夜間アクセス制限 / After-Hours Restriction`n`n" +
           "このPCは $($settings.restrictedHours.startHour):00 ～ $($settings.restrictedHours.endHour):00 の間は利用できません。`n" +
           "${warningSeconds}秒後に自動ログオフされます。`n`n" +
           "Access is restricted from $($settings.restrictedHours.startHour):00 to $($settings.restrictedHours.endHour):00.`n" +
           "You will be logged off in ${warningSeconds} seconds.`n`n" +
           "残業許可は事前にIT部門へ申請してください。"

    msg $($currentUser.SessionId) /TIME:$warningSeconds $msg 2>&1 | Out-Null
    Write-Log "Warning sent to $($currentUser.Username), waiting ${warningSeconds}s..."
    Start-Sleep -Seconds $warningSeconds

    logoff $($currentUser.SessionId) 2>&1 | Out-Null
    Write-Log "LOGOFF: $($currentUser.Username) (session $($currentUser.SessionId))" "WARN"

    Write-EventLog -LogName Application -Source "NightLock" -EventId 4002 `
        -EntryType Warning -Message "Logon denied (restricted hours): $($currentUser.Username)" `
        -ErrorAction SilentlyContinue
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)" "ERROR"
    exit 1
}
