#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock - Main Enforcement Script (22:00 → 05:00)
    夜間ログオン制限 メイン強制ログオフスクリプト
.DESCRIPTION
    Triggered by Scheduled Tasks at 22:00 and every 10min thereafter.
    Checks all active/disconnected sessions and logs off non-exempt users.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── Paths ────────────────────────────────────────────────────────────────────
$INSTALL_DIR  = "C:\ProgramData\NightLock"
$LOG_DIR      = "$INSTALL_DIR\logs"
$CONFIG_FILE  = "$INSTALL_DIR\config\settings.json"
$EXEMPT_FILE  = "$INSTALL_DIR\config\allowedusers.json"
$KILL_SWITCH  = "$INSTALL_DIR\MAINTENANCE_MODE"   # touch this file to pause enforcement

# ── Logging ──────────────────────────────────────────────────────────────────
function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts][$Level][nightlogoff] $Message"
    Write-Output $line
    $logFile = "$LOG_DIR\nightlogoff-$(Get-Date -Format 'yyyyMM').log"
    Add-Content -Path $logFile -Value $line -Encoding UTF8

    # Log rotation: keep last 3 months
    Get-ChildItem "$LOG_DIR\nightlogoff-*.log" |
        Where-Object { $_.LastWriteTime -lt (Get-Date).AddMonths(-3) } |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

# ── Kill Switch ───────────────────────────────────────────────────────────────
function Test-MaintenanceMode {
    if (Test-Path $KILL_SWITCH) {
        Write-Log "MAINTENANCE MODE active. Enforcement suspended." "WARN"
        return $true
    }
    return $false
}

# ── Load Settings ─────────────────────────────────────────────────────────────
function Get-Settings {
    if (!(Test-Path $CONFIG_FILE)) {
        throw "settings.json not found at $CONFIG_FILE"
    }
    return Get-Content $CONFIG_FILE | ConvertFrom-Json
}

# ── Load Exemption List ───────────────────────────────────────────────────────
function Get-ExemptUsers {
    param($Settings)

    $exemptUsers = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )

    # 1. Permanent exclusions from settings.json
    foreach ($u in $Settings.permanentExemptions) {
        $exemptUsers.Add($u) | Out-Null
    }

    # 2. Break glass account - always excluded (hardcoded failsafe)
    $exemptUsers.Add($Settings.breakGlass.username) | Out-Null

    # 3. Dynamic exemptions from allowedusers.json (overtime approvals)
    if (Test-Path $EXEMPT_FILE) {
        try {
            $exemptions = Get-Content $EXEMPT_FILE | ConvertFrom-Json
            $now = Get-Date
            foreach ($entry in $exemptions.exemptions) {
                $expiry = [datetime]::Parse($entry.approvedUntil)
                if ($expiry -gt $now) {
                    $exemptUsers.Add($entry.username) | Out-Null
                    Write-Log "  Exemption active: $($entry.username) until $($entry.approvedUntil)"
                } else {
                    Write-Log "  Exemption EXPIRED: $($entry.username) (was until $($entry.approvedUntil))"
                }
            }
        }
        catch {
            Write-Log "Failed to parse allowedusers.json: $($_.Exception.Message)" "WARN"
            # Fail safe: if we can't read exemptions, use only permanent list
        }
    }

    # 4. Freshness check on allowedusers.json
    if (Test-Path $EXEMPT_FILE) {
        $fileAge = (Get-Date) - (Get-Item $EXEMPT_FILE).LastWriteTime
        if ($fileAge.TotalHours -gt $Settings.exemptionSyncMaxAgeHours) {
            Write-Log "WARNING: allowedusers.json is $([int]$fileAge.TotalHours)h old (max $($Settings.exemptionSyncMaxAgeHours)h). Sync may be failing." "WARN"
        }
    }

    return $exemptUsers
}

# ── Restricted Hours Check ────────────────────────────────────────────────────
function Test-RestrictedHours {
    param($Settings)

    $now       = Get-Date
    $hour      = $now.Hour
    $startHour = $Settings.restrictedHours.startHour   # 22
    $endHour   = $Settings.restrictedHours.endHour     # 5

    # Restricted window crosses midnight: 22→5 means restricted if hour>=22 OR hour<5
    $isRestricted = ($hour -ge $startHour) -or ($hour -lt $endHour)
    Write-Log "Current time: $($now.ToString('HH:mm')), Restricted: $isRestricted"
    return $isRestricted
}

# ── Get Active Sessions ───────────────────────────────────────────────────────
function Get-ActiveSessions {
    # Parse quser output: includes Active, Disc (disconnected), and Lock states
    $sessions = @()
    try {
        $quserOutput = quser 2>&1
        if ($LASTEXITCODE -ne 0 -and $quserOutput -match "No User exists") {
            return $sessions
        }

        foreach ($line in $quserOutput) {
            # Skip header line
            if ($line -match "^\s*USERNAME") { continue }

            # quser format: USERNAME SESSIONNAME ID STATE IDLE TIME LOGON TIME
            if ($line -match "^\s*(\S+)\s+(\S*)\s+(\d+)\s+(\S+)") {
                $sessions += [PSCustomObject]@{
                    Username    = $Matches[1].TrimStart(">")  # ">" marks current session
                    SessionName = $Matches[2]
                    SessionId   = [int]$Matches[3]
                    State       = $Matches[4]
                    RawLine     = $line.Trim()
                }
            }
        }
    }
    catch {
        Write-Log "quser failed: $($_.Exception.Message). Falling back to WMI." "WARN"
        # Fallback: WMI Win32_LoggedOnUser
        $sessions = Get-CimInstance -ClassName Win32_LoggedOnUser |
            Select-Object -ExpandProperty Antecedent |
            Where-Object { $_.Name -ne "" } |
            Select-Object @{N="Username";E={$_.Name}},
                          @{N="SessionName";E={"WMI"}},
                          @{N="SessionId";E={-1}},
                          @{N="State";E={"Active"}}
    }
    return $sessions
}

# ── Warn Before Logoff ────────────────────────────────────────────────────────
function Send-LogoffWarning {
    param([int]$SessionId, [string]$Username, [int]$WarningSeconds)

    $msg = "【NightLock 警告 / Warning】`n`n" +
           "夜間アクセス制限により、${WarningSeconds}秒後に自動ログオフされます。`n" +
           "作業を保存してください。`n`n" +
           "You will be logged off in ${WarningSeconds} seconds due to after-hours policy.`n" +
           "Please save your work now.`n`n" +
           "加班例外申请请联系IT部门。 / 残業許可はIT部門へ。"

    try {
        # msg.exe sends a popup to the session
        msg $SessionId /TIME:$WarningSeconds $msg 2>&1 | Out-Null
        Write-Log "  Warning sent to session $SessionId ($Username), $WarningSeconds sec"
    }
    catch {
        Write-Log "  msg.exe failed for session $SessionId`: $($_.Exception.Message)" "WARN"
    }
}

# ── Logoff Session ────────────────────────────────────────────────────────────
function Invoke-SessionLogoff {
    param([int]$SessionId, [string]$Username)

    try {
        logoff $SessionId 2>&1 | Out-Null
        Write-Log "  LOGOFF executed: $Username (session $SessionId)" "WARN"

        # Write structured audit event to Windows Event Log
        $eventMsg = "NightLock: Forced logoff of user '$Username' (session $SessionId) at $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        Write-EventLog -LogName Application -Source "NightLock" `
            -EventId 4001 -EntryType Warning -Message $eventMsg `
            -ErrorAction SilentlyContinue
    }
    catch {
        Write-Log "  logoff command failed for session $SessionId`: $($_.Exception.Message)" "ERROR"
    }
}

# ── Register Event Source (first-run) ────────────────────────────────────────
function Register-EventSource {
    if (![System.Diagnostics.EventLog]::SourceExists("NightLock")) {
        New-EventLog -LogName Application -Source "NightLock" -ErrorAction SilentlyContinue
    }
}

# ── Main Enforcement Logic ────────────────────────────────────────────────────
function Invoke-Enforcement {
    Write-Log "===== NightLock enforcement check START ====="

    if (Test-MaintenanceMode) { return }

    $settings = Get-Settings
    if (!$settings.enabled) {
        Write-Log "NightLock is disabled in settings.json. Skipping." "WARN"
        return
    }

    if (!(Test-RestrictedHours -Settings $settings)) {
        Write-Log "Not in restricted hours. No action."
        return
    }

    $exemptUsers = Get-ExemptUsers -Settings $settings
    Write-Log "Exempt users: $($exemptUsers -join ', ')"

    $sessions = Get-ActiveSessions
    Write-Log "Found $($sessions.Count) session(s)."

    if ($sessions.Count -eq 0) {
        Write-Log "No active sessions. Done."
        return
    }

    foreach ($session in $sessions) {
        $user = $session.Username
        Write-Log "Checking: $user (session $($session.SessionId), state: $($session.State))"

        if ($exemptUsers.Contains($user)) {
            Write-Log "  EXEMPT - skipping: $user"
            continue
        }

        # SYSTEM/DWM/UMFD are built-in non-interactive sessions — never log off
        if ($user -match "^(SYSTEM|DWM-|UMFD-|Window Manager)$") {
            Write-Log "  System session - skipping: $user"
            continue
        }

        # Send warning, wait, then force logoff
        $warningSeconds = $settings.warningBeforeLogoffSeconds
        if ($session.SessionId -ge 0) {
            Send-LogoffWarning -SessionId $session.SessionId `
                               -Username $user `
                               -WarningSeconds $warningSeconds
            Start-Sleep -Seconds $warningSeconds
        }

        Invoke-SessionLogoff -SessionId $session.SessionId -Username $user
    }

    Write-Log "===== NightLock enforcement check END ====="
}

# ── Entry Point ───────────────────────────────────────────────────────────────
Register-EventSource
Invoke-Enforcement
