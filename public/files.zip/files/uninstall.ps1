#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock - Uninstaller
    アンインストールスクリプト
#>

$INSTALL_DIR  = "C:\ProgramData\NightLock"
$SERVICE_NAME = "NightLockSvc"

function Write-Log { param([string]$m) Write-Output "[$(Get-Date -Format 'HH:mm:ss')] $m" }

Write-Log "=== NightLock Uninstall ==="

# Stop and remove service
$svc = Get-Service -Name $SERVICE_NAME -ErrorAction SilentlyContinue
if ($svc) {
    Write-Log "Stopping service..."
    Stop-Service -Name $SERVICE_NAME -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 3
    sc.exe delete $SERVICE_NAME | Out-Null
    Write-Log "Service removed."
}

# Remove scheduled tasks
@("NightLock-LogoffAt2200","NightLock-IntervalCheck","NightLock-OnLogon","NightLock-ExemptionSync") |
    ForEach-Object {
        Unregister-ScheduledTask -TaskName $_ -Confirm:$false -ErrorAction SilentlyContinue
        Write-Log "Task removed: $_"
    }

# Remove Break Glass account (confirm before removing!)
$settings = Get-Content "$INSTALL_DIR\config\settings.json" -ErrorAction SilentlyContinue | ConvertFrom-Json
if ($settings) {
    $bgUser = $settings.breakGlass.username
    $user = Get-LocalUser -Name $bgUser -ErrorAction SilentlyContinue
    if ($user) {
        Remove-LocalUser -Name $bgUser -ErrorAction SilentlyContinue
        Write-Log "Break Glass account '$bgUser' removed."
    }
}

# Remove install directory (preserve logs if you want)
if (Test-Path $INSTALL_DIR) {
    Remove-Item -Path $INSTALL_DIR -Recurse -Force -ErrorAction SilentlyContinue
    Write-Log "Install directory removed: $INSTALL_DIR"
}

# Remove event source
Remove-EventLog -Source "NightLock" -ErrorAction SilentlyContinue
Write-Log "Event source removed."

Write-Log "=== Uninstall complete ==="