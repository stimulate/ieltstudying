SQL Training Single-BAT Builder - V2 Fixed
================================================

This version intentionally returns to the simple V2 structure.

Only the necessary parts were changed:
1. Trusted Location uses the previous working Location99 registry block.
2. The old FINDSTR + MORE payload extraction method is retained.
3. certutil decoding is replaced with cscript + ADODB.Stream + MSXML.
4. The generated learner BAT uses ASCII-only messages to avoid CMD
   misinterpreting Japanese text as commands.

Files
-----
- Build_SQLTraining_SingleBAT_V2_Fixed.cmd
- SingleBAT_Template_V2_Fixed.cmd
- EncodePayload.js
- README_V2_Fixed.txt

Build
-----
1. Put the completed ACCDB in this folder and name it:
   SQLTraining_v1.0.accdb

   You can also drag an ACCDB file onto:
   Build_SQLTraining_SingleBAT_V2_Fixed.cmd

2. Run:
   Build_SQLTraining_SingleBAT_V2_Fixed.cmd

3. It creates:
   SQLTraining_SingleFile_V2_Fixed.bat

4. Distribute only that generated BAT.

First clean test
----------------
Previous versions may have left a local ACCDB or ready marker.

1. Close all Microsoft Access windows.
2. Press Win + R.
3. Enter:
   %LOCALAPPDATA%\ADS
4. Delete the SQLTraining folder.
5. Run SQLTraining_SingleFile_V2_Fixed.bat.
6. Confirm that Access opens without the Enable Content prompt.
7. Close Access.
8. Run the same BAT again.

Second run
----------
When both files exist:
- SQLTraining.accdb
- .SQLTraining_V2_Fixed.ready

the BAT opens Access immediately:
- no registry write
- no database restore
- no cscript
- no overwrite

Trusted Location
----------------
Registry key:
HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99

Values:
Path = %LOCALAPPDATA%\ADS\SQLTraining\
AllowSubFolders = 0
Description = ADS SQL Training Lab

If Access still shows Enable Content after a clean first run, open:
Access > File > Options > Trust Center > Trust Center Settings >
Trusted Locations

Confirm that the expanded path is shown:
C:\Users\<user>\AppData\Local\ADS\SQLTraining\

If it is absent or ignored, an enterprise Office policy is blocking
user Trusted Locations. A BAT cannot override that policy.
