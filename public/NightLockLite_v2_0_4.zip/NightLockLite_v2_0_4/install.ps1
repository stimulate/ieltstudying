#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Lite v2.0.4 - Intune Win32 installer
.DESCRIPTION
    Installs NightLockLite enforcement script and registers two SYSTEM scheduled tasks:
      1. NightLockLite-MinuteCheck: runs every minute, script checks local restricted hours.
      2. NightLockLite-OnLogon: runs immediately after any user logon.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$INSTALL_DIR     = "C:\ProgramData\NightLockLite"
$SCRIPT_DIR      = Join-Path $INSTALL_DIR "scripts"
$LOG_DIR         = Join-Path $INSTALL_DIR "logs"
$VERSION_FILE    = Join-Path $INSTALL_DIR "version.txt"
$CURRENT_VERSION = "2.0.4"
$SOURCE_DIR      = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    if (!(Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR -Force | Out-Null }
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts][$Level][install] $Message"
    Write-Output $line
    Add-Content -Path (Join-Path $LOG_DIR "install.log") -Value $line -Encoding UTF8
}

function Test-AlreadyInstalled {
    if (Test-Path $VERSION_FILE) {
        if ((Get-Content $VERSION_FILE -Raw).Trim() -eq $CURRENT_VERSION) {
            Write-Log "Version $CURRENT_VERSION already installed. Skipping."
            return $true
        }
    }
    return $false
}

function Initialize-Directories {
    Write-Log "Creating directories..."
    @($INSTALL_DIR, $SCRIPT_DIR, $LOG_DIR) | ForEach-Object {
        if (!(Test-Path $_)) { New-Item -ItemType Directory -Path $_ -Force | Out-Null }
    }

    $acl = Get-Acl $INSTALL_DIR
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($rule in @($acl.Access)) { $acl.RemoveAccessRule($rule) | Out-Null }
    foreach ($id in @("SYSTEM", "BUILTIN\Administrators")) {
        $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $id, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow"
        )
        $acl.AddAccessRule($rule)
    }
    Set-Acl -Path $INSTALL_DIR -AclObject $acl
    Write-Log "Directory ACL secured."
}

function Copy-Scripts {
    $src = Join-Path $SOURCE_DIR "scripts\nightlogoff.ps1"
    $dst = Join-Path $SCRIPT_DIR "nightlogoff.ps1"
    if (!(Test-Path $src)) { throw "Required script not found: $src" }
    Copy-Item -Path $src -Destination $dst -Force
    Write-Log "Copied nightlogoff.ps1"
}

function Register-EventSource {
    if (![System.Diagnostics.EventLog]::SourceExists("NightLockLite")) {
        New-EventLog -LogName Application -Source "NightLockLite" -ErrorAction SilentlyContinue
    }
}

function Register-NightLockTasks {
    Write-Log "Registering scheduled tasks..."

    @(
        "NightLockLite-LogoffAt2200",
        "NightLockLite-IntervalCheck",
        "NightLockLite-MinuteCheck",
        "NightLockLite-OnLogon"
    ) | ForEach-Object {
        Unregister-ScheduledTask -TaskName $_ -Confirm:$false -ErrorAction SilentlyContinue
        & "$env:SystemRoot\System32\schtasks.exe" /Delete /TN $_ /F 2>&1 | Out-Null
    }

    $powershell = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $scriptPath = Join-Path $SCRIPT_DIR "nightlogoff.ps1"
    $taskAction = "`"$powershell`" -NonInteractive -NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`""

    function Invoke-SchtasksCreate {
        param(
            [Parameter(Mandatory=$true)][string]$TaskName,
            [Parameter(Mandatory=$true)][string[]]$Arguments
        )

        $output = & "$env:SystemRoot\System32\schtasks.exe" @Arguments 2>&1
        foreach ($line in $output) {
            if (![string]::IsNullOrWhiteSpace($line)) { Write-Log "schtasks ${TaskName}: $line" }
        }
        if ($LASTEXITCODE -ne 0) {
            throw "schtasks.exe failed creating $TaskName. ExitCode=$LASTEXITCODE"
        }
    }

    Invoke-SchtasksCreate -TaskName "NightLockLite-MinuteCheck" -Arguments @(
        "/Create",
        "/TN", "NightLockLite-MinuteCheck",
        "/SC", "MINUTE",
        "/MO", "1",
        "/RU", "SYSTEM",
        "/RL", "HIGHEST",
        "/TR", $taskAction,
        "/F"
    )
    Write-Log "Registered NightLockLite-MinuteCheck"

    Invoke-SchtasksCreate -TaskName "NightLockLite-OnLogon" -Arguments @(
        "/Create",
        "/TN", "NightLockLite-OnLogon",
        "/SC", "ONLOGON",
        "/RU", "SYSTEM",
        "/RL", "HIGHEST",
        "/TR", $taskAction,
        "/F"
    )
    Write-Log "Registered NightLockLite-OnLogon"
}

function Write-VersionMarker {
    Set-Content -Path $VERSION_FILE -Value $CURRENT_VERSION -Encoding ASCII
    Write-Log "Version marker written: $CURRENT_VERSION"
}

try {
    Write-Log "================================================"
    Write-Log "NightLockLite Installer v$CURRENT_VERSION"
    Write-Log "================================================"

    if (Test-AlreadyInstalled) { exit 0 }

    Initialize-Directories
    Copy-Scripts
    Register-EventSource
    Register-NightLockTasks
    Write-VersionMarker

    Write-Log "Installation completed successfully."
    exit 0
}
catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log $_.ScriptStackTrace "ERROR"
    exit 1
}
