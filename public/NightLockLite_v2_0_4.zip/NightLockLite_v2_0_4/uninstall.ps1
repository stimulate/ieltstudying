#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Lite v2.0 - Uninstaller
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "SilentlyContinue"

$INSTALL_DIR = "C:\ProgramData\NightLockLite"
$LOG_DIR = Join-Path $INSTALL_DIR "logs"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    if (!(Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR -Force | Out-Null }
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts][$Level][uninstall] $Message"
    Write-Output $line
    Add-Content -Path (Join-Path $LOG_DIR "uninstall.log") -Value $line -Encoding UTF8
}

try {
    Write-Log "Uninstall started."

    @(
        "NightLockLite-LogoffAt2200",
        "NightLockLite-IntervalCheck",
        "NightLockLite-MinuteCheck",
        "NightLockLite-OnLogon"
    ) | ForEach-Object {
        Stop-ScheduledTask -TaskName $_ -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName $_ -Confirm:$false -ErrorAction SilentlyContinue
        & "$env:SystemRoot\System32\schtasks.exe" /Delete /TN $_ /F 2>&1 | Out-Null
        Write-Log "Removed task if present: $_"
    }

    if (Test-Path $INSTALL_DIR) {
        Remove-Item $INSTALL_DIR -Recurse -Force -ErrorAction SilentlyContinue
    }

    Write-Output "NightLockLite uninstalled."
    exit 0
}
catch {
    Write-Output "NightLockLite uninstall failed: $($_.Exception.Message)"
    exit 1
}
