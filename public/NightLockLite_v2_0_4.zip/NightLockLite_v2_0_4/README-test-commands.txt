Package folder structure:
NightLockLite_v2\
  install.ps1
  uninstall.ps1
  scripts\nightlogoff.ps1

IntuneWinAppUtil source folder should be this package folder.
Install command:
%SystemRoot%\SysNative\WindowsPowerShell\v1.0\powershell.exe -ExecutionPolicy Bypass -File .\install.ps1

Uninstall command:
%SystemRoot%\SysNative\WindowsPowerShell\v1.0\powershell.exe -ExecutionPolicy Bypass -File .\uninstall.ps1

Detection rule:
File exists: C:\ProgramData\NightLockLite\version.txt
or file content equals: 2.0.4

Quick validation commands:
Get-ScheduledTask -TaskName "NightLockLite-*" | Select TaskName,State
Get-ScheduledTaskInfo -TaskName "NightLockLite-MinuteCheck"
Get-Content "C:\ProgramData\NightLockLite\version.txt"
Get-Content "C:\ProgramData\NightLockLite\logs\nightlogoff-$(Get-Date -Format yyyyMM).log" -Tail 80

Temporary maintenance mode:
New-Item -ItemType File "C:\ProgramData\NightLockLite\MAINTENANCE_MODE" -Force
Remove-Item "C:\ProgramData\NightLockLite\MAINTENANCE_MODE" -Force
