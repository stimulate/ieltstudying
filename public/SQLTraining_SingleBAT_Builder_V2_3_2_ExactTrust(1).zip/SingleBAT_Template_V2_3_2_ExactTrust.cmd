@echo off
setlocal EnableExtensions DisableDelayedExpansion

rem ============================================================
rem SQL Training Lab - Single BAT V2.3.2 ExactTrust
rem
rem Based on the working V2.3 restore and Access launch flow.
rem
rem Trusted Location is written through WScript.Shell.RegWrite.
rem This avoids REG.EXE command-line parsing problems when the
rem Path value must end in a backslash.
rem
rem No certutil. No PowerShell.
rem ============================================================

set "WORKDIR=%LOCALAPPDATA%\ADS\SQLTraining"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "READY=%WORKDIR%\.SQLTraining_V2_3_2_ExactTrust.ready"
set "PAYLOAD=%TEMP%\SQLTraining_%RANDOM%_%RANDOM%.b64"
set "TEMPJS=%TEMP%\SQLTraining_Decode_%RANDOM%_%RANDOM%.js"
set "REGJS=%TEMP%\SQLTraining_RegWrite_%RANDOM%_%RANDOM%.js"

rem Second and later launches:
rem only this version's marker allows the direct-open path.
if exist "%TARGET%" if exist "%READY%" goto OPEN_DATABASE

echo.
echo SQL Training Lab first-run setup...
echo.

tasklist /FI "IMAGENAME eq MSACCESS.EXE" 2>nul | find /I "MSACCESS.EXE" >nul
if not errorlevel 1 (
    echo [ERROR] Microsoft Access is currently running.
    echo Close all Access windows and run this BAT again.
    pause
    exit /b 1
)

if not exist "%WORKDIR%" mkdir "%WORKDIR%" >nul 2>&1

if not exist "%WORKDIR%" (
    echo [ERROR] Could not create the local work folder:
    echo %WORKDIR%
    pause
    exit /b 1
)

call :ENSURE_TRUSTED_LOCATION
if errorlevel 1 exit /b 1

if not exist "%TARGET%" (
    call :RESTORE_DATABASE
    if errorlevel 1 exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] Local ACCDB was not found:
    echo %TARGET%
    pause
    exit /b 1
)

for %%F in ("%TARGET%") do set "TARGET_SIZE=%%~zF"

if %TARGET_SIZE% LSS 1024 (
    echo [ERROR] Local ACCDB is too small or invalid.
    echo Size: %TARGET_SIZE% bytes
    pause
    exit /b 1
)

rem Remove Mark-of-the-Web if present.
del "%TARGET%:Zone.Identifier" >nul 2>&1

> "%READY%" echo Ready

if not exist "%READY%" (
    echo [ERROR] Could not create the setup marker.
    pause
    exit /b 1
)

goto OPEN_DATABASE

rem ============================================================
rem Write and verify the exact Access Trusted Location.
rem
rem Expected Path:
rem   C:\Users\<user>\AppData\Local\ADS\SQLTraining\
rem
rem The script receives WORKDIR without a final slash and appends
rem exactly one slash inside JScript.
rem ============================================================
:ENSURE_TRUSTED_LOCATION

echo Registering the exact Access Trusted Location...

call :WRITE_REGISTRY_SCRIPT "%REGJS%"

if not exist "%REGJS%" (
    echo [ERROR] Could not create the temporary registry script.
    pause
    exit /b 1
)

cscript.exe //nologo "%REGJS%" "%WORKDIR%"
set "REG_RC=%ERRORLEVEL%"

del /q "%REGJS%" >nul 2>&1

if not "%REG_RC%"=="0" (
    echo.
    echo [ERROR] Could not write or verify the Access Trusted Location.
    echo Registry script exit code: %REG_RC%
    echo.
    echo Expected folder:
    echo %WORKDIR%\
    echo.
    pause
    exit /b 1
)

echo Access Trusted Location is ready:
echo %WORKDIR%\
exit /b 0

rem ============================================================
rem Restore the embedded ACCDB.
rem Unchanged from the working V2.3 structure.
rem ============================================================
:RESTORE_DATABASE

set "PAYLOAD_LINE="

for /f "tokens=1 delims=:" %%N in ('findstr /n /b /c:":__SQLTRAINING_PAYLOAD__" "%~f0"') do set "PAYLOAD_LINE=%%N"

if not defined PAYLOAD_LINE (
    echo [ERROR] Embedded payload marker was not found.
    pause
    exit /b 1
)

echo Restoring the embedded ACCDB...

more +%PAYLOAD_LINE% "%~f0" > "%PAYLOAD%"

if not exist "%PAYLOAD%" (
    echo [ERROR] Temporary payload file was not created.
    pause
    exit /b 1
)

call :WRITE_DECODER "%TEMPJS%"

if not exist "%TEMPJS%" (
    echo [ERROR] Temporary decoder was not created.
    del /q "%PAYLOAD%" >nul 2>&1
    pause
    exit /b 1
)

cscript.exe //nologo "%TEMPJS%" "%PAYLOAD%" "%TARGET%"
set "DECODE_RC=%ERRORLEVEL%"

del /q "%PAYLOAD%" >nul 2>&1
del /q "%TEMPJS%" >nul 2>&1

if not "%DECODE_RC%"=="0" (
    echo [ERROR] Could not restore the embedded ACCDB.
    echo Decoder exit code: %DECODE_RC%
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] Restored ACCDB was not found.
    pause
    exit /b 1
)

exit /b 0

rem ============================================================
rem Find and open Microsoft Access.
rem ============================================================
:OPEN_DATABASE

set "ACCESS_EXE="

for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"

if not defined ACCESS_EXE (
    for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"
)

if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE"

if not defined ACCESS_EXE (
    echo [ERROR] Microsoft Access was not found.
    echo Database:
    echo %TARGET%
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] Local ACCDB was not found:
    echo %TARGET%
    pause
    exit /b 1
)

echo Opening Microsoft Access...
start "" "%ACCESS_EXE%" "%TARGET%"

endlocal
exit /b 0

rem ============================================================
rem Create the temporary registry JScript.
rem ============================================================
:WRITE_REGISTRY_SCRIPT

> "%~1" echo var args = WScript.Arguments;
>>"%~1" echo if (args.length ^< 1) WScript.Quit(2);
>>"%~1" echo var folder = args.Item(0);
>>"%~1" echo if (folder.charAt(folder.length - 1) != "\\") folder += "\\";
>>"%~1" echo var key = "HKCU\\Software\\Microsoft\\Office\\16.0\\Access\\Security\\Trusted Locations\\Location99\\";
>>"%~1" echo try {
>>"%~1" echo   var shell = new ActiveXObject("WScript.Shell");
>>"%~1" echo   shell.RegWrite(key + "Path", folder, "REG_SZ");
>>"%~1" echo   shell.RegWrite(key + "AllowSubFolders", 0, "REG_DWORD");
>>"%~1" echo   shell.RegWrite(key + "Description", "ADS SQL Training Lab", "REG_SZ");
>>"%~1" echo   var actualPath = shell.RegRead(key + "Path");
>>"%~1" echo   var actualSub = shell.RegRead(key + "AllowSubFolders");
>>"%~1" echo   if (String(actualPath).toLowerCase() != String(folder).toLowerCase()) WScript.Quit(3);
>>"%~1" echo   if (Number(actualSub) != 0) WScript.Quit(4);
>>"%~1" echo   WScript.Quit(0);
>>"%~1" echo } catch (e) {
>>"%~1" echo   WScript.Echo("Registry error: " + e.number + " / " + e.description);
>>"%~1" echo   WScript.Quit(1);
>>"%~1" echo }

exit /b 0

rem ============================================================
rem Create the temporary Base64 decoder.
rem ============================================================
:WRITE_DECODER

> "%~1" echo var args = WScript.Arguments;
>>"%~1" echo if (args.length ^< 2) WScript.Quit(2);
>>"%~1" echo var payloadPath = args.Item(0);
>>"%~1" echo var targetPath = args.Item(1);
>>"%~1" echo try {
>>"%~1" echo   var fso = new ActiveXObject("Scripting.FileSystemObject");
>>"%~1" echo   var input = fso.OpenTextFile(payloadPath, 1, false, 0);
>>"%~1" echo   var base64 = input.ReadAll();
>>"%~1" echo   input.Close();
>>"%~1" echo   base64 = base64.replace(/\s/g, "");
>>"%~1" echo   var xml;
>>"%~1" echo   try {
>>"%~1" echo     xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
>>"%~1" echo   } catch (ignore) {
>>"%~1" echo     xml = new ActiveXObject("Msxml2.DOMDocument.3.0");
>>"%~1" echo   }
>>"%~1" echo   var node = xml.createElement("base64");
>>"%~1" echo   node.dataType = "bin.base64";
>>"%~1" echo   node.text = base64;
>>"%~1" echo   var bytes = node.nodeTypedValue;
>>"%~1" echo   var output = new ActiveXObject("ADODB.Stream");
>>"%~1" echo   output.Type = 1;
>>"%~1" echo   output.Open();
>>"%~1" echo   output.Write(bytes);
>>"%~1" echo   output.SaveToFile(targetPath, 2);
>>"%~1" echo   output.Close();
>>"%~1" echo   WScript.Quit(0);
>>"%~1" echo } catch (e) {
>>"%~1" echo   WScript.Echo("Decode error: " + e.number + " / " + e.description);
>>"%~1" echo   WScript.Quit(1);
>>"%~1" echo }

exit /b 0

:__SQLTRAINING_PAYLOAD__
