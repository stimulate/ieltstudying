SQL Training Single-BAT Builder V2.3.2 ExactTrust
=========================================================

Confirmed problem
-----------------
The earlier V2.3.1 REG ADD command wrote malformed text into the Access
Trusted Location Path. Access displayed a value similar to:

    ...\SQLTraining" \f\

That is not a valid folder path. Therefore, the database was not opened
from a real Trusted Location and Access showed Enable Content.

This was a script error, not an organization policy restriction.

V2.3.2 correction
-----------------
The working V2.3 database restoration and Access startup flow are retained.

Only Trusted Location writing is changed:
- REG.EXE is not used for the Path value.
- A temporary JScript uses WScript.Shell.RegWrite.
- The script receives WORKDIR without a trailing backslash.
- JScript appends exactly one backslash.
- The script reads the value back and verifies it.

Expected registry values
------------------------
Key:
HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99

Values:
Path = C:\Users\<user>\AppData\Local\ADS\SQLTraining\
AllowSubFolders = 0
Description = ADS SQL Training Lab

Build
-----
1. Put SQLTraining_v1.0.accdb in this folder.
2. Run Build_SQLTraining_SingleBAT_V2_3_2_ExactTrust.cmd.
3. Distribute only SQLTraining_SingleFile_V2_3_2_ExactTrust.bat.

Clean test
----------
1. Close every Microsoft Access window.
2. Delete:
   %LOCALAPPDATA%\ADS\SQLTraining
3. Delete the malformed Location99 created by the previous version.
4. Build and run the V2.3.2 generated BAT.
5. In Access, confirm the Trusted Location is exactly:
   C:\Users\<user>\AppData\Local\ADS\SQLTraining\
6. The Path must not contain quotation marks, /f, or extra backslashes.
