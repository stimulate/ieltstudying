@echo off
setlocal EnableExtensions

set "DATABASE=%~dp0SQLTraining_v1.0.accdb"
set "TEMPLATE=%~dp0SingleBAT_Template.cmd"
set "OUTPUT=%~dp0SQLTraining_SingleFile.bat"
set "TEMPBASE64=%TEMP%\SQLTraining_Payload_%RANDOM%_%RANDOM%.b64"

if not exist "%DATABASE%" (
    echo ERROR: Database not found:
    echo %DATABASE%
    echo Edit the DATABASE line if the filename is different.
    pause
    exit /b 1
)

if not exist "%TEMPLATE%" (
    echo ERROR: Template not found:
    echo %TEMPLATE%
    pause
    exit /b 1
)

certutil -f -encode "%DATABASE%" "%TEMPBASE64%" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Could not encode the ACCDB.
    echo certutil may be blocked by company policy.
    pause
    exit /b 1
)

copy /B "%TEMPLATE%"+"%TEMPBASE64%" "%OUTPUT%" >nul
if errorlevel 1 (
    echo ERROR: Could not create the single BAT file.
    del /q "%TEMPBASE64%" >nul 2>&1
    pause
    exit /b 1
)

del /q "%TEMPBASE64%" >nul 2>&1

echo Created:
echo %OUTPUT%
echo.
echo Distribute only SQLTraining_SingleFile.bat.
pause
endlocal
