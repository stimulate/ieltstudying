@echo off
setlocal EnableExtensions

set "WORKDIR=%LOCALAPPDATA%\ADS\SQLTraining"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "PAYLOAD=%TEMP%\SQLTraining_%RANDOM%_%RANDOM%.b64"
set "TRUSTKEY=HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99"

if not exist "%WORKDIR%" mkdir "%WORKDIR%" >nul 2>&1
if not exist "%WORKDIR%" (
    echo ERROR: Could not create local work folder.
    pause
    exit /b 1
)

set "PAYLOAD_LINE="
for /f "tokens=1 delims=:" %%N in ('findstr /n /b /c:":__SQLTRAINING_PAYLOAD__" "%~f0"') do set "PAYLOAD_LINE=%%N"

if not defined PAYLOAD_LINE (
    echo ERROR: Embedded database payload was not found.
    pause
    exit /b 1
)

more +%PAYLOAD_LINE% "%~f0" > "%PAYLOAD%"

certutil -f -decode "%PAYLOAD%" "%TARGET%" >nul 2>&1
set "DECODE_RC=%ERRORLEVEL%"
del /q "%PAYLOAD%" >nul 2>&1

if not "%DECODE_RC%"=="0" (
    echo ERROR: Could not restore the embedded database.
    echo certutil may be blocked by company security policy.
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo ERROR: Restored database was not found.
    pause
    exit /b 1
)

attrib +h "%WORKDIR%" >nul 2>&1
attrib +h "%TARGET%" >nul 2>&1

reg add "%TRUSTKEY%" /v Path /t REG_SZ /d "%WORKDIR%\" /f >nul 2>&1
reg add "%TRUSTKEY%" /v AllowSubFolders /t REG_DWORD /d 0 /f >nul 2>&1
reg add "%TRUSTKEY%" /v Description /t REG_SZ /d "ADS SQL Training Lab" /f >nul 2>&1

set "ACCESS_EXE="

for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"

if not defined ACCESS_EXE (
    for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"
)

if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE"

if not defined ACCESS_EXE (
    echo ERROR: Microsoft Access was not found.
    echo Database restored to:
    echo %TARGET%
    pause
    exit /b 1
)

start "" "%ACCESS_EXE%" "%TARGET%"
exit /b 0

:__SQLTRAINING_PAYLOAD__
