SQL Training Lab - Single BAT Builder

Purpose
-------
Create one distributable BAT file containing the ACCDB payload.

Files needed in the same folder:
- Build_SQLTraining_SingleBAT.cmd
- SingleBAT_Template.cmd
- SQLTraining_v1.0.accdb

Run Build_SQLTraining_SingleBAT.cmd.
It creates:
- SQLTraining_SingleFile.bat

Distribute only SQLTraining_SingleFile.bat.

Behavior
--------
Each launch restores the original ACCDB into:
%LOCALAPPDATA%\ADS\SQLTraining\SQLTraining.accdb

Therefore, a separate Reset CMD is unnecessary.

Important limitations
---------------------
- This does not truly secure or encrypt the ACCDB.
- The ACCDB exists locally while the lab runs.
- The folder and file are hidden only from normal Explorer view.
- A knowledgeable user can still extract the embedded payload.
- Base64 plus certutil may be blocked by Defender or corporate EDR.
- For formal enterprise deployment, Intune Win32 or a self-extracting EXE is preferable.
