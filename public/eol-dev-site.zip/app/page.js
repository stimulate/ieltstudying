export const dynamic = "force-dynamic";

const services = [
  ["AWS Amplify", "Next.js SSR hosting"],
  ["CloudFront", "Edge delivery and HTTPS"],
  ["Route 53", "DEV DNS"],
  ["ACM", "TLS certificate"],
  ["Amazon S3", "Private application storage"],
];

export default function Home() {
  const renderedAt = new Date().toISOString();
  const appEnv = process.env.NEXT_PUBLIC_APP_ENV || "dev";
  const projectName = process.env.NEXT_PUBLIC_PROJECT_NAME || "EOL";

  return (
    <main className="page">
      <section className="hero">
        <span className="badge">{appEnv.toUpperCase()}</span>
        <p className="eyebrow">AWS DEV Environment</p>
        <h1>{projectName} infrastructure validation site</h1>
        <p className="lead">
          This small Next.js application verifies the GitHub → Amplify →
          CloudFront → Route 53 deployment path.
        </p>
        <div className="status">
          <span className="dot" />
          Server-side render successful
        </div>
      </section>

      <section className="grid">
        {services.map(([name, description]) => (
          <article className="card" key={name}>
            <h2>{name}</h2>
            <p>{description}</p>
          </article>
        ))}
      </section>

      <section className="info">
        <div><span>Environment</span><strong>{appEnv}</strong></div>
        <div><span>Rendered at</span><strong>{renderedAt}</strong></div>
        <div><span>Health endpoint</span><strong>/api/health</strong></div>
      </section>
    </main>
  );
}
