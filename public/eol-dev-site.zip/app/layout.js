import "./globals.css";

export const metadata = {
  title: "EOL DEV",
  description: "AWS Amplify DEV validation site",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
