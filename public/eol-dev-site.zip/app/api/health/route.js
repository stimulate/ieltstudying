export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({
    status: "ok",
    service: "eol-dev-sample-site",
    environment: process.env.NEXT_PUBLIC_APP_ENV || "dev",
    timestamp: new Date().toISOString(),
  }, {
    headers: { "Cache-Control": "no-store" },
  });
}
