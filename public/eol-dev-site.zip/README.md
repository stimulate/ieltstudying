# EOL DEV Sample Site

Minimal Next.js SSR app for validating:

GitHub → AWS Amplify Hosting → CloudFront → Route 53 + ACM.

## Local test

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

Health endpoint: `http://localhost:3000/api/health`.

## Amplify

Use:

- platform: `WEB_COMPUTE`
- framework: `Next.js - SSR`

Suggested DEV environment variables:

```text
NEXT_PUBLIC_APP_ENV=dev
NEXT_PUBLIC_PROJECT_NAME=EOL
```

## GitHub

Push these files to the repository/branch used by Terraform.

Do not commit:
- GitHub PAT
- AWS access keys
- Terraform state
- `.env.local`
