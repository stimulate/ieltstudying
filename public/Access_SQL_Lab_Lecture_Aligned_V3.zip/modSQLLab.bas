﻿Attribute VB_Name = "modSQLLab"
Option Compare Database
Option Explicit

'=========================================================
' Access SQL Training Lab - Lecture-aligned V3
'
' Main tables:
'   product
'   contract
'   sales
'   store
'   contract_wide
'
' Saved queries:
'   q_sales_by_contract
'   q_active_product
'   q_wide_to_long
'
' Run BuildTrainingData after importing this module.
' Existing forms are not deleted.
'=========================================================

Public Sub BuildTrainingData()
    On Error GoTo EH
    Application.Echo False

    Dim q As Variant
    Dim t As Variant

    For Each q In Array( _
        "q_UserResult", _
        "q_sales_by_contract", _
        "q_wide_to_long", _
        "q_active_product")

        DeleteQueryIfExists CStr(q)
    Next q

    For Each t In Array( _
        "t_exercise", _
        "contract_wide", _
        "sales", _
        "contract", _
        "store", _
        "product", _
        "t_sales_feb", _
        "t_sales_jan", _
        "t_sales_detail", _
        "t_contract", _
        "m_store", _
        "m_product")

        DeleteTableIfExists CStr(t)
    Next t

    CreateTables
    InsertData
    CreateSavedQueries
    InsertExercises

    Application.Echo True

    MsgBox _
        "講義対応版V3のデータと練習問題を作成しました。" & vbCrLf & _
        "解答は改行・インデント付きです。", _
        vbInformation, _
        "SQL Training Lab"

    Exit Sub

EH:
    Application.Echo True

    MsgBox _
        "作成に失敗しました。" & vbCrLf & _
        "Error " & Err.Number & ": " & Err.Description, _
        vbCritical, _
        "SQL Training Lab"
End Sub

Private Sub CreateTables()
    ExecSQL _
        "CREATE TABLE product (" & _
        "product_code TEXT(10) NOT NULL, " & _
        "product_name TEXT(50) NOT NULL, " & _
        "product_status TEXT(20), " & _
        "CONSTRAINT pk_product PRIMARY KEY(product_code))"

    ExecSQL _
        "CREATE TABLE store (" & _
        "store_id TEXT(10) NOT NULL, " & _
        "store_name TEXT(50) NOT NULL, " & _
        "region_name TEXT(20), " & _
        "CONSTRAINT pk_store PRIMARY KEY(store_id))"

    'product_name and amount/ap_amount are intentionally duplicated
    'so that the lecture SQL can run without being rewritten.
    ExecSQL _
        "CREATE TABLE [contract] (" & _
        "contract_id LONG NOT NULL, " & _
        "contract_date DATETIME NOT NULL, " & _
        "product_code TEXT(10), " & _
        "product_name TEXT(50), " & _
        "customer_id TEXT(20), " & _
        "customer_name TEXT(50), " & _
        "contract_status TEXT(20), " & _
        "amount CURRENCY, " & _
        "ap_amount CURRENCY, " & _
        "store_id TEXT(10), " & _
        "CONSTRAINT pk_contract PRIMARY KEY(contract_id))"

    ExecSQL _
        "CREATE TABLE sales (" & _
        "sales_id LONG NOT NULL, " & _
        "contract_id LONG, " & _
        "sales_date DATETIME, " & _
        "store_id TEXT(10), " & _
        "amount CURRENCY, " & _
        "CONSTRAINT pk_sales PRIMARY KEY(sales_id))"

    ExecSQL _
        "CREATE TABLE contract_wide (" & _
        "customer_id TEXT(20) NOT NULL, " & _
        "cancer_ap CURRENCY, " & _
        "medical_ap CURRENCY, " & _
        "nursing_ap CURRENCY, " & _
        "CONSTRAINT pk_contract_wide PRIMARY KEY(customer_id))"

    ExecSQL _
        "CREATE TABLE t_exercise (" & _
        "exercise_id LONG NOT NULL, " & _
        "category_name TEXT(60), " & _
        "question_text MEMO, " & _
        "starter_sql MEMO, " & _
        "answer_sql MEMO, " & _
        "explanation_text MEMO, " & _
        "CONSTRAINT pk_t_exercise PRIMARY KEY(exercise_id))"
End Sub

Private Sub InsertData()
    Dim r As Variant
    Dim rows As Variant

    rows = Array( _
        Array("00001", "がん保険", "有効"), _
        Array("00002", "医療保険", "有効"), _
        Array("00003", "介護保険", "有効"))

    For Each r In rows
        ExecSQL _
            "INSERT INTO product VALUES (" & _
            Q(r(0)) & "," & _
            Q(r(1)) & "," & _
            Q(r(2)) & ")"
    Next r

    rows = Array( _
        Array("S01", "東京第一支店", "関東"), _
        Array("S02", "東京第二支店", "関東"), _
        Array("S03", "大阪支店", "関西"), _
        Array("S04", "名古屋支店", "中部"))

    For Each r In rows
        ExecSQL _
            "INSERT INTO store VALUES (" & _
            Q(r(0)) & "," & _
            Q(r(1)) & "," & _
            Q(r(2)) & ")"
    Next r

    AddContract 1, "04/10/2025", "00001", "がん保険", _
                "C101", "山田太郎", "有効", 10000, "S01"

    AddContract 2, "04/18/2025", "00002", "医療保険", _
                "C102", "佐藤花子", "有効", 8000, "S01"

    AddContract 3, "05/02/2025", "00001", "がん保険", _
                "C103", "テストデータ", "有効", 12000, "S02"

    AddContract 4, "05/20/2025", "00001", "がん保険", _
                "C104", "鈴木一郎", "有効", Null, "S02"

    AddContract 5, "06/15/2025", "00001", "がん保険", _
                "C105", "高橋美咲", "有効", 6000, "S03"

    AddContract 6, "07/01/2025", "00001", "がん保険", _
                "C106", "伊藤健一", "有効", 5000, "S03"

    AddContract 7, "02/01/2026", "00002", "医療保険", _
                "C001", "田中一郎", "有効", 8000, "S01"

    AddContract 8, "02/03/2026", "00001", "がん保険", _
                "C002", "佐々木愛", "有効", 6000, "S01"

    AddContract 9, "02/06/2026", "00001", "がん保険", _
                "C003", "中村健", "有効", 12000, "S02"

    AddContract 10, "02/07/2026", "00003", "介護保険", _
                "C004", "小林美咲", "有効", 3000, "S02"

    AddContract 11, "02/10/2026", "00004", "学資保険", _
                "C005", "加藤誠", "有効", 6000, "S03"

    AddContract 12, "02/11/2026", "00004", "学資保険", _
                "C006", "吉田葵", "有効", 8000, "S03"

    AddSale 101, 1, "04/10/2025", "S01", 6000
    AddSale 102, 1, "04/10/2025", "S01", 4000
    AddSale 103, 2, "04/18/2025", "S01", 8000
    AddSale 104, 3, "05/02/2025", "S02", 7000
    AddSale 105, 3, "05/02/2025", "S02", 5000
    AddSale 106, 5, "06/15/2025", "S03", 6000
    AddSale 107, 6, "07/01/2025", "S03", 5000
    AddSale 108, 7, "02/01/2026", "S01", 8000
    AddSale 109, 8, "02/03/2026", "S01", 3000
    AddSale 110, 8, "02/03/2026", "S01", 3000
    AddSale 111, 9, "02/06/2026", "S02", 7000
    AddSale 112, 9, "02/06/2026", "S02", 5000
    AddSale 113, 10, "02/07/2026", "S02", 3000
    AddSale 114, 11, "02/10/2026", "S03", 6000
    AddSale 115, 12, "02/11/2026", "S03", 5000
    AddSale 116, 12, "02/11/2026", "S03", 3000

    ExecSQL _
        "INSERT INTO contract_wide VALUES " & _
        "('C001',10000,5000,0)"

    ExecSQL _
        "INSERT INTO contract_wide VALUES " & _
        "('C002',0,8000,2000)"

    ExecSQL _
        "INSERT INTO contract_wide VALUES " & _
        "('C003',3000,0,1000)"
End Sub

Private Sub AddContract( _
    ByVal id As Long, _
    ByVal d As String, _
    ByVal pcd As String, _
    ByVal pname As String, _
    ByVal cid As String, _
    ByVal cname As String, _
    ByVal st As String, _
    ByVal amt As Variant, _
    ByVal sid As String)

    Dim a As String

    If IsNull(amt) Then
        a = "NULL"
    Else
        a = CStr(CLng(amt))
    End If

    ExecSQL _
        "INSERT INTO [contract] (" & _
        "contract_id," & _
        "contract_date," & _
        "product_code," & _
        "product_name," & _
        "customer_id," & _
        "customer_name," & _
        "contract_status," & _
        "amount," & _
        "ap_amount," & _
        "store_id" & _
        ") VALUES (" & _
        id & ",#" & d & "#," & _
        Q(pcd) & "," & _
        Q(pname) & "," & _
        Q(cid) & "," & _
        Q(cname) & "," & _
        Q(st) & "," & _
        a & "," & _
        a & "," & _
        Q(sid) & ")"
End Sub

Private Sub AddSale( _
    ByVal id As Long, _
    ByVal cid As Long, _
    ByVal d As String, _
    ByVal sid As String, _
    ByVal amt As Long)

    ExecSQL _
        "INSERT INTO sales (" & _
        "sales_id," & _
        "contract_id," & _
        "sales_date," & _
        "store_id," & _
        "amount" & _
        ") VALUES (" & _
        id & "," & _
        cid & ",#" & _
        d & "#," & _
        Q(sid) & "," & _
        amt & ")"
End Sub

Private Sub CreateSavedQueries()
    CurrentDb.CreateQueryDef _
        "q_sales_by_contract", _
        "SELECT contract_id, " & _
        "SUM(amount) AS contract_sales_amount " & _
        "FROM sales " & _
        "GROUP BY contract_id;"

    CurrentDb.CreateQueryDef _
        "q_active_product", _
        "SELECT product_code, " & _
        "product_name, " & _
        "product_status " & _
        "FROM product " & _
        "WHERE product_status='有効';"

    CurrentDb.CreateQueryDef _
        "q_wide_to_long", _
        "SELECT customer_id," & _
        "'00001' AS product_code," & _
        "'がん保険' AS product_name," & _
        "cancer_ap AS amount " & _
        "FROM contract_wide " & _
        "UNION ALL " & _
        "SELECT customer_id," & _
        "'00002'," & _
        "'医療保険'," & _
        "medical_ap " & _
        "FROM contract_wide " & _
        "UNION ALL " & _
        "SELECT customer_id," & _
        "'00003'," & _
        "'介護保険'," & _
        "nursing_ap " & _
        "FROM contract_wide;"
End Sub

Private Sub InsertExercises()
    Dim sqlText As String

    sqlText = _
        "SELECT" & vbCrLf & _
        "    contract_date," & vbCrLf & _
        "    product_name," & vbCrLf & _
        "    amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract]" & vbCrLf & _
        "WHERE" & vbCrLf & _
        "    contract_date BETWEEN DateSerial(2025,4,1)" & vbCrLf & _
        "                      AND DateSerial(2025,6,30)" & vbCrLf & _
        "    AND product_name = 'がん保険'" & vbCrLf & _
        "    AND customer_name <> 'テストデータ'" & vbCrLf & _
        "    AND amount IS NOT NULL;"

    AddEx _
        1, _
        "WHERE：複数条件", _
        "2025/4/1～2025/6/30のがん保険のうち、" & _
        "顧客名がテストデータではなく、" & _
        "amountがNULLではない契約を表示してください。", _
        sqlText, _
        "結果は2件です。" & _
        "AccessではDateSerialを使うと日付形式の曖昧さを避けられます。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    COUNT(*) AS contract_count" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract];"

    AddEx _
        2, _
        "COUNT：全件数", _
        "contractの全件数を求めてください。", _
        sqlText, _
        "COUNT(*)は行数を数えます。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    COUNT(*) AS cancer_count" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract]" & vbCrLf & _
        "WHERE" & vbCrLf & _
        "    product_name = 'がん保険';"

    AddEx _
        3, _
        "COUNT：がん保険", _
        "がん保険の契約件数を求めてください。", _
        sqlText, _
        "WHEREで絞り込んだ後にCOUNTします。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    SUM(ap_amount) AS total_ap" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract];"

    AddEx _
        4, _
        "SUM：総合計", _
        "新契約APの総合計をtotal_apという列名で求めてください。", _
        sqlText, _
        "SUMはNULLを無視します。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    product_name," & vbCrLf & _
        "    SUM(ap_amount) AS total_ap" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract]" & vbCrLf & _
        "GROUP BY" & vbCrLf & _
        "    product_name;"

    AddEx _
        5, _
        "GROUP BY：商品別", _
        "商品名別に新契約APを合計してください。", _
        sqlText, _
        "非集計列product_nameをGROUP BYに指定します。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    contract_date," & vbCrLf & _
        "    SUM(ap_amount) AS total_ap" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract]" & vbCrLf & _
        "GROUP BY" & vbCrLf & _
        "    contract_date;"

    AddEx _
        6, _
        "GROUP BY：契約日別", _
        "契約日別に新契約APを合計してください。", _
        sqlText, _
        "契約日が集計単位です。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    store_id," & vbCrLf & _
        "    SUM(amount) AS total_amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    sales" & vbCrLf & _
        "GROUP BY" & vbCrLf & _
        "    store_id;"

    AddEx _
        7, _
        "sales：店舗別SUM", _
        "salesをstore_id別に集計してください。", _
        sqlText, _
        "AccessのSQL入力欄には--コメントを入れないでください。"

    sqlText = _
        "SELECT DISTINCT" & vbCrLf & _
        "    customer_id" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract];"

    AddEx _
        8, _
        "DISTINCT", _
        "顧客IDを重複なしで表示してください。", _
        sqlText, _
        "DISTINCTは重複行を除去します。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    c.contract_date," & vbCrLf & _
        "    c.product_code," & vbCrLf & _
        "    p.product_name," & vbCrLf & _
        "    c.ap_amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract] AS c" & vbCrLf & _
        "    INNER JOIN product AS p" & vbCrLf & _
        "        ON c.product_code = p.product_code;"

    AddEx _
        9, _
        "INNER JOIN", _
        "contractとproductを商品コードでINNER JOINしてください。", _
        sqlText, _
        "productにない00004は表示されません。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    c.contract_date," & vbCrLf & _
        "    c.product_code," & vbCrLf & _
        "    p.product_name," & vbCrLf & _
        "    c.ap_amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract] AS c" & vbCrLf & _
        "    LEFT JOIN product AS p" & vbCrLf & _
        "        ON c.product_code = p.product_code;"

    AddEx _
        10, _
        "LEFT JOIN", _
        "contractを左側としてproductへLEFT JOINし、00004も残してください。", _
        sqlText, _
        "00004の商品名はNULLになります。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    c.contract_date," & vbCrLf & _
        "    c.product_code," & vbCrLf & _
        "    p.product_name," & vbCrLf & _
        "    p.product_status," & vbCrLf & _
        "    c.ap_amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract] AS c" & vbCrLf & _
        "    LEFT JOIN product AS p" & vbCrLf & _
        "        ON c.product_code = p.product_code" & vbCrLf & _
        "        AND p.product_status = '有効';"

    AddEx _
        11, _
        "LEFT JOIN + WHERE", _
        "全契約を残しながら、有効な商品だけを結合してください。", _
        sqlText, _
        "右表条件をWHEREに置くと、右表がNULLの00004が消えます。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    c.customer_id," & vbCrLf & _
        "    c.ap_amount," & vbCrLf & _
        "    p.product_name" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract] AS c," & vbCrLf & _
        "    product AS p;"

    AddEx _
        12, _
        "デカルト積", _
        "結合条件を指定せずにcontractとproductを組み合わせてください。" & _
        "結果件数が増える理由も確認してください。", _
        sqlText, _
        "12件×3商品で36件になります。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    SUM(c.ap_amount) AS wrong_total_ap" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract] AS c" & vbCrLf & _
        "    INNER JOIN sales AS s" & vbCrLf & _
        "        ON c.contract_id = s.contract_id;"

    AddEx _
        13, _
        "JOIN後の誤集計", _
        "contractとsalesをJOIN後、contract側APをSUMし、" & _
        "重複計上を確認してください。", _
        sqlText, _
        "1契約に複数明細があるとcontract側APが繰り返されます。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    c.product_name," & vbCrLf & _
        "    SUM(s.amount) AS total_ap" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract] AS c" & vbCrLf & _
        "    INNER JOIN sales AS s" & vbCrLf & _
        "        ON c.contract_id = s.contract_id" & vbCrLf & _
        "GROUP BY" & vbCrLf & _
        "    c.product_name;"

    AddEx _
        14, _
        "JOIN + SUM + GROUP BY", _
        "JOIN後、sales.amountを商品名別に合計してください。", _
        sqlText, _
        "JOIN後の粒度はsales明細なのでsales.amountを合計します。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    c.product_name," & vbCrLf & _
        "    SUM(x.contract_sales_amount) AS total_ap" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract] AS c" & vbCrLf & _
        "    INNER JOIN q_sales_by_contract AS x" & vbCrLf & _
        "        ON c.contract_id = x.contract_id" & vbCrLf & _
        "GROUP BY" & vbCrLf & _
        "    c.product_name;"

    AddEx _
        15, _
        "事前集計 + JOIN", _
        "q_sales_by_contractをcontractへJOINして商品別に合計してください。", _
        sqlText, _
        "salesを契約単位へ事前集計してからJOINします。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    customer_id," & vbCrLf & _
        "    '00001' AS product_code," & vbCrLf & _
        "    'がん保険' AS product_name," & vbCrLf & _
        "    cancer_ap AS amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    contract_wide" & vbCrLf & _
        vbCrLf & _
        "UNION ALL" & vbCrLf & _
        vbCrLf & _
        "SELECT" & vbCrLf & _
        "    customer_id," & vbCrLf & _
        "    '00002' AS product_code," & vbCrLf & _
        "    '医療保険' AS product_name," & vbCrLf & _
        "    medical_ap AS amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    contract_wide"

    sqlText = _
        sqlText & vbCrLf & _
        vbCrLf & _
        "UNION ALL" & vbCrLf & _
        vbCrLf & _
        "SELECT" & vbCrLf & _
        "    customer_id," & vbCrLf & _
        "    '00003' AS product_code," & vbCrLf & _
        "    '介護保険' AS product_name," & vbCrLf & _
        "    nursing_ap AS amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    contract_wide;"

    AddEx _
        16, _
        "横持ち → UNION ALL", _
        "contract_wideを顧客ID・商品コード・商品名・amountの" & _
        "縦持ちに変換してください。", _
        sqlText, _
        "UNION ALLでは各SELECTの列数とデータ型を合わせます。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    product_name," & vbCrLf & _
        "    SUM(amount) AS total_ap" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    q_wide_to_long" & vbCrLf & _
        "GROUP BY" & vbCrLf & _
        "    product_name;"

    AddEx _
        17, _
        "横持ち集計", _
        "q_wide_to_longを使い、商品名別にAPを合計してください。", _
        sqlText, _
        "縦持ちにすると通常のGROUP BYで集計できます。"

    sqlText = _
        "SELECT" & vbCrLf & _
        "    contract_id," & vbCrLf & _
        "    contract_date," & vbCrLf & _
        "    product_code," & vbCrLf & _
        "    ap_amount" & vbCrLf & _
        "FROM" & vbCrLf & _
        "    [contract]" & vbCrLf & _
        "WHERE" & vbCrLf & _
        "    product_code IN" & vbCrLf & _
        "    (" & vbCrLf & _
        "        SELECT" & vbCrLf & _
        "            product_code" & vbCrLf & _
        "        FROM" & vbCrLf & _
        "            product" & vbCrLf & _
        "        WHERE" & vbCrLf & _
        "            product_status = '有効'" & vbCrLf & _
        "    );"

    AddEx _
        18, _
        "SELECTの入れ子", _
        "有効な商品マスタに存在する契約だけを、" & _
        "WHERE内のSELECTで表示してください。", _
        sqlText, _
        "内側のSELECTが有効な商品コード一覧を返します。"
End Sub

Private Sub AddEx( _
    ByVal id As Long, _
    ByVal cat As String, _
    ByVal question As String, _
    ByVal answer As String, _
    ByVal explanation As String)

    Dim rs As DAO.Recordset

    Set rs = CurrentDb.OpenRecordset( _
        "t_exercise", _
        dbOpenDynaset, _
        dbAppendOnly)

    rs.AddNew
    rs!exercise_id = id
    rs!category_name = cat
    rs!question_text = question
    rs!starter_sql = ""
    rs!answer_sql = answer
    rs!explanation_text = explanation
    rs.Update

    rs.Close
    Set rs = Nothing
End Sub

Public Function IsSafeSelect(ByVal sqlText As String) As Boolean
    Dim s As String
    Dim word As Variant
    Dim blocked As Variant

    s = Trim$(Nz(sqlText, ""))

    If Len(s) = 0 Then
        Exit Function
    End If

    If Right$(s, 1) = ";" Then
        s = Left$(s, Len(s) - 1)
    End If

    If InStr(s, ";") > 0 Then
        Exit Function
    End If

    s = UCase$( _
        Replace( _
            Replace( _
                Replace(s, vbCr, " "), _
                vbLf, " "), _
            vbTab, " "))

    s = " " & Trim$(s) & " "

    If Left$(Trim$(s), 6) <> "SELECT" Then
        Exit Function
    End If

    blocked = Array( _
        " UPDATE ", _
        " DELETE ", _
        " INSERT ", _
        " DROP ", _
        " ALTER ", _
        " CREATE ", _
        " INTO ", _
        " EXEC ", _
        " EXECUTE ", _
        " TRANSFORM ", _
        " PARAMETERS ")

    For Each word In blocked
        If InStr(1, s, CStr(word), vbTextCompare) > 0 Then
            Exit Function
        End If
    Next word

    IsSafeSelect = True
End Function

Public Sub DeleteQueryIfExists(ByVal queryName As String)
    On Error Resume Next

    DoCmd.Close acQuery, queryName, acSaveNo
    CurrentDb.QueryDefs.Delete queryName

    On Error GoTo 0
End Sub

Private Sub DeleteTableIfExists(ByVal tableName As String)
    On Error Resume Next

    DoCmd.Close acTable, tableName, acSaveNo
    DoCmd.DeleteObject acTable, tableName

    On Error GoTo 0
End Sub

Private Sub ExecSQL(ByVal sqlText As String)
    CurrentDb.Execute sqlText, dbFailOnError
End Sub

Private Function Q(ByVal value As Variant) As String
    Q = "'" & Replace(CStr(value), "'", "''") & "'"
End Function
