﻿ACCESS SQL LAB - LECTURE-ALIGNED V3
===================================

V3 changes:
- Full replacement version of modSQLLab.bas
- Rebuilds all training tables and sample data
- Rebuilds all 18 exercises
- Every answer_sql contains line breaks and indentation
- Exercise 12 is named デカルト積
- starter_sql remains blank, so txtSQL starts empty

HOW TO APPLY
------------
1. Back up the ACCDB file.
2. Close frm_SQLLab, all tables, and all queries.
3. Press Alt+F11.
4. In Project Explorer, right-click Modules > modSQLLab.
5. Choose Remove modSQLLab.
6. Export the old module first if needed.
7. File > Import File.
8. Import the V3 modSQLLab.bas.
9. Open modSQLLab.
10. Put the cursor inside Public Sub BuildTrainingData().
11. Press F5.
12. Reopen frm_SQLLab.

This rebuild deletes and recreates:
- product
- contract
- sales
- store
- contract_wide
- t_exercise
- q_sales_by_contract
- q_active_product
- q_wide_to_long

It does not delete frm_SQLLab.

FORM SETTING
------------
LoadExercise should keep:

    Me.txtSQL.Value = ""

Recommended txtAnswer properties:
- 名前: txtAnswer
- 使用可能: はい
- 編集ロック: はい
- スクロール バー: あり
- スクロール バー配置: 右
- フォント名: Consolas
- フォントサイズ: 10
