#Requires -RunAsAdministrator
<#
.SYNOPSIS
    NightLock Lite v2.0 - Enforcement Script
.DESCRIPTION
    Enforces local PC usage restriction from 22:00 to 05:00.
    Designed for Intune Win32 App deployment and SYSTEM scheduled tasks.
    Session detection uses Windows WTS API, not quser.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Config
$INSTALL_DIR = "C:\ProgramData\NightLockLite"
$LOG_DIR     = Join-Path $INSTALL_DIR "logs"
$KILL_SWITCH = Join-Path $INSTALL_DIR "MAINTENANCE_MODE"
$LOCK_FILE   = Join-Path $INSTALL_DIR "nightlogoff.lock"

$RESTRICT_START = 22   # 22:00
$RESTRICT_END   = 5    # 05:00
$WARNING_SECONDS = 0   # Immediate logoff during restricted hours

# Usernames to exempt. Use short username, DOMAIN\user, AzureAD\user, or user@domain.com when known.
$PERMANENT_EXEMPTIONS = @(
    "Administrator",
    "WDAGUtilityAccount"
)

# Logging
function Write-Log {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [string]$Level = "INFO"
    )
    if (!(Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR -Force | Out-Null }
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts][$Level][nightlogoff] $Message"
    Write-Output $line
    Add-Content -Path (Join-Path $LOG_DIR "nightlogoff-$(Get-Date -Format 'yyyyMM').log") -Value $line -Encoding UTF8

    Get-ChildItem $LOG_DIR -Filter "nightlogoff-*.log" -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt (Get-Date).AddMonths(-3) } |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

function Test-RestrictedHours {
    $hour = (Get-Date).Hour
    $isRestricted = ($hour -ge $RESTRICT_START) -or ($hour -lt $RESTRICT_END)
    Write-Log "Local time: $(Get-Date -Format 'HH:mm:ss') | Restricted: $isRestricted"
    return $isRestricted
}

function Get-Lock {
    if (Test-Path $LOCK_FILE) {
        $age = (Get-Date) - (Get-Item $LOCK_FILE).LastWriteTime
        if ($age.TotalMinutes -lt 3) {
            Write-Log "Another instance appears to be running. Lock age=$([int]$age.TotalSeconds)s. Skipping."
            return $false
        }
        Remove-Item $LOCK_FILE -Force -ErrorAction SilentlyContinue
        Write-Log "Stale lock removed."
    }
    New-Item -ItemType File -Path $LOCK_FILE -Force | Out-Null
    return $true
}

function Release-Lock {
    Remove-Item $LOCK_FILE -Force -ErrorAction SilentlyContinue
}

# WTS API Session Enumeration
function Initialize-WtsApi {
    if ("NightLockLite.WtsApi" -as [type]) { return }

    $source = @"
using System;
using System.Runtime.InteropServices;

namespace NightLockLite {
    public enum WTS_CONNECTSTATE_CLASS {
        WTSActive,
        WTSConnected,
        WTSConnectQuery,
        WTSShadow,
        WTSDisconnected,
        WTSIdle,
        WTSListen,
        WTSReset,
        WTSDown,
        WTSInit
    }

    public enum WTS_INFO_CLASS {
        WTSInitialProgram = 0,
        WTSApplicationName = 1,
        WTSWorkingDirectory = 2,
        WTSOEMId = 3,
        WTSSessionId = 4,
        WTSUserName = 5,
        WTSWinStationName = 6,
        WTSDomainName = 7,
        WTSConnectState = 8,
        WTSClientBuildNumber = 9,
        WTSClientName = 10,
        WTSClientDirectory = 11,
        WTSClientProductId = 12,
        WTSClientHardwareId = 13,
        WTSClientAddress = 14,
        WTSClientDisplay = 15,
        WTSClientProtocolType = 16
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct WTS_SESSION_INFO {
        public Int32 SessionID;
        [MarshalAs(UnmanagedType.LPStr)] public string pWinStationName;
        public WTS_CONNECTSTATE_CLASS State;
    }

    public class WtsApi {
        public static readonly IntPtr WTS_CURRENT_SERVER_HANDLE = IntPtr.Zero;

        [DllImport("wtsapi32.dll", SetLastError=true)]
        public static extern bool WTSEnumerateSessions(
            IntPtr hServer,
            int Reserved,
            int Version,
            out IntPtr ppSessionInfo,
            out int pCount);

        [DllImport("wtsapi32.dll")]
        public static extern void WTSFreeMemory(IntPtr pMemory);

        [DllImport("wtsapi32.dll", SetLastError=true)]
        public static extern bool WTSQuerySessionInformation(
            IntPtr hServer,
            int sessionId,
            WTS_INFO_CLASS wtsInfoClass,
            out IntPtr ppBuffer,
            out int pBytesReturned);
    }
}
"@
    Add-Type -TypeDefinition $source -Language CSharp
}

function Get-WtsSessionString {
    param(
        [int]$SessionId,
        [NightLockLite.WTS_INFO_CLASS]$InfoClass
    )
    $buffer = [IntPtr]::Zero
    $bytes = 0
    try {
        $ok = [NightLockLite.WtsApi]::WTSQuerySessionInformation(
            [NightLockLite.WtsApi]::WTS_CURRENT_SERVER_HANDLE,
            $SessionId,
            $InfoClass,
            [ref]$buffer,
            [ref]$bytes
        )
        if (!$ok -or $buffer -eq [IntPtr]::Zero) { return "" }
        return ([Runtime.InteropServices.Marshal]::PtrToStringAnsi($buffer)).Trim()
    }
    finally {
        if ($buffer -ne [IntPtr]::Zero) { [NightLockLite.WtsApi]::WTSFreeMemory($buffer) }
    }
}

function Get-InteractiveSessionsByWts {
    Initialize-WtsApi
    $sessions = @()
    $ppSessionInfo = [IntPtr]::Zero
    $count = 0

    $ok = [NightLockLite.WtsApi]::WTSEnumerateSessions(
        [NightLockLite.WtsApi]::WTS_CURRENT_SERVER_HANDLE,
        0,
        1,
        [ref]$ppSessionInfo,
        [ref]$count
    )
    if (!$ok) {
        $err = [Runtime.InteropServices.Marshal]::GetLastWin32Error()
        throw "WTSEnumerateSessions failed. Win32Error=$err"
    }

    try {
        $dataSize = [Runtime.InteropServices.Marshal]::SizeOf([type][NightLockLite.WTS_SESSION_INFO])
        for ($i = 0; $i -lt $count; $i++) {
            $current = [IntPtr]::Add($ppSessionInfo, $i * $dataSize)
            $info = [Runtime.InteropServices.Marshal]::PtrToStructure($current, [type][NightLockLite.WTS_SESSION_INFO])

            $username = Get-WtsSessionString -SessionId $info.SessionID -InfoClass ([NightLockLite.WTS_INFO_CLASS]::WTSUserName)
            $domain   = Get-WtsSessionString -SessionId $info.SessionID -InfoClass ([NightLockLite.WTS_INFO_CLASS]::WTSDomainName)
            $station  = Get-WtsSessionString -SessionId $info.SessionID -InfoClass ([NightLockLite.WTS_INFO_CLASS]::WTSWinStationName)

            if ([string]::IsNullOrWhiteSpace($username)) { continue }

            $displayUser = if ([string]::IsNullOrWhiteSpace($domain)) { $username } else { "$domain\$username" }
            $sessions += [PSCustomObject]@{
                Username    = $username
                Domain      = $domain
                DisplayUser = $displayUser
                SessionId   = [int]$info.SessionID
                SessionName = $station
                State       = $info.State.ToString()
                Source      = "WTS"
            }
        }
    }
    finally {
        if ($ppSessionInfo -ne [IntPtr]::Zero) { [NightLockLite.WtsApi]::WTSFreeMemory($ppSessionInfo) }
    }

    return $sessions
}

# Last-resort fallback only; WTS should normally be used.
function Get-InteractiveSessionsByQuser {
    $sessions = @()
    $raw = query user 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Log "query user returned exit code $LASTEXITCODE: $raw" "WARN"
        return $sessions
    }

    foreach ($line in $raw) {
        if ($line -match "^\s*USERNAME") { continue }
        if ([string]::IsNullOrWhiteSpace($line)) { continue }

        $clean = $line.Trim() -replace '^>', ''
        # Robust enough for common English/Japanese Windows output where ID is the first numeric column after sessionname.
        if ($clean -match "^(?<user>\S+)\s+(?<session>\S*)\s+(?<id>\d+)\s+(?<state>\S+)") {
            $user = $Matches.user
            $sessions += [PSCustomObject]@{
                Username    = $user
                Domain      = ""
                DisplayUser = $user
                SessionId   = [int]$Matches.id
                SessionName = $Matches.session
                State       = $Matches.state
                Source      = "query user"
            }
        }
    }
    return $sessions
}

function Get-InteractiveSessions {
    Write-Log "Detecting interactive sessions by WTS API..."
    try {
        $wtsSessions = @(Get-InteractiveSessionsByWts)
        Write-Log "WTS sessions found: $($wtsSessions.Count)"
        foreach ($s in $wtsSessions) {
            Write-Log "  WTS: user=$($s.DisplayUser), session=$($s.SessionId), state=$($s.State), station=$($s.SessionName)"
        }
        if ($wtsSessions.Count -gt 0) { return $wtsSessions }
    }
    catch {
        Write-Log "WTS detection failed: $($_.Exception.Message)" "WARN"
    }

    Write-Log "Falling back to query user..." "WARN"
    $qSessions = @(Get-InteractiveSessionsByQuser)
    Write-Log "query user sessions found: $($qSessions.Count)"
    foreach ($s in $qSessions) {
        Write-Log "  query user: user=$($s.DisplayUser), session=$($s.SessionId), state=$($s.State), station=$($s.SessionName)"
    }
    return $qSessions
}

function Test-ExemptUser {
    param([object]$Session, [System.Collections.Generic.HashSet[string]]$ExemptSet)

    $candidates = @(
        $Session.Username,
        $Session.DisplayUser,
        ("{0}\{1}" -f $Session.Domain, $Session.Username).Trim('\')
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }

    foreach ($c in $candidates) {
        if ($ExemptSet.Contains($c)) { return $true }
    }
    return $false
}

function Send-LogoffWarning {
    param([int]$SessionId, [string]$Username)
    if ($WARNING_SECONDS -le 0) { return }

    $msg = "[NightLock Warning]`n`nThis PC is restricted from $RESTRICT_START`:00 to $RESTRICT_END`:00.`nYou will be logged off in $WARNING_SECONDS seconds.`nPlease save your work now."
    try {
        & "$env:SystemRoot\System32\msg.exe" $SessionId /TIME:$WARNING_SECONDS $msg 2>&1 | Out-Null
        Write-Log "Warning sent to $Username session=$SessionId for $WARNING_SECONDS seconds."
    }
    catch {
        Write-Log "msg.exe failed for $Username session=$SessionId: $($_.Exception.Message)" "WARN"
    }
}

function Invoke-SessionLogoff {
    param([int]$SessionId, [string]$Username)
    try {
        & "$env:SystemRoot\System32\logoff.exe" $SessionId 2>&1 | Out-Null
        Write-Log "LOGOFF executed: $Username session=$SessionId" "WARN"
        Write-EventLog -LogName Application -Source "NightLockLite" -EventId 4001 -EntryType Warning `
            -Message "NightLockLite forced logoff. User=$Username SessionId=$SessionId Time=$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" `
            -ErrorAction SilentlyContinue
    }
    catch {
        Write-Log "logoff.exe failed for $Username session=$SessionId: $($_.Exception.Message)" "ERROR"
    }
}

# Main
try {
    Write-Log "===== NightLockLite v2 check START ====="

    if (Test-Path $KILL_SWITCH) {
        Write-Log "MAINTENANCE_MODE exists. Enforcement suspended." "WARN"
        exit 0
    }

    if (!(Test-RestrictedHours)) {
        Write-Log "Not in restricted hours. No action."
        Write-Log "===== NightLockLite v2 check END ====="
        exit 0
    }

    if (!(Get-Lock)) { exit 0 }

    try {
        $exemptSet = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($u in $PERMANENT_EXEMPTIONS) { $exemptSet.Add($u) | Out-Null }
        Write-Log "Exempt users: $($PERMANENT_EXEMPTIONS -join ', ')"

        $sessions = @(Get-InteractiveSessions)
        if ($sessions.Count -eq 0) {
            Write-Log "No interactive user sessions detected."
            exit 0
        }

        foreach ($s in $sessions) {
            $user = $s.DisplayUser
            Write-Log "Checking user=$user username=$($s.Username) domain=$($s.Domain) session=$($s.SessionId) state=$($s.State) source=$($s.Source)"

            if ($s.SessionId -le 0) {
                Write-Log "  Skipping session $($s.SessionId) because it is not a normal interactive session."
                continue
            }
            if ($s.Username -match '^(SYSTEM|LOCAL SERVICE|NETWORK SERVICE|DWM-\d+|UMFD-\d+)$') {
                Write-Log "  System/non-interactive account. Skipping: $user"
                continue
            }
            if (Test-ExemptUser -Session $s -ExemptSet $exemptSet) {
                Write-Log "  EXEMPT. Skipping: $user"
                continue
            }

            Send-LogoffWarning -SessionId $s.SessionId -Username $user
            if ($WARNING_SECONDS -gt 0) { Start-Sleep -Seconds $WARNING_SECONDS }
            Invoke-SessionLogoff -SessionId $s.SessionId -Username $user
        }
    }
    finally {
        Release-Lock
    }

    Write-Log "===== NightLockLite v2 check END ====="
    exit 0
}
catch {
    Write-Log "FATAL: $($_.Exception.Message)" "ERROR"
    Write-Log $_.ScriptStackTrace "ERROR"
    exit 1
}
