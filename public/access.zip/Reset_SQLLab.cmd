﻿@echo off
setlocal

set "SOURCE=%~dp0SQLTraining_Master.accdb"
set "WORKDIR=%LOCALAPPDATA%\CompanyName\SQLTraining"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "LOCKFILE=%WORKDIR%\SQLTraining.laccdb"

if exist "%LOCKFILE%" (
    echo Please close Microsoft Access before resetting the lab.
    pause
    exit /b 1
)

if not exist "%SOURCE%" (
    echo ERROR: SQLTraining_Master.accdb was not found.
    pause
    exit /b 1
)

if not exist "%WORKDIR%" mkdir "%WORKDIR%"

copy /Y "%SOURCE%" "%TARGET%" >nul
if errorlevel 1 (
    echo ERROR: Reset failed.
    pause
    exit /b 1
)

echo SQL Training Lab was reset successfully.
pause
endlocal
