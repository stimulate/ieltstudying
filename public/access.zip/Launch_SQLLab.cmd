﻿@echo off
setlocal

set "SOURCE=%~dp0SQLTraining_Master.accdb"
set "WORKDIR=%LOCALAPPDATA%\CompanyName\SQLTraining"
set "TARGET=%WORKDIR%\SQLTraining.accdb"

if not exist "%SOURCE%" (
    echo ERROR: SQLTraining_Master.accdb was not found.
    echo Put this CMD file in the same folder as the master database.
    pause
    exit /b 1
)

if not exist "%WORKDIR%" mkdir "%WORKDIR%"

if not exist "%TARGET%" (
    copy /Y "%SOURCE%" "%TARGET%" >nul
    if errorlevel 1 (
        echo ERROR: Could not copy the training database.
        pause
        exit /b 1
    )
)

start "" "%TARGET%"
endlocal
