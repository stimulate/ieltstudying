﻿Attribute VB_Name = "modSQLLab"
Option Compare Database
Option Explicit

'=========================================================
' SQL Training Lab - MVP setup module
' Import this module into a blank Access .accdb file.
' Run BuildTrainingData once.
'=========================================================

Public Sub BuildTrainingData()
    On Error GoTo ErrHandler

    Application.Echo False

    DeleteQueryIfExists "q_UserResult"
    DeleteQueryIfExists "q_active_contract"
    DeleteQueryIfExists "q_sales_by_contract"
    DeleteTableIfExists "t_exercise"
    DeleteTableIfExists "t_sales_feb"
    DeleteTableIfExists "t_sales_jan"
    DeleteTableIfExists "t_sales_detail"
    DeleteTableIfExists "t_contract"
    DeleteTableIfExists "m_store"
    DeleteTableIfExists "m_product"

    CreateTables
    InsertMasterData
    InsertContractData
    InsertSalesData
    CreateSavedQueries
    InsertExercises

    Application.Echo True
    MsgBox "SQL Lab data and exercises were created successfully.", _
           vbInformation, "SQL Training Lab"
    Exit Sub

ErrHandler:
    Application.Echo True
    MsgBox "Build failed." & vbCrLf & _
           "Error " & Err.Number & ": " & Err.Description, _
           vbCritical, "SQL Training Lab"
End Sub

Private Sub CreateTables()
    Dim db As DAO.Database
    Set db = CurrentDb

    db.Execute _
        "CREATE TABLE m_product (" & _
        " product_code TEXT(10) NOT NULL," & _
        " product_name TEXT(100) NOT NULL," & _
        " product_category TEXT(50)," & _
        " CONSTRAINT pk_m_product PRIMARY KEY (product_code)" & _
        ")", dbFailOnError

    db.Execute _
        "CREATE TABLE m_store (" & _
        " store_id TEXT(10) NOT NULL," & _
        " store_name TEXT(100) NOT NULL," & _
        " region_name TEXT(50)," & _
        " CONSTRAINT pk_m_store PRIMARY KEY (store_id)" & _
        ")", dbFailOnError

    db.Execute _
        "CREATE TABLE t_contract (" & _
        " contract_id LONG NOT NULL," & _
        " contract_date DATETIME NOT NULL," & _
        " product_code TEXT(10)," & _
        " customer_id TEXT(20)," & _
        " contract_status TEXT(20)," & _
        " new_contract_ap CURRENCY," & _
        " store_id TEXT(10)," & _
        " CONSTRAINT pk_t_contract PRIMARY KEY (contract_id)" & _
        ")", dbFailOnError

    db.Execute _
        "CREATE TABLE t_sales_detail (" & _
        " sales_detail_id LONG NOT NULL," & _
        " contract_id LONG," & _
        " store_id TEXT(10)," & _
        " sales_month DATETIME," & _
        " ap_amount CURRENCY," & _
        " CONSTRAINT pk_t_sales_detail PRIMARY KEY (sales_detail_id)" & _
        ")", dbFailOnError

    db.Execute _
        "CREATE TABLE t_sales_jan (" & _
        " sales_id LONG NOT NULL," & _
        " contract_id LONG," & _
        " store_id TEXT(10)," & _
        " ap_amount CURRENCY," & _
        " CONSTRAINT pk_t_sales_jan PRIMARY KEY (sales_id)" & _
        ")", dbFailOnError

    db.Execute _
        "CREATE TABLE t_sales_feb (" & _
        " sales_id LONG NOT NULL," & _
        " contract_id LONG," & _
        " store_id TEXT(10)," & _
        " ap_amount CURRENCY," & _
        " CONSTRAINT pk_t_sales_feb PRIMARY KEY (sales_id)" & _
        ")", dbFailOnError

    db.Execute _
        "CREATE TABLE t_exercise (" & _
        " exercise_id LONG NOT NULL," & _
        " category_name TEXT(50)," & _
        " question_text MEMO," & _
        " starter_sql MEMO," & _
        " answer_sql MEMO," & _
        " explanation_text MEMO," & _
        " CONSTRAINT pk_t_exercise PRIMARY KEY (exercise_id)" & _
        ")", dbFailOnError
End Sub

Private Sub InsertMasterData()
    Dim db As DAO.Database
    Set db = CurrentDb

    db.Execute "INSERT INTO m_product VALUES ('P001','終身保険','死亡保険')", dbFailOnError
    db.Execute "INSERT INTO m_product VALUES ('P002','医療保険','医療保険')", dbFailOnError
    db.Execute "INSERT INTO m_product VALUES ('P003','がん保険','医療保険')", dbFailOnError
    db.Execute "INSERT INTO m_product VALUES ('P004','学資保険','貯蓄型')", dbFailOnError
    db.Execute "INSERT INTO m_product VALUES ('P005','介護保険','介護保険')", dbFailOnError
    db.Execute "INSERT INTO m_product VALUES ('P006','女性疾病保険','医療保険')", dbFailOnError

    db.Execute "INSERT INTO m_store VALUES ('S01','東京第一支店','関東')", dbFailOnError
    db.Execute "INSERT INTO m_store VALUES ('S02','東京第二支店','関東')", dbFailOnError
    db.Execute "INSERT INTO m_store VALUES ('S03','大阪支店','関西')", dbFailOnError
    db.Execute "INSERT INTO m_store VALUES ('S04','名古屋支店','中部')", dbFailOnError
End Sub

Private Sub InsertContractData()
    Dim db As DAO.Database
    Set db = CurrentDb

    db.Execute "INSERT INTO t_contract VALUES (1,#01/05/2026#,'P001','C001','有効',120000,'S01')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (2,#01/10/2026#,'P002','C002','有効',80000,'S01')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (3,#01/12/2026#,'P001','C003','解約',100000,'S02')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (4,#02/01/2026#,'P003','C001','有効',150000,'S02')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (5,#02/03/2026#,'P004','C004','申込中',90000,'S03')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (6,#02/15/2026#,'P002','C005','有効',110000,'S03')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (7,#03/01/2026#,'P005','C006','失効',70000,'S01')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (8,#03/08/2026#,'P001','C001','有効',130000,'S02')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (9,#03/12/2026#,'P003','C007','有効',200000,'S03')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (10,#03/20/2026#,'P004','C008','有効',95000,'S01')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (11,#04/02/2026#,'P002','C009','有効',NULL,'S02')", dbFailOnError
    db.Execute "INSERT INTO t_contract VALUES (12,#04/08/2026#,'P999','C010','有効',60000,'S03')", dbFailOnError
End Sub

Private Sub InsertSalesData()
    Dim db As DAO.Database
    Set db = CurrentDb

    'Contract 1 deliberately has two detail rows.
    db.Execute "INSERT INTO t_sales_detail VALUES (101,1,'S01',#01/01/2026#,70000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_detail VALUES (102,1,'S01',#01/01/2026#,50000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_detail VALUES (103,2,'S01',#01/01/2026#,80000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_detail VALUES (104,3,'S02',#01/01/2026#,100000)", dbFailOnError

    'Contract 4 also has two detail rows.
    db.Execute "INSERT INTO t_sales_detail VALUES (105,4,'S02',#02/01/2026#,100000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_detail VALUES (106,4,'S02',#02/01/2026#,50000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_detail VALUES (107,5,'S03',#02/01/2026#,90000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_detail VALUES (108,6,'S03',#02/01/2026#,110000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_detail VALUES (109,8,'S02',#03/01/2026#,130000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_detail VALUES (110,9,'S03',#03/01/2026#,120000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_detail VALUES (111,9,'S03',#03/01/2026#,80000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_detail VALUES (112,12,'S03',#04/01/2026#,60000)", dbFailOnError

    'Monthly tables for UNION / UNION ALL practice.
    db.Execute "INSERT INTO t_sales_jan VALUES (201,1,'S01',70000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_jan VALUES (202,1,'S01',50000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_jan VALUES (203,2,'S01',80000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_jan VALUES (204,3,'S02',100000)", dbFailOnError

    'The first February row intentionally duplicates a January row.
    db.Execute "INSERT INTO t_sales_feb VALUES (201,1,'S01',70000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_feb VALUES (205,4,'S02',100000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_feb VALUES (206,4,'S02',50000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_feb VALUES (207,5,'S03',90000)", dbFailOnError
    db.Execute "INSERT INTO t_sales_feb VALUES (208,6,'S03',110000)", dbFailOnError
End Sub

Private Sub CreateSavedQueries()
    Dim db As DAO.Database
    Set db = CurrentDb

    db.CreateQueryDef _
        "q_active_contract", _
        "SELECT contract_id, contract_date, product_code, customer_id, " & _
        "contract_status, new_contract_ap, store_id " & _
        "FROM t_contract WHERE contract_status='有効';"

    db.CreateQueryDef _
        "q_sales_by_contract", _
        "SELECT contract_id, SUM(ap_amount) AS contract_ap " & _
        "FROM t_sales_detail GROUP BY contract_id;"
End Sub

Private Sub InsertExercises()
    AddExercise 1, "SELECT", _
        "全契約の契約ID、契約日、顧客ID、新契約APを表示してください。", _
        "SELECT" & vbCrLf & _
        "    contract_id," & vbCrLf & _
        "    contract_date," & vbCrLf & _
        "    customer_id," & vbCrLf & _
        "    new_contract_ap" & vbCrLf & _
        "FROM t_contract;", _
        "SELECT contract_id, contract_date, customer_id, new_contract_ap FROM t_contract;", _
        "SELECTで必要な列を指定します。"

    AddExercise 2, "WHERE", _
        "契約ステータスが「有効」の契約だけを表示してください。", _
        "SELECT *" & vbCrLf & _
        "FROM t_contract" & vbCrLf & _
        "WHERE ;", _
        "SELECT * FROM t_contract WHERE contract_status='有効';", _
        "文字列条件はシングルクォートで囲みます。"

    AddExercise 3, "DISTINCT", _
        "契約を持つ顧客IDを重複なしで表示してください。", _
        "SELECT customer_id" & vbCrLf & _
        "FROM t_contract;", _
        "SELECT DISTINCT customer_id FROM t_contract;", _
        "DISTINCTはSELECT結果の重複行を除去します。"

    AddExercise 4, "INNER JOIN", _
        "商品マスタと一致する契約について、契約ID、商品コード、商品名を表示してください。", _
        "SELECT" & vbCrLf & _
        "    c.contract_id," & vbCrLf & _
        "    c.product_code," & vbCrLf & _
        "    p.product_name" & vbCrLf & _
        "FROM t_contract AS c" & vbCrLf & _
        "INNER JOIN m_product AS p" & vbCrLf & _
        "    ON ;", _
        "SELECT c.contract_id, c.product_code, p.product_name " & _
        "FROM t_contract AS c INNER JOIN m_product AS p " & _
        "ON c.product_code=p.product_code;", _
        "P999は商品マスタに存在しないため、INNER JOINの結果には出ません。"

    AddExercise 5, "LEFT JOIN", _
        "契約がない商品も含め、全商品と契約IDを表示してください。", _
        "SELECT" & vbCrLf & _
        "    p.product_code," & vbCrLf & _
        "    p.product_name," & vbCrLf & _
        "    c.contract_id" & vbCrLf & _
        "FROM m_product AS p" & vbCrLf & _
        "LEFT JOIN t_contract AS c" & vbCrLf & _
        "    ON ;", _
        "SELECT p.product_code, p.product_name, c.contract_id " & _
        "FROM m_product AS p LEFT JOIN t_contract AS c " & _
        "ON p.product_code=c.product_code;", _
        "P006には契約がありませんが、LEFT JOINでは商品行が残り、契約IDはNULLになります。"

    AddExercise 6, "LEFT JOIN + WHERE", _
        "全商品を残したまま、「有効」契約だけを結合してください。契約がない商品も表示してください。", _
        "SELECT" & vbCrLf & _
        "    p.product_code," & vbCrLf & _
        "    p.product_name," & vbCrLf & _
        "    c.contract_id," & vbCrLf & _
        "    c.contract_status" & vbCrLf & _
        "FROM m_product AS p" & vbCrLf & _
        "LEFT JOIN t_contract AS c" & vbCrLf & _
        "    ON p.product_code = c.product_code" & vbCrLf & _
        "WHERE ;", _
        "SELECT p.product_code, p.product_name, c.contract_id, c.contract_status " & _
        "FROM m_product AS p LEFT JOIN q_active_contract AS c " & _
        "ON p.product_code=c.product_code;", _
        "Accessでは、右表を先にWHEREで絞った保存クエリq_active_contractを作り、その結果へLEFT JOINすると理解しやすく確実です。右表の条件を外側のWHEREに置くとNULL行が除外されます。"

    AddExercise 7, "COUNT", _
        "全契約数と、新契約APがNULLではない契約数を同時に表示してください。", _
        "SELECT" & vbCrLf & _
        "    COUNT(*) AS contract_count," & vbCrLf & _
        "    COUNT() AS ap_value_count" & vbCrLf & _
        "FROM t_contract;", _
        "SELECT COUNT(*) AS contract_count, COUNT(new_contract_ap) AS ap_value_count FROM t_contract;", _
        "COUNT(*)は行を数え、COUNT(field)はそのフィールドがNULLの行を数えません。"

    AddExercise 8, "SUM", _
        "「有効」契約の新契約AP合計を表示してください。", _
        "SELECT SUM() AS total_ap" & vbCrLf & _
        "FROM t_contract" & vbCrLf & _
        "WHERE ;", _
        "SELECT SUM(new_contract_ap) AS total_ap FROM t_contract WHERE contract_status='有効';", _
        "SUMはNULLを合計対象に含めません。"

    AddExercise 9, "GROUP BY", _
        "商品コード別に契約件数を表示してください。", _
        "SELECT" & vbCrLf & _
        "    product_code," & vbCrLf & _
        "    COUNT(*) AS contract_count" & vbCrLf & _
        "FROM t_contract" & vbCrLf & _
        "GROUP BY ;", _
        "SELECT product_code, COUNT(*) AS contract_count FROM t_contract GROUP BY product_code;", _
        "集計関数でないSELECT列は、通常GROUP BYにも指定します。"

    AddExercise 10, "SELECT + GROUP BY", _
        "商品コードと契約ステータスの組合せ別に、契約件数と新契約AP合計を表示してください。", _
        "SELECT" & vbCrLf & _
        "    product_code," & vbCrLf & _
        "    contract_status," & vbCrLf & _
        "    COUNT(*) AS contract_count," & vbCrLf & _
        "    SUM(new_contract_ap) AS total_ap" & vbCrLf & _
        "FROM t_contract" & vbCrLf & _
        "GROUP BY ;", _
        "SELECT product_code, contract_status, COUNT(*) AS contract_count, " & _
        "SUM(new_contract_ap) AS total_ap " & _
        "FROM t_contract GROUP BY product_code, contract_status;", _
        "product_codeとcontract_statusの両方が集計単位です。"

    AddExercise 11, "JOIN + Aggregation Problem", _
        "契約表とAP明細をJOINし、商品コード別のAP明細合計を表示してください。1契約に複数明細がある点に注意してください。", _
        "SELECT" & vbCrLf & _
        "    c.product_code," & vbCrLf & _
        "    SUM(s.ap_amount) AS total_ap" & vbCrLf & _
        "FROM t_contract AS c" & vbCrLf & _
        "INNER JOIN t_sales_detail AS s" & vbCrLf & _
        "    ON c.contract_id = s.contract_id" & vbCrLf & _
        "GROUP BY ;", _
        "SELECT c.product_code, SUM(s.ap_amount) AS total_ap " & _
        "FROM t_contract AS c INNER JOIN t_sales_detail AS s " & _
        "ON c.contract_id=s.contract_id " & _
        "GROUP BY c.product_code;", _
        "JOIN後の1行は契約ではなくAP明細です。new_contract_apをSUMすると、明細数だけ重複計上される可能性があります。"

    AddExercise 12, "Saved Query + AS + JOIN", _
        "AP明細を契約単位に集計した保存クエリq_sales_by_contractを契約表へJOINし、商品コード別APを表示してください。", _
        "SELECT" & vbCrLf & _
        "    c.product_code," & vbCrLf & _
        "    SUM(x.contract_ap) AS total_ap" & vbCrLf & _
        "FROM t_contract AS c" & vbCrLf & _
        "INNER JOIN q_sales_by_contract AS x" & vbCrLf & _
        "    ON c.contract_id = x.contract_id" & vbCrLf & _
        "GROUP BY ;", _
        "SELECT c.product_code, SUM(x.contract_ap) AS total_ap " & _
        "FROM t_contract AS c INNER JOIN q_sales_by_contract AS x " & _
        "ON c.contract_id=x.contract_id " & _
        "GROUP BY c.product_code;", _
        "q_sales_by_contractで明細を契約単位に集計してからJOINします。ASはテーブルまたは保存クエリと集計列の別名に使います。"

    AddExercise 13, "UNION / UNION ALL", _
        "1月と2月の売上表を縦に結合してください。まずUNION ALLを使い、次にUNIONへ変更して行数の違いを確認してください。", _
        "SELECT sales_id, contract_id, store_id, ap_amount" & vbCrLf & _
        "FROM t_sales_jan" & vbCrLf & _
        "UNION ALL" & vbCrLf & _
        "SELECT sales_id, contract_id, store_id, ap_amount" & vbCrLf & _
        "FROM t_sales_feb;", _
        "SELECT sales_id, contract_id, store_id, ap_amount FROM t_sales_jan " & _
        "UNION ALL " & _
        "SELECT sales_id, contract_id, store_id, ap_amount FROM t_sales_feb;", _
        "UNIONは重複行を除去し、UNION ALLは保持します。両側のSELECTは列数と対応するデータ型を合わせます。"

    AddExercise 14, "Cartesian Product", _
        "商品マスタと店舗マスタを結合条件なしで並べ、結果行数を確認してください。その後、なぜ行数が増えるか説明してください。", _
        "SELECT" & vbCrLf & _
        "    p.product_code," & vbCrLf & _
        "    s.store_id" & vbCrLf & _
        "FROM m_product AS p, m_store AS s;", _
        "SELECT p.product_code, s.store_id FROM m_product AS p, m_store AS s;", _
        "6商品×4店舗=24行です。JOIN条件がないため、左表の各行と右表の全行が組み合わされます。"


    AddExercise 15, "Nested SELECT", _
        "商品カテゴリが「医療保険」の商品に該当する契約を、WHERE句内のSELECTを使って表示してください。", _
        "SELECT" & vbCrLf & _
        "    c.contract_id," & vbCrLf & _
        "    c.product_code," & vbCrLf & _
        "    c.customer_id" & vbCrLf & _
        "FROM t_contract AS c" & vbCrLf & _
        "WHERE c.product_code IN" & vbCrLf & _
        "    (" & vbCrLf & _
        "        SELECT p.product_code" & vbCrLf & _
        "        FROM m_product AS p" & vbCrLf & _
        "        WHERE ;" & vbCrLf & _
        "    );", _
        "SELECT c.contract_id, c.product_code, c.customer_id " & _
        "FROM t_contract AS c " & _
        "WHERE c.product_code IN " & _
        "(SELECT p.product_code FROM m_product AS p " & _
        "WHERE p.product_category='医療保険');", _
        "内側のSELECTが医療保険の商品コード一覧を返し、外側のSELECTが該当契約を取得します。"End Sub

Private Sub AddExercise( _
    ByVal exerciseId As Long, _
    ByVal categoryName As String, _
    ByVal questionText As String, _
    ByVal starterSql As String, _
    ByVal answerSql As String, _
    ByVal explanationText As String)

    Dim rs As DAO.Recordset
    Set rs = CurrentDb.OpenRecordset("t_exercise", dbOpenDynaset, dbAppendOnly)

    rs.AddNew
    rs!exercise_id = exerciseId
    rs!category_name = categoryName
    rs!question_text = questionText
    rs!starter_sql = starterSql
    rs!answer_sql = answerSql
    rs!explanation_text = explanationText
    rs.Update

    rs.Close
    Set rs = Nothing
End Sub

Public Function IsSafeSelect(ByVal sqlText As String) As Boolean
    Dim s As String
    Dim blockedWords As Variant
    Dim item As Variant

    s = Trim$(Nz(sqlText, vbNullString))
    If Len(s) = 0 Then Exit Function

    'Allow one optional trailing semicolon, but reject multiple statements.
    If Right$(s, 1) = ";" Then
        s = Left$(s, Len(s) - 1)
    End If
    If InStr(1, s, ";", vbBinaryCompare) > 0 Then Exit Function

    s = UCase$(s)
    s = Replace(s, vbCrLf, " ")
    s = Replace(s, vbCr, " ")
    s = Replace(s, vbLf, " ")
    s = Replace(s, vbTab, " ")
    s = " " & Trim$(s) & " "

    If Left$(Trim$(s), 6) <> "SELECT" Then Exit Function

    blockedWords = Array( _
        " UPDATE ", " DELETE ", " INSERT ", " DROP ", _
        " ALTER ", " CREATE ", " INTO ", " EXEC ", _
        " EXECUTE ", " TRANSFORM ", " PARAMETERS ")

    For Each item In blockedWords
        If InStr(1, s, CStr(item), vbTextCompare) > 0 Then
            Exit Function
        End If
    Next item

    IsSafeSelect = True
End Function

Public Sub DeleteQueryIfExists(ByVal queryName As String)
    On Error Resume Next
    DoCmd.Close acQuery, queryName, acSaveNo
    CurrentDb.QueryDefs.Delete queryName
    On Error GoTo 0
End Sub

Private Sub DeleteTableIfExists(ByVal tableName As String)
    On Error Resume Next
    DoCmd.DeleteObject acTable, tableName
    On Error GoTo 0
End Sub
