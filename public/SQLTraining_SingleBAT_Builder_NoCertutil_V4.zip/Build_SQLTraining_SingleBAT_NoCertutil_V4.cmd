@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion

set "DATABASE=%~1"
if not defined DATABASE set "DATABASE=%~dp0SQLTraining_v1.0.accdb"

set "TEMPLATE=%~dp0SingleBAT_Template_NoCertutil_V4.cmd"
set "ENCODER=%~dp0EncodePayload.js"
set "OUTPUT=%~dp0SQLTraining_SingleFile_V4.bat"
set "TEMPBASE64=%TEMP%\SQLTraining_Payload_%RANDOM%_%RANDOM%.b64"

echo.
echo SQL Training Single-BAT V4 Builder
echo.

if not exist "%DATABASE%" (
    echo [ERROR] ACCDB file was not found.
    echo %DATABASE%
    echo.
    echo Put SQLTraining_v1.0.accdb in this folder,
    echo or drag an ACCDB file onto this CMD.
    pause
    exit /b 1
)

if not exist "%TEMPLATE%" (
    echo [ERROR] Template was not found.
    echo %TEMPLATE%
    pause
    exit /b 1
)

if not exist "%ENCODER%" (
    echo [ERROR] EncodePayload.js was not found.
    echo %ENCODER%
    pause
    exit /b 1
)

where cscript.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] cscript.exe was not found.
    pause
    exit /b 1
)

if exist "%TEMPBASE64%" del /q "%TEMPBASE64%" >nul 2>&1

cscript.exe //nologo "%ENCODER%" "%DATABASE%" "%TEMPBASE64%"
if errorlevel 1 (
    echo [ERROR] Could not encode the ACCDB.
    if exist "%TEMPBASE64%" del /q "%TEMPBASE64%" >nul 2>&1
    pause
    exit /b 1
)

if not exist "%TEMPBASE64%" (
    echo [ERROR] Base64 payload was not created.
    pause
    exit /b 1
)

copy /B /Y "%TEMPLATE%"+"%TEMPBASE64%" "%OUTPUT%" >nul
set "BUILD_RC=%ERRORLEVEL%"

del /q "%TEMPBASE64%" >nul 2>&1

if not "%BUILD_RC%"=="0" (
    echo [ERROR] Could not create the single BAT file.
    pause
    exit /b 1
)

if not exist "%OUTPUT%" (
    echo [ERROR] Output file was not found.
    pause
    exit /b 1
)

echo.
echo Created:
echo %OUTPUT%
echo.
pause
endlocal
exit /b 0
