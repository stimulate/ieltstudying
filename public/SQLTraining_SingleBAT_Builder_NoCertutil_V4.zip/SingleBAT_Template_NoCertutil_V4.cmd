@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion

rem ============================================================
rem SQL Training Lab - Single self-extracting BAT V4
rem
rem Fix in V4:
rem - The decoder uses the LAST payload marker.
rem - The marker literal is assembled in JScript so it cannot
rem   accidentally match the decoder source itself.
rem - Base64 length and character validation are performed.
rem
rem No certutil. No PowerShell.
rem ============================================================

set "WORKDIR=%LOCALAPPDATA%\ADS\SQLTraining"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "TEMPJS=%TEMP%\SQLTraining_Decode_%RANDOM%_%RANDOM%.js"
set "TRUSTKEY=HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99"

rem Existing ACCDB: verify Trusted Location before opening.
if exist "%TARGET%" (
    call :CHECK_TRUST
    if not errorlevel 1 goto OPEN_DATABASE

    echo.
    echo Local ACCDB exists, but Trusted Location is missing.
    echo Repairing the registry setting only.
    echo.

    call :REGISTER_TRUST
    if errorlevel 1 goto TRUST_ERROR

    goto OPEN_DATABASE
)

echo.
echo SQL Training Lab first-run setup
echo.

tasklist /FI "IMAGENAME eq MSACCESS.EXE" 2>nul | find /I "MSACCESS.EXE" >nul
if not errorlevel 1 (
    echo [ERROR] Microsoft Access is currently running.
    echo Close all Access windows and run this BAT again.
    pause
    exit /b 1
)

if not exist "%WORKDIR%" mkdir "%WORKDIR%" >nul 2>&1

if not exist "%WORKDIR%" (
    echo [ERROR] Could not create the local folder.
    echo %WORKDIR%
    pause
    exit /b 1
)

where cscript.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] cscript.exe was not found.
    pause
    exit /b 1
)

call :WRITE_DECODER "%TEMPJS%"

if not exist "%TEMPJS%" (
    echo [ERROR] Could not create the temporary decoder.
    pause
    exit /b 1
)

cscript.exe //nologo "%TEMPJS%" "%~f0" "%TARGET%"
set "DECODE_RC=%ERRORLEVEL%"

del /q "%TEMPJS%" >nul 2>&1

if not "%DECODE_RC%"=="0" (
    echo.
    echo [ERROR] Embedded ACCDB restore failed.
    echo Decoder exit code: %DECODE_RC%
    echo.
    echo Exit code 3: payload marker not found
    echo Exit code 4: payload is empty
    echo Exit code 5: invalid Base64 length
    echo Exit code 6: invalid Base64 characters
    echo Exit code 7: decoded file is too small
    echo Exit code 1: COM / ADODB / MSXML error
    echo.
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] Restored ACCDB was not found.
    pause
    exit /b 1
)

for %%F in ("%TARGET%") do set "TARGET_SIZE=%%~zF"

if %TARGET_SIZE% LSS 1024 (
    echo [ERROR] Restored ACCDB is unexpectedly small.
    echo Size: %TARGET_SIZE% bytes
    del /q "%TARGET%" >nul 2>&1
    pause
    exit /b 1
)

attrib +h "%WORKDIR%" >nul 2>&1
attrib +h "%TARGET%" >nul 2>&1
del "%TARGET%:Zone.Identifier" >nul 2>&1

call :REGISTER_TRUST
if errorlevel 1 goto TRUST_ERROR

goto OPEN_DATABASE

:REGISTER_TRUST

reg add "%TRUSTKEY%" /v Path /t REG_SZ /d "%WORKDIR%\" /f >nul 2>&1
if errorlevel 1 exit /b 1

reg add "%TRUSTKEY%" /v AllowSubFolders /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 exit /b 1

reg add "%TRUSTKEY%" /v Description /t REG_SZ /d "ADS SQL Training Lab" /f >nul 2>&1
if errorlevel 1 exit /b 1

call :CHECK_TRUST
if errorlevel 1 exit /b 1

echo Access Trusted Location is ready.
exit /b 0

:CHECK_TRUST

reg query "%TRUSTKEY%" /v Path 2>nul ^
    | findstr /I /C:"%WORKDIR%\" >nul

if errorlevel 1 exit /b 1
exit /b 0

:OPEN_DATABASE

set "ACCESS_EXE="

for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"

if not defined ACCESS_EXE (
    for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"
)

if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE"

if not defined ACCESS_EXE (
    echo [ERROR] Microsoft Access was not found.
    echo Database:
    echo %TARGET%
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] Local ACCDB was not found.
    echo %TARGET%
    pause
    exit /b 1
)

start "" "%ACCESS_EXE%" "%TARGET%"
endlocal
exit /b 0

:TRUST_ERROR

echo [ERROR] Could not register the Access Trusted Location.
echo.
echo An Intune, Group Policy, or Microsoft 365 Apps policy
echo may be blocking user Trusted Locations.
echo.
echo Folder:
echo %WORKDIR%
pause

endlocal
exit /b 1

:WRITE_DECODER

> "%~1" echo var args = WScript.Arguments;
>>"%~1" echo if (args.length ^< 2) WScript.Quit(2);
>>"%~1" echo var selfPath = args.Item(0);
>>"%~1" echo var targetPath = args.Item(1);
>>"%~1" echo try {
>>"%~1" echo   var textStream = new ActiveXObject("ADODB.Stream");
>>"%~1" echo   textStream.Type = 2;
>>"%~1" echo   textStream.Charset = "utf-8";
>>"%~1" echo   textStream.Open();
>>"%~1" echo   textStream.LoadFromFile(selfPath);
>>"%~1" echo   var content = textStream.ReadText();
>>"%~1" echo   textStream.Close();
>>"%~1" echo   var marker = ":" + "__SQLTRAINING_" + "PAYLOAD__";
>>"%~1" echo   var pos = content.lastIndexOf(marker);
>>"%~1" echo   if (pos == -1) WScript.Quit(3);
>>"%~1" echo   var base64 = content.substring(pos + marker.length);
>>"%~1" echo   base64 = base64.replace(/\s/g, "");
>>"%~1" echo   if (base64.length == 0) WScript.Quit(4);
>>"%~1" echo   if ((base64.length %% 4) != 0) WScript.Quit(5);
>>"%~1" echo   if (/[^A-Za-z0-9+\/=]/.test(base64)) WScript.Quit(6);
>>"%~1" echo   var xml;
>>"%~1" echo   try {
>>"%~1" echo     xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
>>"%~1" echo   } catch (ignore) {
>>"%~1" echo     xml = new ActiveXObject("Msxml2.DOMDocument.3.0");
>>"%~1" echo   }
>>"%~1" echo   var node = xml.createElement("base64");
>>"%~1" echo   node.dataType = "bin.base64";
>>"%~1" echo   node.text = base64;
>>"%~1" echo   var bytes = node.nodeTypedValue;
>>"%~1" echo   if (bytes.length ^< 1024) WScript.Quit(7);
>>"%~1" echo   var binaryStream = new ActiveXObject("ADODB.Stream");
>>"%~1" echo   binaryStream.Type = 1;
>>"%~1" echo   binaryStream.Open();
>>"%~1" echo   binaryStream.Write(bytes);
>>"%~1" echo   binaryStream.SaveToFile(targetPath, 2);
>>"%~1" echo   binaryStream.Close();
>>"%~1" echo   WScript.Quit(0);
>>"%~1" echo } catch (e) {
>>"%~1" echo   WScript.Echo("Decode error: " + e.number + " / " + e.description);
>>"%~1" echo   WScript.Quit(1);
>>"%~1" echo }

exit /b 0

:__SQLTRAINING_PAYLOAD__
