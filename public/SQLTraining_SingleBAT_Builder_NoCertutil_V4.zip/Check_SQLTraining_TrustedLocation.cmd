@echo off
setlocal

set "WORKDIR=%LOCALAPPDATA%\ADS\SQLTraining"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "TRUSTKEY=HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99"

echo Local ACCDB:
if exist "%TARGET%" (
    for %%F in ("%TARGET%") do echo [OK] %%~fF  Size=%%~zF
) else (
    echo [NG] Not found
)

echo.
echo Trusted Location:
reg query "%TRUSTKEY%" /v Path

echo.
echo Expected:
echo %WORKDIR%\
echo.
pause

endlocal
