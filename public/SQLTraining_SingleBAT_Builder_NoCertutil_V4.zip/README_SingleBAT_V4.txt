SQL Training Single-BAT Builder V4
==================================

V3 failure cause
----------------
The V3 decoder used:

    content.indexOf(":__SQLTRAINING_PAYLOAD__")

The same marker text also appeared earlier inside the decoder source code.
Therefore, indexOf found the wrong position. Batch/JScript source code was
passed to the Base64 decoder, producing:

    Decode error: -2147024809
    The parameter is incorrect.

V4 fix
------
V4 uses:

    var marker = ":" + "__SQLTRAINING_" + "PAYLOAD__";
    var pos = content.lastIndexOf(marker);

The complete marker text no longer appears in the decoder source, and
lastIndexOf selects the real marker at the end of the BAT.

V4 also validates:
- payload is not empty
- Base64 length is divisible by 4
- only Base64 characters are present
- decoded file is at least 1024 bytes

Build
-----
1. Put the final database in this folder as:
   SQLTraining_v1.0.accdb

2. Run:
   Build_SQLTraining_SingleBAT_NoCertutil_V4.cmd

3. Distribute only:
   SQLTraining_SingleFile_V4.bat

Clean test
----------
1. Close Microsoft Access.
2. Press Win + R.
3. Enter:
   %LOCALAPPDATA%\ADS
4. Delete the SQLTraining folder.
5. Run SQLTraining_SingleFile_V4.bat.
6. Close Access.
7. Run the same BAT a second time.

Second launch
-------------
If the local ACCDB exists and Location99 is correct:
- no cscript
- no registry rewrite
- no database restoration
- direct Access launch

If the ACCDB exists but Location99 is missing:
- only Location99 is repaired
- the ACCDB is not overwritten
