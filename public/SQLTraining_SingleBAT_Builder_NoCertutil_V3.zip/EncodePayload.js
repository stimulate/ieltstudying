// EncodePayload.js
// Binary ACCDB -> Base64 text without certutil or PowerShell.

(function () {
    if (WScript.Arguments.length < 2) {
        WScript.Quit(2);
    }

    var inputPath = WScript.Arguments.Item(0);
    var outputPath = WScript.Arguments.Item(1);

    try {
        var binaryStream = new ActiveXObject("ADODB.Stream");
        binaryStream.Type = 1;
        binaryStream.Open();
        binaryStream.LoadFromFile(inputPath);
        var bytes = binaryStream.Read();
        binaryStream.Close();

        var xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
        var node = xml.createElement("base64");
        node.dataType = "bin.base64";
        node.nodeTypedValue = bytes;

        var base64 = node.text.replace(/\r/g, "").replace(/\n/g, "");
        var wrapped = "";

        for (var i = 0; i < base64.length; i += 76) {
            wrapped += base64.substr(i, 76) + "\r\n";
        }

        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var output = fso.CreateTextFile(outputPath, true, false);
        output.Write(wrapped);
        output.Close();

        WScript.Quit(0);
    } catch (e) {
        WScript.Echo("Encode error: " + e.number + " / " + e.description);
        WScript.Quit(1);
    }
})();
