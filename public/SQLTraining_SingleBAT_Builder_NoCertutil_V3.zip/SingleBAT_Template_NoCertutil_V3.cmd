@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion

rem ============================================================
rem SQL Training Lab - Single self-extracting BAT V3
rem
rem This version follows the Trusted Location registry block
rem from the previous BAT that did not show "Enable Content".
rem
rem First run:
rem   1. Create local folder.
rem   2. Restore embedded ACCDB.
rem   3. Hide the folder and ACCDB.
rem   4. Add Access Trusted Location using Location99.
rem   5. Verify the registry path.
rem   6. Open with MSACCESS.EXE.
rem
rem Second and later runs:
rem   - If ACCDB exists and Trusted Location is correct:
rem       open immediately.
rem   - If ACCDB exists but Trusted Location is missing:
rem       repair only the registry and open.
rem   - Do not restore or overwrite the ACCDB.
rem   - Do not run cscript again.
rem
rem certutil and PowerShell are not used.
rem ============================================================

set "WORKDIR=%LOCALAPPDATA%\ADS\SQLTraining"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "TEMPJS=%TEMP%\SQLTraining_Decode_%RANDOM%_%RANDOM%.js"
set "TRUSTKEY=HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99"

rem ------------------------------------------------------------
rem Existing local ACCDB:
rem Verify Trusted Location first.
rem ------------------------------------------------------------
if exist "%TARGET%" (
    call :CHECK_TRUST
    if not errorlevel 1 goto OPEN_DATABASE

    echo.
    echo ローカルデータベースは存在しますが、
    echo Accessの信頼できる場所が確認できません。
    echo 登録のみ修復します。
    echo.

    call :REGISTER_TRUST
    if errorlevel 1 goto TRUST_ERROR

    goto OPEN_DATABASE
)

rem ------------------------------------------------------------
rem First run
rem ------------------------------------------------------------
echo.
echo SQL Training Labの初回セットアップを開始します。
echo.

rem Access can cache Trust Center settings.
tasklist /FI "IMAGENAME eq MSACCESS.EXE" 2>nul | find /I "MSACCESS.EXE" >nul
if not errorlevel 1 (
    echo [ERROR] Microsoft Accessが起動中です。
    echo.
    echo すべてのAccess画面を閉じてから、
    echo このBATを再実行してください。
    pause
    exit /b 1
)

if not exist "%WORKDIR%" mkdir "%WORKDIR%" >nul 2>&1

if not exist "%WORKDIR%" (
    echo [ERROR] ローカルフォルダーを作成できませんでした。
    echo %WORKDIR%
    pause
    exit /b 1
)

where cscript.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] cscript.exeが見つかりません。
    pause
    exit /b 1
)

call :WRITE_DECODER "%TEMPJS%"

if not exist "%TEMPJS%" (
    echo [ERROR] 一時デコードスクリプトを作成できませんでした。
    pause
    exit /b 1
)

cscript.exe //nologo "%TEMPJS%" "%~f0" "%TARGET%"
set "DECODE_RC=%ERRORLEVEL%"

del /q "%TEMPJS%" >nul 2>&1

if not "%DECODE_RC%"=="0" (
    echo [ERROR] 内蔵ACCDBを復元できませんでした。
    echo.
    echo cscript.exe、ADODB.Stream、またはMSXMLが
    echo 会社のポリシーで制限されている可能性があります。
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] 復元後のデータベースが見つかりません。
    pause
    exit /b 1
)

rem Same behavior as the previous working BAT.
attrib +h "%WORKDIR%" >nul 2>&1
attrib +h "%TARGET%" >nul 2>&1

rem Remove the Internet Zone stream from the restored local file if present.
del "%TARGET%:Zone.Identifier" >nul 2>&1

call :REGISTER_TRUST
if errorlevel 1 goto TRUST_ERROR

goto OPEN_DATABASE

rem ------------------------------------------------------------
rem Register Trusted Location
rem This block follows the previous working BAT.
rem ------------------------------------------------------------
:REGISTER_TRUST

reg add "%TRUSTKEY%" /v Path /t REG_SZ /d "%WORKDIR%\" /f >nul 2>&1
if errorlevel 1 exit /b 1

reg add "%TRUSTKEY%" /v AllowSubFolders /t REG_DWORD /d 0 /f >nul 2>&1
if errorlevel 1 exit /b 1

reg add "%TRUSTKEY%" /v Description /t REG_SZ /d "ADS SQL Training Lab" /f >nul 2>&1
if errorlevel 1 exit /b 1

call :CHECK_TRUST
if errorlevel 1 exit /b 1

echo Accessの信頼できる場所を登録しました。
exit /b 0

rem ------------------------------------------------------------
rem Check the exact trusted path without changing the registry.
rem ------------------------------------------------------------
:CHECK_TRUST

reg query "%TRUSTKEY%" /v Path 2>nul ^
    | findstr /I /C:"%WORKDIR%\" >nul

if errorlevel 1 exit /b 1
exit /b 0

rem ------------------------------------------------------------
rem Find and open Microsoft Access
rem This follows the previous working BAT.
rem ------------------------------------------------------------
:OPEN_DATABASE

set "ACCESS_EXE="

for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"

if not defined ACCESS_EXE (
    for /f "tokens=2,*" %%A in ('reg query "HKLM\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\MSACCESS.EXE" /ve 2^>nul ^| findstr /i "REG_SZ"') do set "ACCESS_EXE=%%B"
)

if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\root\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles%\Microsoft Office\Office16\MSACCESS.EXE"
if not defined ACCESS_EXE if exist "%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE" set "ACCESS_EXE=%ProgramFiles(x86)%\Microsoft Office\Office16\MSACCESS.EXE"

if not defined ACCESS_EXE (
    echo [ERROR] Microsoft Accessが見つかりません。
    echo.
    echo Database restored to:
    echo %TARGET%
    pause
    exit /b 1
)

if not exist "%TARGET%" (
    echo [ERROR] ローカルデータベースが見つかりません。
    echo %TARGET%
    pause
    exit /b 1
)

start "" "%ACCESS_EXE%" "%TARGET%"
endlocal
exit /b 0

rem ------------------------------------------------------------
rem Trusted Location failure
rem ------------------------------------------------------------
:TRUST_ERROR

echo [ERROR] Accessの信頼できる場所を登録できませんでした。
echo.
echo 会社のIntune、Group Policy、またはOfficeポリシーで、
echo ユーザーによるTrusted Locationの登録が
echo 制限されている可能性があります。
echo.
echo 対象:
echo %WORKDIR%
pause

endlocal
exit /b 1

rem ------------------------------------------------------------
rem Create temporary JScript decoder.
rem ------------------------------------------------------------
:WRITE_DECODER

> "%~1" echo var args = WScript.Arguments;
>>"%~1" echo if (args.length ^< 2) WScript.Quit(2);
>>"%~1" echo var selfPath = args.Item(0);
>>"%~1" echo var targetPath = args.Item(1);
>>"%~1" echo try {
>>"%~1" echo   var textStream = new ActiveXObject("ADODB.Stream");
>>"%~1" echo   textStream.Type = 2;
>>"%~1" echo   textStream.Charset = "utf-8";
>>"%~1" echo   textStream.Open();
>>"%~1" echo   textStream.LoadFromFile(selfPath);
>>"%~1" echo   var content = textStream.ReadText();
>>"%~1" echo   textStream.Close();
>>"%~1" echo   var marker = ":__SQLTRAINING_PAYLOAD__";
>>"%~1" echo   var pos = content.indexOf(marker);
>>"%~1" echo   if (pos == -1) WScript.Quit(3);
>>"%~1" echo   var base64 = content.substring(pos + marker.length);
>>"%~1" echo   base64 = base64.replace(/\s/g, "");
>>"%~1" echo   var xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
>>"%~1" echo   var node = xml.createElement("base64");
>>"%~1" echo   node.dataType = "bin.base64";
>>"%~1" echo   node.text = base64;
>>"%~1" echo   var bytes = node.nodeTypedValue;
>>"%~1" echo   var binaryStream = new ActiveXObject("ADODB.Stream");
>>"%~1" echo   binaryStream.Type = 1;
>>"%~1" echo   binaryStream.Open();
>>"%~1" echo   binaryStream.Write(bytes);
>>"%~1" echo   binaryStream.SaveToFile(targetPath, 2);
>>"%~1" echo   binaryStream.Close();
>>"%~1" echo   WScript.Quit(0);
>>"%~1" echo } catch (e) {
>>"%~1" echo   WScript.Echo("Decode error: " + e.number + " / " + e.description);
>>"%~1" echo   WScript.Quit(1);
>>"%~1" echo }

exit /b 0

:__SQLTRAINING_PAYLOAD__
