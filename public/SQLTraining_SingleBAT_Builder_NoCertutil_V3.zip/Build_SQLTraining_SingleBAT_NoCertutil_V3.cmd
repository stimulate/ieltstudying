@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion

rem ============================================================
rem SQL Training Single-BAT Builder V3
rem
rem - certutil is not used.
rem - PowerShell is not used.
rem - The Trusted Location block follows the previous working BAT.
rem ============================================================

set "DATABASE=%~1"
if not defined DATABASE set "DATABASE=%~dp0SQLTraining_v1.0.accdb"

set "TEMPLATE=%~dp0SingleBAT_Template_NoCertutil_V3.cmd"
set "ENCODER=%~dp0EncodePayload.js"
set "OUTPUT=%~dp0SQLTraining_SingleFile_V3.bat"
set "TEMPBASE64=%TEMP%\SQLTraining_Payload_%RANDOM%_%RANDOM%.b64"

echo.
echo SQL Training用の単一BAT V3を作成します。
echo.

if not exist "%DATABASE%" (
    echo [ERROR] ACCDBファイルが見つかりません。
    echo.
    echo 対象:
    echo %DATABASE%
    echo.
    echo SQLTraining_v1.0.accdbを同じフォルダーに置くか、
    echo ACCDBファイルをこのCMDへドラッグしてください。
    pause
    exit /b 1
)

if not exist "%TEMPLATE%" (
    echo [ERROR] テンプレートが見つかりません。
    echo %TEMPLATE%
    pause
    exit /b 1
)

if not exist "%ENCODER%" (
    echo [ERROR] EncodePayload.jsが見つかりません。
    echo %ENCODER%
    pause
    exit /b 1
)

where cscript.exe >nul 2>&1
if errorlevel 1 (
    echo [ERROR] cscript.exeが見つかりません。
    pause
    exit /b 1
)

if exist "%TEMPBASE64%" del /q "%TEMPBASE64%" >nul 2>&1

cscript.exe //nologo "%ENCODER%" "%DATABASE%" "%TEMPBASE64%"
if errorlevel 1 (
    echo.
    echo [ERROR] ACCDBをBase64へ変換できませんでした。
    echo cscript.exe、ADODB.Stream、またはMSXMLが
    echo 会社のポリシーで制限されている可能性があります。
    if exist "%TEMPBASE64%" del /q "%TEMPBASE64%" >nul 2>&1
    pause
    exit /b 1
)

if not exist "%TEMPBASE64%" (
    echo [ERROR] Base64ペイロードが作成されませんでした。
    pause
    exit /b 1
)

copy /B /Y "%TEMPLATE%"+"%TEMPBASE64%" "%OUTPUT%" >nul
set "BUILD_RC=%ERRORLEVEL%"

del /q "%TEMPBASE64%" >nul 2>&1

if not "%BUILD_RC%"=="0" (
    echo [ERROR] 単一BATファイルを作成できませんでした。
    pause
    exit /b 1
)

if not exist "%OUTPUT%" (
    echo [ERROR] 出力ファイルを確認できませんでした。
    pause
    exit /b 1
)

echo.
echo 作成完了:
echo %OUTPUT%
echo.
echo 受講者にはSQLTraining_SingleFile_V3.batだけを配布してください。
echo.
pause
endlocal
exit /b 0
