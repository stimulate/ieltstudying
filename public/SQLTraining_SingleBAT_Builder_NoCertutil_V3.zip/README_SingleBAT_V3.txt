SQL Training Single-BAT Builder V3
==================================

V3 incorporates the registry and MSACCESS.EXE lookup logic from the
previous BAT shown in the screenshot.

Key changes
-----------
- Uses this key again:
  HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99

- Uses the same three registry values:
  Path
  AllowSubFolders
  Description

- Uses the previous MSACCESS.EXE App Paths lookup logic.

- Does not use certutil.
- Does not use PowerShell.

Second launch behavior
----------------------
1. If SQLTraining.accdb exists, V3 checks Location99.
2. If the trusted path is correct, it opens Access immediately.
3. It does not restore or overwrite the database.
4. It does not run cscript.
5. It does not rewrite the registry.
6. If the database exists but Location99 is missing, it repairs only the
   registry and opens the existing database.

Build steps
-----------
1. Put your final ACCDB in this folder as:
   SQLTraining_v1.0.accdb

   Or drag an ACCDB onto:
   Build_SQLTraining_SingleBAT_NoCertutil_V3.cmd

2. Run:
   Build_SQLTraining_SingleBAT_NoCertutil_V3.cmd

3. It creates:
   SQLTraining_SingleFile_V3.bat

4. Distribute only SQLTraining_SingleFile_V3.bat.

Clean test
----------
1. Close all Access windows.
2. Press Win + R.
3. Enter:
   %LOCALAPPDATA%\ADS
4. Delete the SQLTraining folder.
5. Run SQLTraining_SingleFile_V3.bat.
6. Confirm there is no "Enable Content" message.
7. Close Access.
8. Run the BAT a second time.

Manual confirmation
-------------------
In Access:
File
> Options
> Trust Center
> Trust Center Settings
> Trusted Locations

Confirm:
C:\Users\<user>\AppData\Local\ADS\SQLTraining\

If the path is not displayed even though reg add succeeds, an enterprise
policy is blocking or ignoring user Trusted Locations. A BAT cannot override
an Intune, Group Policy, or Microsoft 365 Apps policy.
