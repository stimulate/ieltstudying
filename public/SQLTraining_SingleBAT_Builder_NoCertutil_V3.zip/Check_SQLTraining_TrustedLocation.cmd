@echo off
chcp 65001 >nul
setlocal

set "WORKDIR=%LOCALAPPDATA%\ADS\SQLTraining"
set "TARGET=%WORKDIR%\SQLTraining.accdb"
set "TRUSTKEY=HKCU\Software\Microsoft\Office\16.0\Access\Security\Trusted Locations\Location99"

echo.
echo Local ACCDB:
if exist "%TARGET%" (
    echo [OK] %TARGET%
) else (
    echo [NG] Not found
)

echo.
echo Trusted Location:
reg query "%TRUSTKEY%" /v Path

echo.
echo Expected path:
echo %WORKDIR%\
echo.
pause

endlocal
